'use strict';
/* ===== Жизнь государства: недовольство, восстания, события, жители ===== */
const clampL = (v, a, b) => Math.max(a, Math.min(b, v));

/* Случайность событий: у каждого игрока свой независимый поток (по seed, номеру игрока и счётчику),
   поэтому события игроков не пересекаются и одинаково выпадают у всех участников мультиплеера. */
function evR(S, p) {
  if (!p.ev) p.ev = { n: 0, next: S.time + 150 + 120, mods: [], last: '' };
  p.ev.n++;
  let h = (Math.imul((S.seed | 0) ^ 0x9e3779b9, 2654435761) ^ Math.imul(p.id + 1, 40503) ^ Math.imul(p.ev.n, 2246822519)) >>> 0;
  h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0; h = Math.imul(h ^ (h >>> 13), 3266489909) >>> 0;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
function evMod(S, pid, k) {
  const p = S.players[pid]; if (!p || !p.ev || !p.ev.mods) return 1; let m = 1;
  for (const q of p.ev.mods) if (q.k === k && q.until > S.time) m *= q.m; return m;
}
function unrestMult(c) { const u = c.unrest === undefined ? 25 : c.unrest; return 1 - clampL((u - 50) / 125, 0, 0.4); }
const ownCities = (S, pid) => S.cities.filter(c => c.owner === pid);
const hasB = (S, pid, t) => S.buildings.some(b => b.owner === pid && b.type === t && !(b.cons > 0));

/* ===== Недовольство ===== */
function unrestFactors(S, c, p) {
  const cx = c.x + 1, cy = c.y + 1, f = { h: 0, w: 0, s: 0, b: 0, a: 0, g: 0, k: c.isCap ? -4 : 0 };
  if (p.stock.food <= 0.5) f.h = 40; else if (p.rate.food < 0 && p.stock.food < 80) f.h = 18;
  let wd = 0; for (const q of S.players) if (q.id !== p.id && q.alive && atWar(S, p.id, q.id)) wd = Math.max(wd, (S.time - rel(S, p.id, q.id).warSince) / DAY);
  if (wd > 0) { f.w = Math.min(20, Math.round(wd * 4)); f.s = clampL(Math.round(-(p.wr || 0) * 3), -15, 20); }
  let nb = 0; for (let k = 0; k < 12; k++) for (const r of [4.5, 7]) { const x = Math.round(cx + Math.cos(k * 0.5236) * r), y = Math.round(cy + Math.sin(k * 0.5236) * r); if (x < 0 || y < 0 || x >= S.W || y >= S.H) continue; const o = S.terr[y * S.W + x]; if (o >= 0 && o !== p.id && atWar(S, p.id, o)) nb++; }
  f.b = Math.min(18, Math.round(nb * 1.5));
  let en = false, own = false;
  for (const a of S.armies) { if (a.ship) continue; const d = dist(a.x, a.y, cx, cy); if (a.owner === p.id) { if (d < 3.5) own = true; } else if (d < 7 && atWar(S, p.id, a.owner)) en = true; }
  f.a = (en ? 12 : 0) + (own ? -6 : 0);
  if (p.stock.food > 400 && p.rate.food >= 0) f.g = -5; else if (p.stock.food > 150 && p.rate.food >= 0) f.g = -2;
  f.sum = f.h + f.w + f.s + f.b + f.a + f.k + f.g; return f;
}
/* Живые колебания настроения: у каждого города своя фаза, настроение то немного растёт (слухи, базарные дни), то спадает —
   детерминированно по времени и номеру города, поэтому у всех участников мультиплеера одинаково. */
function noiseL(t, id) { const h = k => { let x = (Math.imul(k + 1, 2654435761) ^ Math.imul(id + 7, 40503)) >>> 0; x = Math.imul(x ^ (x >>> 15), 2246822507) >>> 0; return ((x ^ (x >>> 13)) >>> 0) / 4294967296; }; const i = Math.floor(t / 35), f = t / 35 - i, u = f * f * (3 - 2 * f); return (h(i) * (1 - u) + h(i + 1) * u) * 2 - 1; }
function moodWobble(S, c) { const t = S.time, ph = c.id * 1.7; return 4.5 * Math.sin(t / 31 + ph) + 2.5 * Math.sin(t / 11.5 + ph * 2.3) + 4 * noiseL(t, c.id); }
function tickUnrest(S, dt) {
  const calc = S.tk % 8 === 0;
  for (const c of S.cities) {
    if (c.owner < 0) continue; const p = S.players[c.owner]; if (!p) continue;
    if (c.unrest === undefined) c.unrest = 25;
    if (calc || !c.uf) c.uf = unrestFactors(S, c, p);
    const target = clampL(25 + c.uf.sum + moodWobble(S, c), 0, 100), d = target - c.unrest; c.ut = target; c.unrest = clampL(c.unrest + clampL(d, -0.6 * dt, 0.6 * dt), 0, 100);
  }
  for (const p of S.players) if (p.wr) p.wr *= 1 - 0.004 * dt;
}

/* ===== Восстания ===== */
function revoltSize(S, p) { let t = 0; for (let i = 0; i < S.terr.length; i++) if (S.terr[i] === p.id) t++; return clampL(1 + Math.round(ownCities(S, p.id).length * 0.5 + t / 220), 1, 6); }
function startRevolt(S, c, p) {
  const n = revoltSize(S, p), sq = []; for (let i = 0; i < n; i++) sq.push(mkSquad('militia'));
  const a = newArmy(S, -1, c.x + 1, c.y + 2.6, sq); a.reb = { c: c.id, t: S.time };
  c.revCd = S.time + 480; c.unrest = 48;
  pushEvent(S, p, 'revolt', { c }, [{ units: n * SQ.militia.cnt }], 0, 'Восстание в ' + c.name, 'Крестьяне взялись за вилы: мятежники осадили ' + c.name + '. Подавите бунт, пока они не захватили город!');
}
function tickRevolts(S) {
  for (const c of S.cities) {
    if (c.owner < 0 || S.time < 180 || S.time < (c.revCd || 0)) continue; const u = c.unrest === undefined ? 25 : c.unrest; if (u < 55) continue;
    if (S.armies.some(a => a.reb && a.reb.c === c.id)) continue; const p = S.players[c.owner]; if (!p || !p.alive) continue;
    const k = (u - 55) / 45; if (evR(S, p) < k * k * 0.012) startRevolt(S, c, p);
  }
  for (const a of S.armies.slice()) if (a.reb) {
    if (S.time - a.reb.t > 700) { S.armies = S.armies.filter(q => q !== a); continue; }
    const c = S.cities[a.reb.c]; if (!c || c.owner < 0) continue; const p = S.players[c.owner]; if (p.human) continue;
    let best = null, bd = 1e9; for (const q of S.armies) if (q.owner === c.owner && !q.ship && !q.reb) { const d = dist(q.x, q.y, c.x + 1, c.y + 1); if (d > 2.5 && d < bd) { bd = d; best = q; } }
    if (best && best.st === 'idle') orderMove(S, best, c.x + 1, c.y + 2.6);
  }
}

/* ===== События ===== */
const EVENTS = [
  { id: 'gems', good: 1, art: 'gems', t: 'Драгоценные камни', d: 'Крестьяне нашли в русле ручья россыпь самоцветов. Ювелиры уже спорят о цене.', cond: () => true, make: (S, p, R, x) => [{ r: 'gold', v: Math.round(150 + R() * 150 + 30 * x.nc) }] },
  { id: 'soil', good: 1, art: 'soil', t: 'Плодородная почва', d: 'После тёплых дождей земля стала на диво плодородной: поля дают куда больше зерна.', cond: (S, p) => hasB(S, p.id, 'farm'), make: () => [{ mod: 'food', m: 1.35, days: 4 }] },
  { id: 'vein', good: 1, art: 'vein', t: 'Богатая жила', d: 'Рудокопы наткнулись на богатую жилу — шахты работают с удвоенным рвением.', cond: (S, p) => hasB(S, p.id, 'mine'), make: () => [{ mod: 'mine', m: 1.4, days: 3 }] },
  { id: 'caravan', good: 1, art: 'caravan', t: 'Торговый караван', d: 'К вашим воротам пришёл купеческий караван и щедро заплатил за право торговать.', cond: (S, p) => hasB(S, p.id, 'market') || hasB(S, p.id, 'port'), make: (S, p, R) => [{ r: 'gold', v: Math.round(110 + R() * 160) }] },
  { id: 'harvest', good: 1, art: 'harvest', t: 'Богатый урожай', d: 'Осень выдалась на славу: амбары ломятся от зерна, а хлеба хватит надолго.', cond: (S, p) => hasB(S, p.id, 'farm'), make: (S, p, R, x) => [{ r: 'food', v: Math.round(140 + R() * 100 + 35 * x.farms) }] },
  { id: 'smiths', good: 1, art: 'smiths', t: 'Странствующие кузнецы', d: 'Мастера-оружейники остановились в ваших землях и поделились слитками и секретами ремесла.', cond: () => true, make: (S, p, R) => [{ r: 'iron', v: Math.round(60 + R() * 80) }] },
  { id: 'timber', good: 1, art: 'timber', t: 'Лесная удача', d: 'Лесорубы нашли нетронутую рощу корабельных сосен — брёвен хватит на много построек.', cond: (S, p) => hasB(S, p.id, 'sawmill'), make: (S, p, R) => [{ r: 'wood', v: Math.round(150 + R() * 150) }] },
  { id: 'feast', good: 1, art: 'feast', t: 'Праздник урожая', d: 'Народ веселится на ярмарке: песни, пляски, эль рекой. Недовольство в городах спадает.', cond: (S, p) => ownCities(S, p.id).length > 0, make: () => [{ unrest: -15, all: 1 }] },
  { id: 'settlers', good: 1, art: 'settlers', t: 'Переселенцы', d: n => n + ': прибыли переселенцы из дальних земель. Они принесли серебро и зерно и готовы работать.', cond: (S, p, x) => !!x.city, make: (S, p, R, x) => [{ r: 'gold', v: Math.round(70 + R() * 70) }, { r: 'food', v: Math.round(50 + R() * 50) }, { unrest: -8, city: x.city.id }] },
  { id: 'plague', good: 0, art: 'plague', t: 'Поветрие', d: n => n + ': вспыхнула болезнь. Лекари бессильны, торговля встала, люди ропщут.', cond: (S, p, x) => !!x.city && p.stock.food >= 80, make: (S, p, R, x) => [{ r: 'food', v: -Math.round(p.stock.food * (0.2 + R() * 0.15)) }, { r: 'gold', v: -Math.round(p.stock.gold * 0.1) }, { unrest: 10, city: x.city.id }] },
  { id: 'lostcaravan', good: 0, art: 'lostcaravan', t: 'Ограбленный караван', d: 'Купеческий караван пропал на дороге: разбойники унесли весь товар, а возницы разбежались.', cond: (S, p) => (hasB(S, p.id, 'market') || hasB(S, p.id, 'port')) && p.stock.gold >= 100, make: (S, p, R) => [{ r: 'gold', v: -Math.round(Math.min(p.stock.gold * 0.5, 80 + R() * 120)) }] },
  { id: 'shipwreck', good: 0, art: 'shipwreck', t: 'Кораблекрушение', d: 'Шторм разбил ваше судно о скалы. Корабль и груз потеряны навсегда.', cond: (S, p) => S.ships.some(sh => sh.owner === p.id && !shipLoad(S, sh)), make: (S, p, R) => [{ ship: -1 }, { r: 'gold', v: -Math.round(Math.min(p.stock.gold * 0.3, 40 + R() * 60)) }] },
  { id: 'blight', good: 0, art: 'blight', t: 'Неурожай', d: 'Мор побил посевы: колосья чернеют, не успев созреть. Придётся затянуть пояса.', cond: (S, p) => hasB(S, p.id, 'farm') && p.stock.food >= 80, make: (S, p, R) => [{ r: 'food', v: -Math.round(p.stock.food * (0.3 + R() * 0.15)) }, { mod: 'food', m: 0.6, days: 3 }] },
  { id: 'fire', good: 0, art: 'fire', t: n => 'Пожар в ' + n, d: 'Огонь пожрал склады и лесные запасы. Пока тушили, часть добра растащили.', cond: (S, p, x) => !!x.city && p.stock.wood >= 100, make: (S, p, R, x) => [{ r: 'wood', v: -Math.round(p.stock.wood * (0.25 + R() * 0.1)) }, { r: 'gold', v: -Math.round(Math.min(p.stock.gold * 0.15, 60)) }, { unrest: 6, city: x.city.id }] },
  { id: 'bandits', good: 0, art: 'bandits', t: 'Налёт разбойников', d: 'Лихие люди ограбили обозы на дорогах и ушли в лес. Стража опоздала.', cond: (S, p) => p.stock.gold >= 150, make: (S, p, R) => [{ r: 'gold', v: -Math.round(p.stock.gold * (0.08 + R() * 0.06)) }, { r: 'iron', v: -Math.round(p.stock.iron * 0.15) }] },
  { id: 'rats', good: 0, art: 'rats', t: 'Крысы в амбарах', d: 'Серые полчища добрались до зерна. Часть запасов испорчена, а хлеб подорожал.', cond: (S, p) => p.stock.food >= 100, make: (S, p, R) => [{ r: 'food', v: -Math.round(p.stock.food * (0.2 + R() * 0.1)) }] },
  { id: 'treasure', good: 1, art: 'treasure', t: 'Старый клад', d: 'Копая колодец, крестьяне наткнулись на окованный сундук со старыми монетами. Староста клянётся, что делиться не придётся.', cond: () => true, make: (S, p, R, x) => [{ r: 'gold', v: Math.round(180 + R() * 200 + 30 * x.nc) }] },
  { id: 'bard', good: 1, art: 'bard', t: 'Странствующий бард', d: 'На площади запел бродячий бард, и скоро весь город подпевал ему. Ропот стих, а шляпа менестреля наполнилась медью.', cond: (S, p, x) => !!x.city, make: (S, p, R, x) => [{ r: 'gold', v: Math.round(30 + R() * 40) }, { unrest: -10, city: x.city.id }] },
  { id: 'blessing', good: 1, art: 'blessing', t: 'Благословение', d: 'Странствующий епископ отслужил молебен о мире и урожае. Люди разошлись умиротворёнными, а в амбарах появились пожертвования.', cond: (S, p) => ownCities(S, p.id).length > 0, make: (S, p, R) => [{ r: 'food', v: Math.round(40 + R() * 50) }, { unrest: -10, all: 1 }] },
  { id: 'rain', good: 1, art: 'rain', t: 'Благодатные дожди', d: 'Над полями прошли тёплые ливни, засияла радуга. Земля напилась влагой, и всходы пошли в рост.', cond: (S, p) => hasB(S, p.id, 'farm'), make: () => [{ mod: 'food', m: 1.25, days: 3 }] },
  { id: 'wedding', good: 1, art: 'wedding', t: 'Пышная свадьба', d: 'Дочь богатого купца выходит замуж: гуляет весь город, гости осыпают молодых дарами, а казна получает пошлину с торга.', cond: (S, p) => ownCities(S, p.id).length > 0, make: (S, p, R) => [{ r: 'gold', v: Math.round(60 + R() * 70) }, { unrest: -8, all: 1 }] },
  { id: 'tournament', good: 1, art: 'tournament', t: 'Рыцарский турнир', d: 'Ваши воины устроили турнир. Зрители съехались со всей округи, поставили на победителя и охотно оставили золото в вашей казне.', cond: (S, p, x) => hasB(S, p.id, 'barracks') && !!x.city, make: (S, p, R, x) => [{ r: 'gold', v: Math.round(80 + R() * 90) }, { unrest: -10, city: x.city.id }] },
  { id: 'fishing', good: 1, art: 'fishing', t: 'Богатый улов', d: 'Косяки сельди подошли к самому берегу. Рыбаки возвращаются с полными сетями, и в городе пахнет коптильнями.', cond: (S, p) => hasB(S, p.id, 'port'), make: (S, p, R) => [{ r: 'food', v: Math.round(120 + R() * 100) }] },
  { id: 'hunters', good: 1, art: 'hunters', t: 'Удачная охота', d: 'Охотники затравили оленя и вернулись с богатой добычей. Мяса хватит на много дней, а шкуры уйдут торговцам.', cond: () => true, make: (S, p, R) => [{ r: 'food', v: Math.round(80 + R() * 70) }, { r: 'gold', v: Math.round(20 + R() * 30) }] },
  { id: 'envoy', good: 1, art: 'envoy', t: 'Дары посла', d: 'Посол далёкой страны прибыл с сундуками подарков и просьбой о дружбе. Он хочет, чтобы вас знали далеко за морем.', cond: () => true, make: (S, p, R) => [{ r: 'gold', v: Math.round(100 + R() * 100) }, { r: 'iron', v: Math.round(30 + R() * 30) }] },
  { id: 'drought', good: 0, art: 'drought', t: 'Засуха', d: 'Неделями не было ни капли дождя. Земля потрескалась, колодцы мелеют, а хлеб в полях сохнет на корню.', cond: (S, p) => hasB(S, p.id, 'farm') && p.stock.food >= 80, make: (S, p, R) => [{ r: 'food', v: -Math.round(p.stock.food * (0.1 + R() * 0.05)) }, { mod: 'food', m: 0.7, days: 4 }] },
  { id: 'flood', good: 0, art: 'flood', t: 'Наводнение', d: 'Река вышла из берегов и затопила низины: смыло мостки, подмочило зерно, унесло штабеля брёвен.', cond: (S, p, x) => !!x.city && p.stock.food >= 100 && p.stock.wood >= 80, make: (S, p, R, x) => [{ r: 'food', v: -Math.round(p.stock.food * (0.15 + R() * 0.05)) }, { r: 'wood', v: -Math.round(p.stock.wood * 0.15) }, { unrest: 5, city: x.city.id }] },
  { id: 'storm', good: 0, art: 'storm', t: 'Буря', d: 'Ураган сорвал крыши, повалил заборы и разметал дровяные склады. Чинить придётся за свой счёт.', cond: (S, p) => p.stock.wood >= 80 && p.stock.gold >= 60, make: (S, p, R) => [{ r: 'wood', v: -Math.round(p.stock.wood * (0.15 + R() * 0.1)) }, { r: 'gold', v: -Math.round(Math.min(p.stock.gold * 0.1, 50)) }] },
  { id: 'thieves', good: 0, art: 'thieves', t: 'Кража в казне', d: 'Ночью воры подкопались под сокровищницу и ушли с мешками, пока стража спала. Народ шепчется о нерадивых начальниках.', cond: (S, p, x) => p.stock.gold >= 200 && !!x.city, make: (S, p, R, x) => [{ r: 'gold', v: -Math.round(p.stock.gold * (0.08 + R() * 0.05)) }, { unrest: 4, city: x.city.id }] },
  { id: 'collapse', good: 0, art: 'collapse', t: 'Обвал в шахте', d: 'В забое рухнул свод. Людей откопали, но работы встали, а крепи придётся ставить заново.', cond: (S, p) => hasB(S, p.id, 'mine') && p.stock.iron >= 40, make: (S, p) => [{ r: 'iron', v: -Math.round(p.stock.iron * 0.15) }, { mod: 'mine', m: 0.5, days: 3 }] },
  { id: 'preacher', good: 0, art: 'preacher', t: 'Смутьян-проповедник', d: 'Бродячий проповедник собрал толпу и клеймит власть: «Богачи жиреют, пока вы голодаете!» Люди слушают, и многие кивают.', cond: (S, p, x) => !!x.city, make: (S, p, R, x) => [{ unrest: 14, city: x.city.id }] },
  { id: 'locusts', good: 0, art: 'locusts', t: 'Нашествие саранчи', d: 'Тёмная туча саранчи накрыла поля. Через день от посевов остались лишь голые стебли.', cond: (S, p) => hasB(S, p.id, 'farm') && p.stock.food >= 100, make: (S, p, R) => [{ r: 'food', v: -Math.round(p.stock.food * (0.28 + R() * 0.1)) }, { mod: 'food', m: 0.8, days: 2 }] },
  { id: 'wolves', good: 0, art: 'wolves', t: 'Волки у деревни', d: 'Голодные волки задрали скот и бродят у околиц. По ночам люди не выходят из домов, а в городе растёт тревога.', cond: (S, p, x) => !!x.city && p.stock.food >= 80, make: (S, p, R, x) => [{ r: 'food', v: -Math.round(p.stock.food * (0.1 + R() * 0.07)) }, { unrest: 5, city: x.city.id }] },
  { id: 'frost', good: 0, art: 'frost', t: 'Ранние заморозки', d: 'Ударили морозы, когда хлеб ещё не убран. Иней побил колосья, а крестьяне зябко кутаются в рогожи.', cond: (S, p) => hasB(S, p.id, 'farm'), make: () => [{ mod: 'food', m: 0.75, days: 3 }] },
];
const EVBY = {}; EVENTS.forEach(e => EVBY[e.id] = e); EVBY.revolt = { id: 'revolt', good: 0, art: 'revolt', t: 'Восстание', d: '' };

function applyFx(S, p, list, ctx) {
  for (const f of list) {
    if (f.r) p.stock[f.r] = Math.max(0, p.stock[f.r] + f.v);
    else if (f.mod) { p.ev.mods = (p.ev.mods || []).filter(q => q.until > S.time); p.ev.mods.push({ k: f.mod, m: f.m, until: S.time + f.days * DAY }); }
    else if (f.unrest !== undefined) { for (const c of S.cities) if (c.owner === p.id && (f.all || c.id === f.city)) if (f.set === undefined) c.unrest = clampL((c.unrest === undefined ? 25 : c.unrest) + f.unrest, 0, 100); }
    else if (f.ship) { const sh = S.ships.find(q => q.owner === p.id && !shipLoad(S, q)); if (sh) S.ships = S.ships.filter(q => q !== sh); }
  }
  calcRates(S);
}
function pushEvent(S, p, id, ctx, fx, good, title, text) {
  if (p.human) addMsg(S, p.id, { type: 'event', ev: id, title, text, fx, good });
}
function tickEvents(S) {
  for (const p of S.players) {
    if (!p.alive) continue; if (!p.ev) evR(S, p); if (S.time < p.ev.next) continue;
    const R = () => evR(S, p), mine = ownCities(S, p.id); if (!mine.length) continue;
    p.ev.next = S.time + 200 + R() * 260;
    const ctx = { city: mine[Math.floor(R() * mine.length)], nc: mine.length, farms: S.buildings.filter(b => b.owner === p.id && b.type === 'farm').length };
    p.ev.recent = p.ev.recent || []; let ok = EVENTS.filter(e => !p.ev.recent.includes(e.id) && e.cond(S, p, ctx)); if (!ok.length) ok = EVENTS.filter(e => e.id !== p.ev.last && e.cond(S, p, ctx)); if (!ok.length) continue;
    const e = ok[Math.floor(R() * ok.length)]; p.ev.last = e.id; p.ev.recent.push(e.id); if (p.ev.recent.length > 8) p.ev.recent.shift();
    const fx = e.make(S, p, R, ctx), nm = ctx.city.name;
    applyFx(S, p, fx, ctx); pushEvent(S, p, e.id, ctx, fx, e.good, typeof e.t === 'function' ? e.t(nm) : e.t, typeof e.d === 'function' ? e.d(nm) : e.d);
  }
}
function tickLife(S, dt) {
  tickUnrest(S, dt);
  if (S.tk % 4 === 0) { tickRevolts(S); tickEvents(S); }
}

/* ===== Мирные жители: ходят по улицам города и деревни (только отрисовка, на симуляцию не влияют) ===== */
const VCLOTH = ['#b84a3a', '#3a6ab8', '#4a8a3a', '#8a5a9a', '#c89a3a', '#6a6a72'];
function routePos(rt, s) {
  let L = 0; const sg = []; for (let i = 0; i < rt.length - 1; i++) { const d = Math.hypot(rt[i + 1][0] - rt[i][0], rt[i + 1][1] - rt[i][1]); sg.push(d); L += d; }
  let t = ((s % (2 * L)) + 2 * L) % (2 * L); if (t > L) t = 2 * L - t;
  for (let i = 0; i < sg.length; i++) { if (t <= sg[i] || i === sg.length - 1) { const k = sg[i] ? Math.min(1, t / sg[i]) : 0; return [rt[i][0] + (rt[i + 1][0] - rt[i][0]) * k, rt[i][1] + (rt[i + 1][1] - rt[i][1]) * k]; } t -= sg[i]; }
  return rt[0];
}
function drawVillagers(c, ct, tm) {
  const ox = (ct.x - 1) * TS, oy = (ct.y - 1) * TS, rts = townPlan(ct.level, ct.isCap, ct.vs | 0).paths, n = ct.level === 0 ? 2 + (ct.vs | 0) * 2 : 2 + ct.level * 2 + (ct.isCap ? 2 : 0);
  for (let k = 0; k < n; k++) {
    const rt = rts[(k + ct.id) % rts.length], sp = 5 + (k * 7 % 4), s = tm * sp + k * 53 + ct.id * 17, pos = routePos(rt, s), st = Math.floor(tm * 4 + k) & 1;
    const x = ox + pos[0] * 0.5, y = oy + pos[1] * 0.5, cl = VCLOTH[(k * 5 + ct.id) % VCLOTH.length];
    R_(c, x - 0.7, y + 0.3, 1.5, 0.5, 'rgba(0,0,0,.25)'); R_(c, x - 0.5, y - 0.8 + (st ? 0 : 0.2), 0.5, 1.1, '#3a2a18'); R_(c, x + 0.1, y - 0.8 + (st ? 0.2 : 0), 0.5, 1.1, '#3a2a18');
    R_(c, x - 0.6, y - 2.1, 1.3, 1.5, cl); R_(c, x - 0.4, y - 3.1, 0.9, 1, '#e8c49a'); R_(c, x - 0.5, y - 3.3, 1.1, 0.5, k % 2 ? '#6a4a28' : '#d8b858');
  }
}
