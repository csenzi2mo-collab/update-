'use strict';
/* ===== MODS: menu modifikasi (khusus mode offline / satu pemain) =====
   Fitur: bangun instan, latih pasukan instan, pasukan lebih kuat, sumber daya penuh,
   AI ambil alih kerajaan
   (auto dagang, auto militer, mode damai / normal / agresif), dan rumah yang tumbuh sesuai zona kota.
   Di mode jaringan (ПО СЕТИ) semuanya otomatis nonaktif, karena simulasi game berjalan lockstep
   dan modifikasi sepihak akan membuat semua pemain desync. */
const RF_GOODS = [{ n: 'kayu', m: 1 }, { n: 'makanan', m: 0.9 }, { n: 'besi', m: 1.3 }];   // barang kafilah dagang
const MODS = {
  cfg: { build: false, train: false, power: 1, rich: false, night: 0.18, auto: false, autoTrade: true, autoMil: true, aiMode: 'normal', house: true, autoPort: true, autoVillage: true, caravan: true, god: false },
  last: '', godLock: null,
  L: { archer: 'Pemanah', light: 'Ksatria Ringan', heavy: 'Ksatria Berat', cav: 'Kavaleri', cat: 'Katapel', ram: 'Pendobrak' },
  load() { try { const o = JSON.parse(localStorage.getItem('kc_mods') || '{}'); for (const k in this.cfg) if (typeof o[k] === typeof this.cfg[k]) this.cfg[k] = o[k]; } catch (e) { } },
  save() { try { localStorage.setItem('kc_mods', JSON.stringify(this.cfg)); } catch (e) { } },
  online() { return typeof NET !== 'undefined' && !!NET.active; },
  live() { return !!(UI.S && !UI.S.over && !this.online() && UI.S.players[VP]); },
  // AI ambil alih: memakai otak bot yang sudah ada untuk pemain; dimatikan = kembalikan tingkat kesulitan asli
  applyAI(S) {
    const p = S.players[VP]; if (!p || !this.live()) return;
    if (this.cfg.auto) {
      if (p._d0 === undefined) p._d0 = p.diff;
      p.diff = { peaceful: 'easy', normal: 'normal', aggressive: 'hard' }[this.cfg.aiMode] || 'normal';
      p.peaceful = this.cfg.aiMode === 'peaceful'; p.autoTrade = this.cfg.autoTrade; p.autoMil = this.cfg.autoMil; p.autoPort = this.cfg.autoPort; p.autoVillage = this.cfg.autoVillage; p.milJobs = this.cfg.autoMil;
      if (!p.ai) p.ai = { next: 0, fails: {} };
      aiThink(S, p);
    } else if (p._d0 !== undefined) {
      p.diff = p._d0; delete p._d0; p.peaceful = false; p.autoTrade = undefined; p.autoMil = undefined; p.autoPort = undefined; p.autoVillage = undefined; p.milJobs = undefined;
    }
  },
  // rumah bertambah satu tiap hari (DAY detik), berhenti saat mencapai batas zona kota
  grow(S, dt) {
    if (!this.cfg.house || !this.live()) return;
    for (const c of S.cities) {
      if (c.owner !== VP || !(c.level >= 1)) continue;
      const base = [0, 6, 8, 10, 12, 14][Math.min(5, c.level)];
      const room = Math.min(TSLOT.length - base, Math.floor(Math.max(0, c.radius - 4) * 2));
      c.hx = c.hx | 0;
      if (c.hx >= room) { c.hgrow = 0; continue; }
      c.hgrow = (c.hgrow || 0) + dt;
      if (c.hgrow >= DAY * (1 - Math.min(0.3, techSum(S, 'build')))) { c.hgrow = 0; c.hx++; say('Kota ' + c.name + ' bertambah satu rumah.', true); }
    }
  },
  // ----- otak AI: diplomasi, jawaban tawaran, perang (sesuai mode), dan jembatan
  brain(S) {
    if (!this.cfg.auto || !this.live()) return;
    if (S.time < (S._brain || 0)) return; S._brain = S.time + DAY / 4;
    const p = S.players[VP];
    try { aiDiplomacy(S, p); } catch (e) { }
    for (const m of S.msgs.slice()) {
      if (m.to !== VP || m.done || !m.kind || m.from === undefined || m.from < 0) continue;
      if (!['trade', 'ally', 'pass', 'truce', 'ult'].includes(m.kind)) continue;
      try { answerMsg(S, m.id, this.decide(S, m), VP); } catch (e) { }
    }
    if (this.cfg.aiMode === 'aggressive') {
      const pm = govSifat(S, 'Menteri Perang'), kk = pm.includes('Pemberani') ? 0.75 : pm.includes('Hati-hati') ? 1.2 : 0.9;
      for (const q of S.players) {
        if (q.id === VP || !q.alive) continue;
        const r = rel(S, VP, q.id), ci = claimInfo(S, VP, q.id);
        if (r.st === 'peace' && !r.ally && ci && ci.ready && milPower(S, VP) >= milPower(S, q.id) * kk) { declareWar(S, VP, q.id); break; }
      }
    }
    if (this.cfg.autoMil) this.milJobs(S);
  },
  // keputusan atas tawaran masuk, mengikuti mode AI
  decide(S, m) {
    const f = m.from, r = rel(S, VP, f), mode = this.cfg.aiMode, mine = milPower(S, VP), theirs = milPower(S, f);
    const ln = govSifat(S, 'Menteri Luar Negeri'), ek = govSifat(S, 'Menteri Ekonomi');
    if (m.kind === 'trade') return r.st === 'peace' && !r.trade && r.op > (ek.includes('Serakah') ? 10 : mode === 'peaceful' ? -50 : -35);
    if (m.kind === 'ally') return r.st === 'peace' && !r.ally && r.op >= (ln.includes('Ramah') ? 0 : mode === 'peaceful' ? 0 : 10) && (r.trade || mode === 'peaceful');
    if (m.kind === 'pass') return r.st !== 'war' && (r.op >= 0 || r.trade);
    if (m.kind === 'truce') return !ln.includes('Pendendam') && r.st === 'war' && (mode === 'aggressive' ? mine < theirs * 0.9 : (S.time - r.warSince > 150 || mine < theirs * 0.9));
    if (m.kind === 'ult') return mode !== 'aggressive' && S.players[VP].stock.gold >= 150 && mine * 1.4 >= theirs;
    return false;
  },
  // jalur darat (tanpa air, gunung, atau bangunan) dari kota a ke kota b
  landPath(S, a, b) {
    const W = S.W, n = W * S.H, start = a.y * W + a.x, goal = b.y * W + b.x, par = new Int32Array(n).fill(-2), q = new Int32Array(n); let h = 0, t = 0;
    par[start] = -1; q[t++] = start;
    while (h < t) {
      const i = q[h++]; if (i === goal) break;
      const x = i % W, y = (i / W) | 0;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= W || ny >= S.H) continue;
        const j = ny * W + nx; if (par[j] !== -2) continue;
        const tt = S.ter[j]; if (isWater(tt) || tt === TR.MOUNT) continue;
        if (j !== goal && S.occ[j] >= 0 && S.occ[j] < 1000000) continue;   // bangunan menghalangi; area kota boleh dilewati
        par[j] = i; q[t++] = j;
      }
    }
    if (par[goal] === -2) return null;
    const out = []; for (let i = goal; i !== -1; i = par[i]) out.push([i % W, (i / W) | 0]);
    return out.reverse();
  },
  // god mode: kota yang dipilih dikunci pada tingkat berontak/korupsi yang diatur
  godTick(S) {
    const g = this.godLock; if (!this.cfg.god || !g || !S || S !== UI.S) return;
    const c = S.cities.find(q => q.id === g.id); if (!c) return;
    if (g.unrest !== null) c.unrest = g.unrest;
    if (g.kor !== null) for (const o of villageOfficials(S, c)) o.kor = g.kor;
  },
  // kafilah dagang: kuda dan pedagang berjalan di darat ke kota mitra dagang, lalu membawa emas
  caravans(S, dt) {
    if (!this.live()) return;
    S._car = S._car || [];
    const pa = S.players[VP];
    for (const car of S._car.slice()) {
      if (car.kind !== 'envoy') { const rr = rel(S, VP, car.to); if (!rr || !rr.trade || rr.st !== 'peace') { S._car.splice(S._car.indexOf(car), 1); continue; } }
      car.s += car.v * dt;
      if (car.kind !== 'envoy' && !car.robbed) {
        // perampok mengintai jalur: pengawal hanya mengurangi peluang, kafilah tetap bisa dirampok
        const at = car.path[Math.min(car.path.length - 1, Math.floor(car.s))];
        const esc = at ? soldiersNear(S, VP, at[0], at[1], 6) : 0;
        if (S.rnd() < dt / DAY * (esc ? 0.7 : 1.6)) {
          car.robbed = true; S._car.splice(S._car.indexOf(car), 1);
          say(esc ? 'Kafilah dagang dirampok walau dikawal! Barang dan emas hilang' : 'Kafilah dagang dirampok perampok! Barang dan emas hilang', false);
          continue;
        }
      }
      if (car.s >= car.path.length - 1) {
        if (car.kind === 'envoy') {
          const q = (S.pending || []).find(x => x.eid === car.eid); if (q) q.at = S.time;
          const ln = govSifat(S, 'Menteri Luar Negeri'), r = rel(S, VP, car.to);
          if (r) r.op += ln.includes('Ramah') ? 4 : ln.includes('Pendendam') ? -6 : 1;
          say('Utusan tiba di ' + S.players[car.to].name + ': tawaran segera diputuskan', true);
        } else {
          // harga barang berbeda di tiap kota tujuan
          const dc = S.cities.find(q => q.id === car.dst), good = car.good || RF_GOODS[0];
          const f = [0.8, 1.0, 1.25][dc ? (dc.id + Math.round(good.m * 10)) % 3 : 1];
          const g = Math.round(car.gold * good.m * f * (1 + techSum(S, 'trade')));
          pa.stock.gold = (pa.stock.gold || 0) + g; say('Kafilah tiba membawa ' + good.n + ': +' + g + ' emas', true);
        }
        S._car.splice(S._car.indexOf(car), 1);
      }
    }
    for (const p of S.pending || []) {
      if (p.env || p.from !== VP) continue; p.env = 1; p.eid = Math.floor(S.rnd() * 1e9) + 1;
      const from = S.cities.find(q => q.isCap && q.owner === VP), to = S.cities.find(q => q.isCap && q.owner === p.to);
      if (!from || !to) continue;
      const path = this.landPath(S, from, to);
      if (!path || path.length > 200) { say('Utusan tidak bisa sampai ke ' + S.players[p.to].name + ': tidak ada jalur darat', false); continue; }
      p.at = 1e15;   // tawaran ditahan sampai utusan tiba
      S._car.push({ kind: 'envoy', path, s: 0, v: 1.5, gold: 0, to: p.to, eid: p.eid });
    }
    if (this.cfg.caravan && (S._carNext === undefined || S.time >= S._carNext)) {
      S._carNext = S.time + DAY * 0.75;
      if (S._car.filter(q => q.kind !== 'envoy').length < 4) {
        const mine = S.cities.filter(c => c.owner === VP);
        search: for (const c of mine) for (const d of S.cities) {
          if (d.owner === VP || d.owner < 0) continue;
          const r = rel(S, VP, d.owner); if (!r || !r.trade || r.st !== 'peace') continue;
          if (S.comp[d.y * S.W + d.x] !== S.comp[c.y * S.W + c.x] || Math.hypot(d.x - c.x, d.y - c.y) > 60) continue;
          const key = c.id + '-' + d.id; S._pc = S._pc || {}; let pc = S._pc[key];
          if (!pc || S.time - pc.t > DAY * 2) { const p0 = this.landPath(S, c, d); pc = S._pc[key] = { t: S.time, path: p0 && p0.length <= 140 ? p0 : null }; }
          if (!pc.path) continue;
          const path = pc.path;
          S._car.push({ path, s: 0, v: 1.1, gold: 20 + Math.floor(path.length / 4), to: d.owner, dst: d.id, good: RF_GOODS[Math.floor(S.rnd() * RF_GOODS.length)] });
          break search;
        }
      }
    }
  },
  // pekerjaan pasukan selain pasukan utama: jaga kota yang belum ada penjaga, atau patroli di jalan
  milJobs(S) {
    const my = S.armies.filter(a => a.owner === VP && !a.ship); if (my.length < 2) return;
    const main = my.slice().sort((a, b) => units(b) - units(a))[0], cities = S.cities.filter(c => c.owner === VP);
    for (const a of my) {
      if (a === main || a.st !== 'idle' || a.path.length || a.fight) continue;
      if (a.jobT !== undefined && S.time - a.jobT < DAY / 2) continue;
      let best = null, bd = 1e9;
      for (const c of cities) {
        if (!c.isCap && villageOfficials(S, c)[1].izin === false) continue;   // gubernur tanpa izin militer tidak meminta pasukan
        if (my.some(o => o !== a && dist(o.x, o.y, c.x + 1, c.y + 1) < 3)) continue;
        const d = dist(a.x, a.y, c.x + 1, c.y + 1) - (c.guard ? 40 : 0); if (d < bd) { bd = d; best = c; }
      }
      let job = null, tx = 0, ty = 0;
      if (best) { job = 'jaga'; tx = best.x + 1; ty = best.y + 1; }
      else if (cities.length) { const c = cities[Math.floor(S.rnd() * cities.length)], px = c.x + Math.round((S.rnd() - 0.5) * 8), py = c.y + Math.round((S.rnd() - 0.5) * 8); if (px > 1 && py > 1 && px < S.W - 2 && py < S.H - 2 && !isWater(S.ter[py * S.W + px]) && S.ter[py * S.W + px] !== TR.MOUNT) { job = 'patroli'; tx = px + 0.5; ty = py + 0.5; } }
      if (!job) continue;
      orderMove(S, a, tx, ty); a.job = job; a.jobT = S.time; a.jobN = best ? best.name : null;
    }
  },
  // gambar: kuda kafilah & utusan, dan pejabat (ukuran seperti warga, nama di atas kepala)
  draw(c, S, vx0, vx1, vy0, vy1) {
    if (!S || S !== UI.S || this.online()) return;
    if (RN.cam && RN.cam.z < 0.7) return;   // terlalu jauh: pejabat tidak terlihat, lewati semua
    const tm = S.time, gm = new Map(), vm = new Map();
    const gOf = pid => { let g = gm.get(pid); if (!g) { g = govOf(S, pid); gm.set(pid, g); } return g; };
    const vOf = ct => { let v = vm.get(ct); if (!v) { v = villageOfficials(S, ct); vm.set(ct, v); } return v; };
    const inV = (x, y) => x >= vx0 - 2 && x <= vx1 + 2 && y >= vy0 - 2 && y <= vy1 + 2;
    for (const p of S.players) {
      if (!p.alive) continue;
      const ct = S.cities.find(q => q.isCap && q.owner === p.id); if (!ct || !inV(ct.x, ct.y)) continue;
      try {
        const g = gOf(p.id), names = [g.ruler.name].concat(g.ministers.map(m => m.name)), rts = townPlan(ct.level, ct.isCap, ct.vs | 0, ct.hx | 0).paths, ox = (ct.x - 1) * TS, oy = (ct.y - 1) * TS;
        for (let k = 0; k < names.length; k++) {
          if ([g.ruler].concat(g.ministers)[k].trip) continue;
          const ok = rts.length && rts[(k + ct.id) % rts.length] && rts[(k + ct.id) % rts.length].length > 1;
          const pos = ok ? routePos(rts[(k + ct.id) % rts.length], tm * (4 + (k % 3)) + k * 53 + ct.id * 17) : [0, 0];
          drawPerson(c, ox + pos[0] * 0.5 + (ok ? 0 : (k - 2) * 4), oy + pos[1] * 0.5 + (ok ? 0 : 36), p.col, names[k], k === 0);
        }
      } catch (e) { }
    }
    for (const ct of S.cities) {
      if (ct.isCap || ct.owner < 0 || !S.players[ct.owner].alive || !inV(ct.x, ct.y)) continue;
      const rts = townPlan(ct.level, false, ct.vs | 0, ct.hx | 0).paths, ox = (ct.x - 1) * TS, oy = (ct.y - 1) * TS;
      try {
        vOf(ct).forEach((o, k) => {
          if (o.trip) return;
          const ok = rts.length && rts[(k + ct.id) % rts.length] && rts[(k + ct.id) % rts.length].length > 1;
          const pos = ok ? routePos(rts[(k + ct.id) % rts.length], tm * 4 + k * 40 + ct.id * 13) : null;
          const px = pos ? ox + pos[0] * 0.5 : ox + 40 + (k ? 10 : -10) + Math.sin(tm + k) * 3, py = pos ? oy + pos[1] * 0.5 : oy + 52;
          drawPerson(c, px, py, S.players[ct.owner].col, o.name, false);
        });
      } catch (e) { }
    }
    // pejabat yang berjalan kaki: menteri ekonomi (kafilah dagang) dan menteri luar negeri (utusan)
    const pm = gOf(VP).ministers, nEco = (pm.find(m => m.t === 'Menteri Ekonomi') || {}).name || 'Pedagang', nLn = (pm.find(m => m.t === 'Menteri Luar Negeri') || {}).name || 'Utusan';
    for (const car of S._car || []) {
      const k = Math.min(car.path.length - 1, Math.floor(car.s)), f = car.s - Math.floor(car.s), p0 = car.path[k], p1 = car.path[Math.min(car.path.length - 1, k + 1)];
      const cx = p0[0] + (p1[0] - p0[0]) * f + 0.5, cy = p0[1] + (p1[1] - p0[1]) * f + 0.5;
      if (!inV(cx, cy)) continue;
      drawPerson(c, cx * TS, cy * TS, S.players[VP].col, car.kind === 'envoy' ? nLn : nEco, car.kind === 'envoy');
    }
  },
  tick(S) {
    if (!this.live() || S !== UI.S) return; const p = S.players[VP], c = this.cfg;
    if (c.build) {
      let fin = false;
      for (const b of S.buildings) if (b.owner === VP && b.cons > 0) { b.cons = 0; fin = true; say(BD[b.type].n + ' siap.', true); }
      if (fin) { refreshStructs(S); if (S.buildings.some(b => b.type === 'moat')) recomputeMoat(S); calcRates(S); S.dirtyT = true; }
    }
    if (c.train) for (const b of S.buildings) if (b.owner === VP && b.queue && b.queue.length) for (const q of b.queue) q.left = 0;
    if (c.rich) for (const k of STOCK_KEYS) if ((p.stock[k] || 0) < 9999) p.stock[k] = 9999;
  }
};
MODS.load();

/* tombol MODS mengambang di dalam permainan (hanya tampil saat offline berjalan) */
function rfFab(id, act, icon, label, top) {
  const hud = document.getElementById('hud'); if (!hud) return null;
  let b = document.getElementById(id);
  if (!b) {
    b = document.createElement('button'); b.id = id; b.className = 'px rf-fab'; b.dataset.act = act;
    b.innerHTML = IMG(icon, 28) + '<div class="lbl">' + label + '</div>'; hud.appendChild(b);
  }
  return b;
}
function modsFab() {
  const b = rfFab('modFab', 'mods', 'menu', 'MODS', ''); if (!b) return;
  const on = MODS.live(); if (on !== modsFab._on) { b.style.display = on ? 'flex' : 'none'; modsFab._on = on; }
}
(function () {
  const _tick = tick;
  tick = function (S, dt) {
    try { modsFab(); } catch (e) { }
    try { techFab(); } catch (e) { }
    try { MODS.techTick(S, dt); } catch (e) { }
    try { techLive(S); } catch (e) { }
    try { MODS.tick(S); } catch (e) { }
    try { MODS.applyAI(S); } catch (e) { }
    try { MODS.grow(S, dt); } catch (e) { }
    try { MODS.caravans(S, dt); } catch (e) { }
    try { MODS.godTick(S); } catch (e) { }
    try { MODS.govTick(S); } catch (e) { }
    try { MODS.events(S); } catch (e) { }
    try { MODS.brain(S); } catch (e) { }
    return _tick(S, dt);
  };
})();

/* ----- tampilan menu Mods ----- */
function modsRender(keepScroll) {
  const c = MODS.cfg, live = MODS.live(), bd0 = document.querySelector('#modal .bd'), sc = keepScroll && bd0 ? bd0.scrollTop : 0;
  const tog = (k, name, desc) => `<button class="mrow ${c[k] ? 'on' : ''}" data-act="modtog:${k}"><span class="mt"><b>${name}</b><i>${desc}</i></span><span class="sw2"></span></button>`;
  const seg = (act, vals, cur, f) => `<div class="mseg">${vals.map(v => `<button class="${cur === v || +cur === v ? 'on' : ''}" data-act="${act}:${v}">${f(v)}</button>`).join('')}</div>`;
  const note = MODS.last || (MODS.online() ? 'Mode online terdeteksi: Mods dimatikan.' : (live ? 'Permainan offline aktif. Perubahan langsung berlaku.' : 'Atur dulu di sini; mod butuh permainan yang sedang berjalan.'));
  const ai = `<div class="mh">AI ambil alih kerajaan</div>${tog('auto', 'AI ambil alih', 'Bot mengatur kerajaanmu: bangun, latih, serang, dan dagang')}` +
    `${seg('modai', ['peaceful', 'normal', 'aggressive'], c.aiMode, v => ({ peaceful: 'Damai', normal: 'Normal', aggressive: 'Agresif' })[v])}` +
    `<div class="mhint">Damai: tidak pernah menyatakan perang. Normal: seperti AI biasa. Agresif: sering menyatakan perang sesuai hubungan.</div>` +
    `${tog('autoTrade', 'Auto dagang', 'AI membuat kapal dagang dan kesepakatan dagang')}${tog('autoMil', 'Auto militer', 'AI melatih dan menggerakkan pasukan')}` +
    `${tog('autoPort', 'Pelabuhan otomatis', 'AI membangun pelabuhan di pantai yang cocok')}${tog('autoVillage', 'Auto desa', 'AI membuat desa baru di tanah kosong dekat wilayah kita')}${tog('caravan', 'Kafilah dagang darat', 'Kuda dan pedagang berjalan ke kota mitra dagang')}`;
  const city = `<div class="mh">Kota</div>${tog('house', 'Rumah tumbuh sesuai zona', 'Setiap hari bertambah satu rumah, dibatasi luas zona kota')}` +
    `<div class="mhint">Pasar, pelabuhan, dan bangunan lain ikut dibangun otomatis saat AI ambil alih aktif. Struktur pemerintahan ada di menu Diplomasi.</div>`;
  const S = UI.S, mine = live && S ? S.cities.filter(q => q.owner === VP) : [];
  const gl = MODS.godLock, gsel = gl ? gl.id : -1;
  const godList = mine.length ? `<div class="mseg">${mine.map(q => `<button class="${q.id === gsel ? 'on' : ''}" data-act="godpick:${q.id}">${q.name}</button>`).join('')}</div>` : `<div class="mhint">Belum ada kota. Mulai permainan offline dulu.</div>`;
  const godSet = `<div class="mseg"><button data-act="godset:unrest">Berontak</button><button data-act="godset:calm">Tenang</button><button data-act="godset:corrupt">Korupsi</button><button data-act="godset:clean">Bersih</button></div>`;
  const godHtml = `<div class="mh">God Mode</div>${tog('god', 'God Mode aktif', 'Kunci pengaturan kota di bawah setiap hari')}` +
    `<div class="mhint">Pilih kota atau desa:</div>${godList}` +
    `<div class="mhint">Atur kota terpilih: berontak/tenang (kerusuhan) atau korupsi/bersih (pejabat).</div>${godSet}` +
    `<div class="mhint">${gl && mine.some(q => q.id === gl.id) ? 'Terkunci: ' + (mine.find(q => q.id === gl.id) || {}).name : 'Belum ada kota terkunci.'}</div>`;
  const body = `<div class="mods">\n    <div class="mnote">${note}</div>\n    <div class="mh">Percepatan</div>\n    ${tog('build', 'Bangun instan', 'Semua bangunan (barak dll.) jadi dalam 0 detik')}\n    ${tog('train', 'Latih instan', 'Antrean pasukan di barak langsung keluar')}\n    <div class="mh">Penerangan malam</div>\n    ${seg('modnight', [0, 0.18, 0.4], c.night, v => v === 0 ? 'Asli' : v === 0.18 ? 'Terang' : 'Sangat terang')}\n    <div class="mhint">Malam lebih terang, plus cahaya hangat di sekeliling rumah dan kerajaan. Hanya tampilan, tidak memengaruhi game.</div>\n    <div class="mh">Sumber daya</div>\n    ${tog('rich', 'Sumber daya penuh', 'Semua stok dijaga minimal 9999')}\n    ${ai}\n    ${city}\n    ${godHtml}\n  </div>`;
  showModal('MODS', body, btn('modreset', 'Reset') + btn('closemodal', 'Tutup', 'gold'));
  const bd = document.querySelector('#modal .bd'); if (bd) bd.scrollTop = sc;
}
Object.assign(ACT, {
  mods() { MODS.last = ''; modsRender(false); },
  modnight(v) { MODS.cfg.night = +v || 0; MODS.save(); modsRender(true); },
  modtog(k) { if (k in MODS.cfg && typeof MODS.cfg[k] === 'boolean') { MODS.cfg[k] = !MODS.cfg[k]; MODS.save(); } modsRender(true); },
  modai(v) { if (['peaceful', 'normal', 'aggressive'].includes(v)) MODS.cfg.aiMode = v; MODS.save(); modsRender(true); },
  godpick(id) { const S = UI.S; if (!S) return; const c = S.cities.find(q => q.id === +id); if (!c) return; MODS.godLock = Object.assign({ id: c.id, unrest: null, kor: null }, MODS.godLock && MODS.godLock.id === c.id ? MODS.godLock : {}); MODS.last = 'Kota dipilih: ' + c.name; modsRender(true); },
  godset(m) {
    const S = UI.S, g = MODS.godLock; if (!S || !g) return say('Pilih kota dulu', false);
    const c = S.cities.find(q => q.id === g.id); if (!c) return;
    if (m === 'unrest') g.unrest = 100; else if (m === 'calm') g.unrest = 0;
    else if (m === 'corrupt') g.kor = 100; else if (m === 'clean') g.kor = 0;
    MODS.godTick(S); MODS.last = c.name + ': ' + ({ unrest: 'berontak', calm: 'tenang', corrupt: 'korupsi', clean: 'bersih' })[m];
    modsRender(true);
  },
  modreset() { Object.assign(MODS.cfg, { build: false, train: false, power: 1, rich: false, night: 0.18, auto: false, autoTrade: true, autoMil: true, aiMode: 'normal', house: true, autoPort: true, autoVillage: true, caravan: true, god: false }); MODS.godLock = null; MODS.save(); modsRender(true); }
});

/* ketuk peta: ketuk pasukan terpilih = batal pilih; ketuk zona kita yang punya pasukan = pasukan terdekat otomatis terpilih */
(function () {
  const _mt = UI.mapTap;
  UI.mapTap = function (tx, ty) {
    const S = UI.S;
    if (S && MODS.live() && !RN.place && !S.over) {
      const cur = RN.sel, near = a => !a.ship && dist(a.x, a.y, tx, ty) < 0.6;
      if (cur && cur.k === 'army') {
        const sel = S.armies.find(a => a.id === cur.id);
        if (sel && near(sel)) { RN.sel = null; closeSheet(); return; }
      } else {
        const o = S.terr[Math.floor(ty) * S.W + Math.floor(tx)];
        if (o === VP) {
          let best = null, bd = 4;
          for (const a of S.armies) if (a.owner === VP && !a.ship) { const d = dist(a.x, a.y, tx, ty); if (d < bd) { bd = d; best = a; } }
          if (best) return _mt.call(this, best.x, best.y);
        }
      }
    }
    return _mt.call(this, tx, ty);
  };
})();

/* ----- penerangan malam: terang malam + kolam cahaya hangat di sekitar rumah, kota & bangunan ----- */
const LIT_BLD = { barracks: 1, workshop: 1, stable: 1, port: 1, farm: 1, sawmill: 1, mine: 1, academy: 1, hospital: 1, market: 1, siege: 1, forge: 1, tower: 1 };
let NIGHT_GLOW = null, NIGHT_POOL = null;
function nightLift(tn) { const k = MODS.cfg.night; if (!k) return tn; return [tn[0] + (255 - tn[0]) * k, tn[1] + (255 - tn[1]) * k, tn[2] + (255 - tn[2]) * k]; }
function nightSprites() {
  if (NIGHT_GLOW) return;
  const mk = (n, stops) => { const cv = newCv(n, n), x = cv.getContext('2d'), g = x.createRadialGradient(n / 2, n / 2, 0, n / 2, n / 2, n / 2); for (const s of stops) g.addColorStop(s[0], s[1]); x.fillStyle = g; x.fillRect(0, 0, n, n); return cv; };
  NIGHT_GLOW = mk(48, [[0, 'rgba(255,220,130,1)'], [.3, 'rgba(255,180,80,.5)'], [1, 'rgba(255,140,40,0)']]);
  NIGHT_POOL = mk(96, [[0, 'rgba(255,196,110,.55)'], [.5, 'rgba(255,170,80,.22)'], [1, 'rgba(255,150,60,0)']]);
}
function nightGlowPass(c, S, dark, vx0, vx1, vy0, vy1) {
  nightSprites(); const raw = Math.max(0, Math.min(1, (255 - todTint(todHours(S))[1]) / 150));
  const prev = c.globalCompositeOperation; c.globalCompositeOperation = 'lighter';
  const fl = 0.93 + 0.07 * Math.sin(S.time * 4), A = Math.min(1, raw * 1.1) * fl;
  for (const ct of S.cities) {
    if (ct.x < vx0 - 6 || ct.x > vx1 + 4 || ct.y < vy0 - 6 || ct.y > vy1 + 4) continue;
    const ox = cityOX(ct), oy = cityOY(ct), pl = townPlan(ct.level, ct.isCap, ct.vs | 0, ct.hx | 0), R = 70 + (ct.level | 0) * 14;
    c.globalAlpha = A * 0.55; c.drawImage(NIGHT_POOL, ox + 32 - R, oy + 34 - R, R * 2, R * 2);          // cahaya menyebar ke tanah sekitar kota
    c.globalAlpha = A * 0.4; for (const L of pl.lights) c.drawImage(NIGHT_GLOW, ox + L[0] * 0.5 - 10, oy + L[1] * 0.5 - 10, 21, 21);
  }
  for (const b of S.buildings) {
    if (b.x < vx0 - 3 || b.x > vx1 + 2 || b.y < vy0 - 3 || b.y > vy1 + 2 || b.cons > 0 || !LIT_BLD[b.type]) continue;
    c.globalAlpha = A * 0.45; c.drawImage(NIGHT_POOL, b.x * TS + 8 - 26, b.y * TS + 10 - 26, 52, 52);
    c.globalAlpha = A * 0.4; c.drawImage(NIGHT_GLOW, b.x * TS + 8 - 11, b.y * TS + 10 - 11, 22, 22);
  }
  c.globalCompositeOperation = prev;
}

/* ===== Pemerintahan: raja/ratu dan pejabat tiap kerajaan, walikota dan gubernur tiap desa =====
   Tokoh disimpan di S._gov (dibuat dari seed, lalu bisa berubah). Sifat berubah sendiri sesuai keadaan. */
const GOV_NAMA = ['Adrik', 'Selene', 'Bramwin', 'Ivarra', 'Kael', 'Maelis', 'Torvan', 'Riana', 'Dareus', 'Lysa', 'Gorran', 'Helvin', 'Sorin', 'Mirelle', 'Caedan', 'Thessa'];
const SIFAT = ['Pemberani', 'Hati-hati', 'Licik', 'Jujur', 'Ambisius', 'Setia', 'Pragmatis', 'Pendendam', 'Ramah', 'Serakah', 'Bijaksana', 'Pemalas'];
const SIFAT_KET = { Pemberani: 'suka perang', 'Hati-hati': 'lambat menyatakan perang', Licik: 'sering berubah sikap', Jujur: 'menepati janji', Ambisius: 'ingin wilayah lebih luas', Setia: 'setia pada raja', Pragmatis: 'menimbang untung rugi', Pendendam: 'tidak mau gencatan senjata', Ramah: 'mudah berdamai dan bersekutu', Serakah: 'hanya mau dagang yang menguntungkan', Bijaksana: 'tenang dalam mengambil keputusan', Pemalas: 'bekerja lambat' };
// kabinet ibu kota: raja/ratu + 4 menteri = 5 pejabat
const GOV_JABATAN = [
  { t: 'Perdana Menteri', r: 'Mengatur arah kerajaan', key: 'mode', atasan: 'Raja' },
  { t: 'Menteri Perang', r: 'Pasukan dan pertahanan', key: 'autoMil', atasan: 'Perdana Menteri' },
  { t: 'Menteri Ekonomi', r: 'Perdagangan, pajak, dan kafilah', key: 'autoTrade', atasan: 'Perdana Menteri' },
  { t: 'Menteri Luar Negeri', r: 'Aliansi, perang, dan perjanjian', key: 'auto', atasan: 'Perdana Menteri' }
];
// efek sifat yang benar-benar dipakai AI kita
const SIFAT_EFEK = {
  'Menteri Perang': { Pemberani: 'menyatakan perang lebih cepat', 'Hati-hati': 'menyatakan perang lebih lambat' },
  'Menteri Luar Negeri': { Pendendam: 'menolak gencatan senjata', Ramah: 'mudah menerima aliansi' },
  'Menteri Ekonomi': { Serakah: 'hanya menerima dagang yang untung besar' }
};
function govHash(str) { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h >>> 0; }
// tokoh tersimpan: dibuat sekali dari seed, lalu dipakai terus (sifatnya bisa berubah)
function govChar(S, key, gelar, t, atasan, owner) {
  S._gov = S._gov || {};
  if (!S._gov[key]) {
    let h = govHash(S.seed + '|' + key); const rnd = () => { h = (Math.imul(h, 1103515245) + 12345) >>> 0; return h / 4294967296; };
    const sf = []; while (sf.length < 2) { const x = SIFAT[Math.floor(rnd() * SIFAT.length)]; if (!sf.includes(x)) sf.push(x); }
    S._gov[key] = { gelar, t, atasan, owner, name: GOV_NAMA[Math.floor(rnd() * GOV_NAMA.length)], umur: 28 + Math.floor(rnd() * 36), sifat: sf, loyal: 30 + Math.floor(rnd() * 66) };
  }
  return S._gov[key];
}
function govOf(S, pid) {
  const gelar = (govHash(S.seed + '|g' + pid) & 1) ? 'Raja' : 'Ratu';
  const ruler = govChar(S, pid + '|raja', gelar, 'Raja', null, pid);
  const ministers = GOV_JABATAN.map(j => Object.assign({ key: j.key, r: j.r }, govChar(S, pid + '|' + j.t, j.t, j.t, j.atasan, pid)));
  return { ruler, ministers };
}
// walikota dan gubernur tiap desa (dua pejabat per desa)
function villageOfficials(S, ct) {
  const o = [govChar(S, 'v' + ct.id + '|walikota', 'Walikota', 'Walikota', 'Gubernur', ct.owner), govChar(S, 'v' + ct.id + '|gubernur', 'Gubernur', 'Gubernur', 'Perdana Menteri', ct.owner)];
  for (const k of ct.vx || []) if (S._gov[k]) o.push(S._gov[k]);   // pejabat rekrutan gubernur
  for (const x of o) if (x.izin === undefined) x.izin = x.loyal >= 45;   // izin militer: diberikan kepada pejabat yang setia
  return o;
}
// pajak harian satu desa: tiap pejabat membayar sesuai loyalitasnya
function taxLvOf(c) { return c.taxLv === undefined ? 1 : c.taxLv | 0; }
function villageTax(S, ct) {
  const f = [0.5, 1, 1.6][taxLvOf(ct)];
  return Math.round(villageOfficials(S, ct).reduce((a, o) => a + 4 + (o.loyal > 70 ? 2 : 0) - (o.loyal < 45 ? 2 : 0), 0) * f);
}
// sifat seorang pejabat di kerajaan kita (dipakai AI saat memutuskan)
function govSifat(S, role) {
  const g = govOf(S, VP); if (role === 'Raja') return g.ruler.sifat;
  const m = g.ministers.find(x => x.t === role); return m ? m.sifat : [];
}
// sifat berubah sendiri setiap hari game: satu pejabat acak, dipengaruhi perang atau dagang
MODS.govTick = function (S) {
  if (!S._gov || this.online() || !S.players[VP] || (S._govNext !== undefined && S.time < S._govNext)) return;
  S._govNext = S.time + DAY;
  const tax = {};
  for (const ct of S.cities) if (!ct.isCap && ct.owner >= 0 && S.players[ct.owner].alive) { const t = villageTax(S, ct); tax[ct.owner] = (tax[ct.owner] || 0) + t; S.players[ct.owner].stock.gold = (S.players[ct.owner].stock.gold || 0) + t; }
  if (tax[VP]) noteRoutine(S, 'Pajak desa masuk ke ibu kota: +' + tax[VP] + ' emas');
  // pajak tinggi membuat pejabat desa kecewa, pajak rendah membuat mereka senang
  for (const ct of S.cities) if (!ct.isCap && ct.owner === VP) for (const o of villageOfficials(S, ct)) o.loyal = Math.max(10, Math.min(100, o.loyal + (taxLvOf(ct) === 2 ? -1 : taxLvOf(ct) === 0 ? 1 : 0)));
  const keys = Object.keys(S._gov); if (!keys.length) return;
  const ch = S._gov[keys[Math.floor(S.rnd() * keys.length)]], owner = ch.owner;
  if (owner === undefined || owner < 0 || !S.players[owner] || !S.players[owner].alive) return;
  const war = S.players.some(q => q.id !== owner && q.alive && atWar(S, owner, q.id));
  const trade = S.players.some(q => q.id !== owner && q.alive && rel(S, owner, q.id).trade);
  const pool = [];
  for (const x of SIFAT) if (!ch.sifat.includes(x)) {
    let w = 1;
    if (war && ['Pemberani', 'Licik', 'Ambisius'].includes(x)) w += 3;
    if (!war && ['Ramah', 'Jujur', 'Setia'].includes(x)) w += 2;
    if (trade && ['Serakah', 'Pragmatis'].includes(x)) w += 3;
    pool.push([x, w]);
  }
  let r = S.rnd() * pool.reduce((a, b) => a + b[1], 0), pick = pool[0][0];
  for (const [x, w] of pool) { r -= w; if (r <= 0) { pick = x; break; } }
  const old = ch.sifat[Math.floor(S.rnd() * ch.sifat.length)];
  ch.sifat = ch.sifat.map(x => x === old ? pick : x);
  if (owner === VP) noteRoutine(S, ch.name + ' (' + ch.t + ') mengubah sifat: ' + old + ' → ' + pick);
};
function govStatus(S, pid, m) {
  const p = S.players[pid];
  if (pid !== VP) return m.key === 'mode' ? 'Gaya: ' + ({ easy: 'Damai', normal: 'Normal', hard: 'Agresif' }[p.diff] || 'Normal') : 'Dikendalikan AI kerajaan';
  const c = MODS.cfg;
  if (m.key === 'mode') return c.auto ? 'Gaya: ' + ({ peaceful: 'Damai', normal: 'Normal', aggressive: 'Agresif' })[c.aiMode] : 'Manual (AI ambil alih mati)';
  return c.auto && c[m.key] !== false ? 'Aktif' : 'Nonaktif';
}
function govHTML(S) {
  const kerja = S._car || [];
  const rows = S.players.filter(p => p.alive).map(p => {
    const g = govOf(S, p.id), me = p.id === VP, desa = S.cities.filter(c => c.owner === p.id && !c.isCap), rl = g.ruler;
    let h = `<div class="it"><div class="g">${sw(p.col)} ${p.name}${me ? ' <span class="gd">(kamu)</span>' : ''}</div></div>`;
    h += `<div class="row" style="margin-left:6px"><b>${rl.gelar} ${rl.name}</b>, ${rl.umur} th · Sifat: ${rl.sifat.join(', ')}<br><i class="dim">Tugas: memimpin kerajaan dan menentukan kebijakan</i></div>`;
    h += g.ministers.map(m => {
      const efek = SIFAT_EFEK[m.t] || {}, aktif = m.sifat.filter(x => efek[x]).map(x => efek[x]);
      const tugas = m.t === 'Menteri Ekonomi' && me ? ' · ' + (kerja.some(q => q.kind !== 'envoy') ? 'kafilah dagang sedang berjalan' : 'menunggu kafilah') : (m.t === 'Menteri Luar Negeri' && me ? ' · ' + (kerja.some(q => q.kind === 'envoy') ? 'utusan sedang berjalan' : 'menunggu tawaran') : '');
      return `<div class="row" style="margin-left:14px">↳ <b>${m.t}</b>: ${m.name}, ${m.umur} th, loyalitas ${m.loyal}<br>` +
        `<i class="dim">${m.r} · ${govStatus(S, p.id, m)}${tugas}</i><br>` +
        `<i class="dim">Sifat: ${m.sifat.map(x => x + ' (' + SIFAT_KET[x] + ')').join(', ')}</i>` +
        (aktif.length && me ? `<br><i class="gd">Pengaruh: ${aktif.join('; ')}</i>` : '') + `</div>`;
    }).join('');
    h += `<div class="row" style="margin-left:14px"><i class="dim">Pemukiman di luar ibu kota: ${desa.length}, masing-masing 2 pejabat</i></div>`;
    if (me) h += desa.map(c => { const [w, gu] = villageOfficials(S, c); return `<div class="row" style="margin-left:24px">↳ <b>${c.name}</b> (level ${c.level}): Walikota ${w.name} · Gubernur ${gu.name}<br><i class="dim">Tugas: memungut pajak ${villageTax(S, c)}/hari dan mengelola wilayah · izin militer ${w.izin && gu.izin ? 'ya' : 'sebagian'}</i><br>${btn('vtax:' + c.id, 'Pajak: ' + ['rendah', 'normal', 'tinggi'][taxLvOf(c)], '')} ${btn('vguard:' + c.id, c.guard ? 'Jaga: aktif' : 'Jaga: nonaktif', '')}<br>${btn('vrec:' + c.id, 'Rekrut pejabat', '')} ${btn('vmil:' + c.id, 'Milisi +5 (40)', '')}<br><span style="color:${milisiColor(c)}">●</span> <i class="dim">Milisi ${c.militia || 0} orang · pejabat tambahan ${(c.vx || []).length}</i></div>`; }).join('');
    return h + `<div style="height:8px"></div>`;
  }).join('');
  return `<div class="btns">${btn('wilayah', 'WILAYAH', 'gold')}</div><div class="gl">Pejabat</div><div class="dim">Hierarki: Raja → Perdana Menteri → menteri. Desa: walikota dan gubernur, pajak masuk ke ibu kota.</div><div class="dim" style="font-size:11px">Nama pejabat tampil di atas kepala mereka di peta.</div>${rows}`;
}
// orang kecil seukuran warga: bentuk yang sama dengan drawVillagers, nama di atas kepala
function drawPerson(c, x, y, col, name, ruler) {
  R_(c, x - 0.7, y + 0.3, 1.5, 0.5, 'rgba(0,0,0,.25)');
  R_(c, x - 0.5, y - 0.8, 0.5, 1.1, '#3a2a18'); R_(c, x + 0.1, y - 0.8, 0.5, 1.1, '#3a2a18');
  R_(c, x - 0.6, y - 2.1, 1.3, 1.5, col);
  R_(c, x - 0.4, y - 3.1, 0.9, 1, '#e8c49a'); R_(c, x - 0.5, y - 3.3, 1.1, 0.5, ruler ? '#d8b858' : '#6a4a28');
  if (RN.cam && RN.cam.z < 1.4) return;
  c.font = '2.2px sans-serif'; c.textAlign = 'center'; c.lineWidth = 0.45; c.strokeStyle = '#000'; c.fillStyle = '#fff';
  c.strokeText(name, x, y - 4.4); c.fillText(name, x, y - 4.4);
}
function MODS_draw(c, S, vx0, vx1, vy0, vy1) { MODS.draw(c, S, vx0, vx1, vy0, vy1); }

/* ===== Info Developer (tombol di menu utama, setelah MODS) ===== */
const DEV = { nama: 'Чарли Sudio', telp: '+6282372803247', tg: 'https://t.me/gaudencior' };
function devInfoHTML() {
  return `<div class="dv">
    <div class="dv-hero"><div class="dv-logo">REALM<span>FORGE</span></div><div class="dv-tag">Strategi abad pertengahan · bangun kerajaanmu sendiri</div></div>
    <section class="dv-sec" style="--d:.08s"><h3>Tentang game</h3>
      <p>RealmForge adalah game strategi abad pertengahan. Bangun kota, desa, pasar, dan pelabuhan, latih pasukan, lalu atur dagang dan diplomasi dengan kerajaan tetangga. Setiap kerajaan punya raja atau ratu, menteri, dan pejabat dengan sifat masing-masing.</p></section>
    <section class="dv-sec" style="--d:.16s"><h3>Update terbaru · v1.6</h3>
      <ul class="dv-list">
        <li>Menu MODS: AI ambil alih kerajaan (damai, normal, agresif), auto dagang, auto militer, auto desa, dan pelabuhan otomatis</li>
        <li>Pemerintahan: raja atau ratu, menteri, serta walikota dan gubernur di setiap pemukiman yang membayar pajak ke ibu kota</li>
        <li>Menu Pejabat di Diplomasi: tugas tiap pejabat dan keadaan mereka sekarang</li>
        <li>Kafilah dagang dan utusan diplomasi berjalan kaki ke kota tetangga</li>
        <li>Nama pejabat tampil di atas kepala mereka di peta</li>
        <li>Pilih pasukan lebih mudah: ketuk untuk memilih atau membatalkan, dan ketuk wilayah untuk memilih pasukan terdekat</li>
        <li>Performa dan animasi antarmuka dioptimalkan</li>
        <li>Utusan menahan tawaran diplomasi sampai tiba, dan sifat Menteri Luar Negeri ikut menentukan hasilnya</li>
        <li>Pajak desa bisa diatur: rendah, normal, atau tinggi. Penjagaan desa juga bisa dinyalakan</li>
        <li>Peristiwa kerajaan tiap beberapa hari dengan pilihan yang punya akibat nyata</li>
        <li>Kafilah membawa kayu, makanan, atau besi dengan harga berbeda di tiap kota</li>
        <li>Info tugas pasukan muncul saat pasukan dipilih</li>
        <li>Data pemerintahan, kafilah, dan peristiwa ikut tersimpan saat save</li>
        <li>Perbaikan: jumlah prajurit khusus, pemadam, dan dokter tidak lagi kembali ke 0 setelah save dan muat</li>
        <li>Selir diambil otomatis oleh AI, separuh bersifat baik dan separuh jahat. Sifat ibu diwariskan ke anak</li>
        <li>Peran baru: penasihat raja, jaksa agung, kepala kepolisian, duta besar, bendahara kerajaan, panglima besar, ketua mahkamah agung, kepala pengawal kerajaan, dan kepala administrasi kerajaan</li>
        <li>Pejabat tidak lagi dibatasi: gubernur bisa merekrut pejabat tambahan di desa</li>
        <li>Milisi per desa dengan warna sendiri, dan menu Wilayah (provinsi, kota/kabupaten, kecamatan, kelurahan, desa)</li>
        <li>Tombol MODS dan TEKNOLOGI sejajar dengan tombol MASUK (ukuran dan posisi sama)</li>
        <li>Layar Teknologi tidak lagi tersendat saat digulir</li>
        <li>Tampilan ulang: tombol MODS dan TEKNOLOGI bergaya tombol MASUK dengan ikon, dan layar Teknologi memakai tata letak grid dengan tab</li>
        <li>Menu baru TEKNOLOGI: riset senjata, ekonomi, perdagangan, dan pembangunan dengan waktu tunggu. Teknologi terbuka berurutan dan memberi efek nyata</li>
      </ul></section>
    <section class="dv-sec dv-dev" style="--d:.24s">
      <div class="dv-badge">C</div>
      <div><div class="dv-k">Developer</div><div class="dv-name">${DEV.nama}</div>
        <a class="dv-call" href="tel:${DEV.telp}">☎ ${DEV.telp}</a>
        <a class="dv-tg" href="${DEV.tg}" target="_blank" rel="noopener">✈ Telegram: t.me/gaudencior</a></div>
    </section>
  </div>`;
}
Object.assign(ACT, {
  devinfo() { showModal('Info Developer', devInfoHTML(), btn('closemodal', 'Tutup', 'gold')); }
});

/* ===== Ikon RealmForge: di minimap (pojok kiri bawah) ===== */
const RF_ICON = new Image(); RF_ICON.src = 'icon.png';
(function () {
  const _dm = drawMinimap;
  drawMinimap = function (S) {
    _dm(S);
    const mm = RN.minimap; if (!mm || !RF_ICON.complete || !RF_ICON.naturalWidth) return;
    const c = mm.getContext('2d'), k = Math.round(mm.width * 0.22);
    c.imageSmoothingEnabled = true; c.drawImage(RF_ICON, 4, mm.height - k - 4, k, k);
  };
})();

/* ===== Tugas pasukan: info singkat saat pasukan dipilih ===== */
let _selId = null;
(function () {
  const _mt3 = UI.mapTap;
  UI.mapTap = function (tx, ty) {
    const r = _mt3.call(this, tx, ty), S = UI.S, cur = RN.sel;
    if (cur && cur.k === 'army' && S && MODS.live()) {
      if (cur.id !== _selId) {
        _selId = cur.id; const a = S.armies.find(x => x.id === cur.id && x.owner === VP);
        if (a) say('Pasukan: ' + (a.job === 'jaga' ? 'menjaga ' + (a.jobN || 'kota') : a.job === 'patroli' ? 'berpatroli di sekitar kota' : 'belum ada tugas'), true);
      }
    } else _selId = null;
    return r;
  };
})();

/* ===== Peristiwa kerajaan: tiap 3 hari game, pilihan dengan akibat nyata ===== */
function rfNameOf(S, k) { const o = S._gov && S._gov[k]; return o ? o.name : '?'; }
function rfVCity(S) { const cs = S.cities.filter(c => c.owner === VP && !c.isCap); return cs.length ? cs[Math.floor(S.rnd() * cs.length)] : null; }
const RF_EVENTS = [
  { make(S) { const c = rfVCity(S); if (!c) return null; const k = 'v' + c.id + '|gubernur'; villageOfficials(S, c);
    return { title: 'Dana perbaikan desa', text: 'Gubernur ' + rfNameOf(S, k) + ' meminta 50 emas untuk memperbaiki jalan dan gudang di ' + c.name + '.', a: 'Beri 50 emas', b: 'Tolak',
      opts: [{ need: 50, gold: -50, loyal: [k, 8], msg: 'Gubernur senang, desa membaik' }, { loyal: [k, -8], msg: 'Gubernur kecewa dan menggerutu' }] }; } },
  { make(S) { govOf(S, VP); const k = VP + '|Menteri Perang';
    return { title: 'Persiapan perang', text: 'Menteri Perang ' + rfNameOf(S, k) + ' meminta 30 emas untuk mempersiapkan pasukan.', a: 'Setujui (30 emas)', b: 'Tunda',
      opts: [{ need: 30, gold: -30, loyal: [k, 6], msg: 'Pasukan dipersiapkan' }, { loyal: [k, -6], msg: 'Menteri menggerutu' }] }; } },
  { make(S) { const c = rfVCity(S); if (!c) return null; const k = 'v' + c.id + '|walikota'; villageOfficials(S, c);
    return { title: 'Laporan pajak', text: 'Walikota ' + rfNameOf(S, k) + ' melaporkan pajak bocor di ' + c.name + '.', a: 'Selidiki (+25 emas)', b: 'Abaikan',
      opts: [{ gold: 25, loyal: [k, 3], msg: 'Pajak bocor ditemukan, kas bertambah' }, { loyal: [k, -6], msg: 'Laporan diabaikan' }] }; } }
];
MODS.events = function (S) {
  if (!this.live() || UI.S !== S || S._ev || S.time < (S._evNext === undefined ? 3 * DAY : S._evNext)) return;
  if (!$('modal').classList.contains('hidden')) return;
  S._evNext = S.time + 3 * DAY;
  const ev = RF_EVENTS[Math.floor(S.rnd() * RF_EVENTS.length)].make(S); if (!ev) return;
  S._ev = ev;
  showModal('Peristiwa kerajaan', `<div class="dim">${ev.text}</div>`, btn('evpick:0', ev.a, 'gold') + btn('evpick:1', ev.b, ''));
};
Object.assign(ACT, {
  vtax(id) { const S = UI.S, c = S && S.cities.find(q => q.id == id && q.owner === VP); if (!c) return; c.taxLv = (taxLvOf(c) + 1) % 3; say('Pajak ' + c.name + ': ' + ['rendah', 'normal', 'tinggi'][taxLvOf(c)], true); openList('officials'); },
  vguard(id) { const S = UI.S, c = S && S.cities.find(q => q.id == id && q.owner === VP); if (!c) return; c.guard = !c.guard; say('Penjagaan ' + c.name + (c.guard ? ' diaktifkan' : ' dimatikan'), true); openList('officials'); },
  evpick(n) {
    const S = UI.S, ev = S && S._ev; if (!ev) return;
    const o = ev.opts[+n]; let msg = o.msg;
    if (o.need && S.players[VP].stock.gold < o.need) msg = 'Kas tidak cukup, pilihan ini gagal';
    else { if (o.gold) S.players[VP].stock.gold += o.gold; }
    if (o.loyal && S._gov[o.loyal[0]]) S._gov[o.loyal[0]].loyal = Math.max(10, Math.min(100, S._gov[o.loyal[0]].loyal + o.loyal[1]));
    S._ev = null; say(msg, true); if (typeof ACT.closemodal === 'function') ACT.closemodal();
  }
});

/* ===== Teknologi: riset berurutan per kategori, dengan waktu tunggu (cooldown) ===== */
const RF_TECH_CAT = ['Senjata', 'Ekonomi', 'Perdagangan', 'Pembangunan'];
const RF_TECH = [
  { id: 'pedang', cat: 'Senjata', n: 'Pedang Besi', d: 'Serangan pasukanmu +10%', c: 60, t: 90, atk: 0.10 },
  { id: 'busur', cat: 'Senjata', n: 'Busur Panjang', d: 'Serangan pasukanmu +10%', c: 120, t: 150, atk: 0.10 },
  { id: 'tombak', cat: 'Senjata', n: 'Tombak Baja', d: 'Serangan pasukanmu +15%', c: 200, t: 210, atk: 0.15 },
  { id: 'irigasi', cat: 'Ekonomi', n: 'Irigasi', d: '+2 emas tiap hari', c: 50, t: 90, gold: 2 },
  { id: 'lumbung', cat: 'Ekonomi', n: 'Lumbung', d: '+3 emas tiap hari', c: 110, t: 150, gold: 3 },
  { id: 'pupuk', cat: 'Ekonomi', n: 'Pupuk', d: '+4 emas tiap hari', c: 180, t: 210, gold: 4 },
  { id: 'jalur', cat: 'Perdagangan', n: 'Jalur Dagang', d: 'Kafilah membawa emas +10%', c: 70, t: 100, trade: 0.10 },
  { id: 'pasar', cat: 'Perdagangan', n: 'Pasar Ramai', d: 'Kafilah membawa emas +10%', c: 130, t: 160, trade: 0.10 },
  { id: 'bendera', cat: 'Perdagangan', n: 'Bendera Dagang', d: 'Kafilah membawa emas +10%', c: 190, t: 200, trade: 0.10 },
  { id: 'batu', cat: 'Pembangunan', n: 'Batu Kuat', d: 'Rumah tumbuh 10% lebih cepat', c: 60, t: 100, build: 0.10 },
  { id: 'kayu', cat: 'Pembangunan', n: 'Tukang Kayu', d: 'Rumah tumbuh 10% lebih cepat', c: 120, t: 150, build: 0.10 },
  { id: 'rencana', cat: 'Pembangunan', n: 'Tata Kota', d: 'Rumah tumbuh 10% lebih cepat', c: 180, t: 200, build: 0.10 }
];
function techS(S) { return S._tech = S._tech || { done: [], cur: null, prog: 0, dur: 0 }; }
function techSum(S, key) {
  const t = techS(S); let s = 0;
  for (const id of t.done) { const x = RF_TECH.find(q => q.id === id); if (x && x[key]) s += x[key]; }
  return s;
}
function techAvail(S, x) {
  const t = techS(S), cat = RF_TECH.filter(q => q.cat === x.cat), i = cat.indexOf(x);
  return i === 0 || t.done.includes(cat[i - 1].id);
}
MODS.techStart = function (S, id) {
  const x = RF_TECH.find(q => q.id === id), t = techS(S), p = S.players[VP];
  if (!x || t.cur || t.done.includes(id) || !techAvail(S, x)) return;
  if (p.stock.gold < x.c) { say('Emas kurang: butuh ' + x.c, false); return; }
  p.stock.gold -= x.c; t.cur = id; t.prog = 0; t.dur = x.t;
  say('Riset ' + x.n + ' dimulai', true);
};
MODS.techTick = function (S, dt) {
  if (!this.live()) return;
  const t = techS(S), p = S.players[VP];
  if (t.cur) {
    t.prog += dt;
    if (t.prog >= t.dur) {
      const x = RF_TECH.find(q => q.id === t.cur);
      t.done.push(x.id); t.cur = null; t.prog = 0;
      p.atkMod = 1 + techSum(S, 'atk');
      say('Teknologi terbuka: ' + x.n, true);
    }
  }
  if (S._techDay === undefined) S._techDay = S.time + DAY;
  if (S.time >= S._techDay) { S._techDay += DAY; const g = techSum(S, 'gold'); if (g) p.stock.gold += g; }
};
const RF_TECH_TAB = { EKONOMI: ['Ekonomi', 'Perdagangan'], MILITER: ['Senjata', 'Pembangunan'] };
const RF_CAT_ICON = { Senjata: 'sword', Ekonomi: 'gold', Perdagangan: 'cart', Pembangunan: 't_build' };
const RF_TECH_ICON = { pedang: 'sword', busur: 'bow', tombak: 'armL', irigasi: 'food', lumbung: 'wood', pupuk: 'iron', jalur: 'cart', pasar: 'gold', bendera: 'flag', batu: 'iron', kayu: 'wood', rencana: 't_build' };
function techNode(S, t, x, arrow) {
  const done = t.done.includes(x.id), cur = t.cur === x.id, ok = techAvail(S, x);
  const cls = done ? 'tk-done' : cur ? 'tk-cur' : ok ? 'tk-open' : 'tk-lock';
  let foot;
  if (done) foot = '<span class="tk-badge">✓ Selesai</span>';
  else if (cur) foot = '<div class="tk-bar"><i id="tkBar" style="width:0%"></i></div><div class="tk-sub" id="tkLeft">riset berjalan</div>';
  else if (!ok) foot = '<div class="tk-sub">🔒 Terkunci</div>';
  else foot = btn('techgo:' + x.id, IMG('gold', 14) + ' ' + x.c + ' · ' + x.t + ' dtk', t.cur ? 'dis' : 'gold');
  return `<div class="tk-node ${cls}"><div class="tk-ic">${IMG(RF_TECH_ICON[x.id] || 'scroll', 30)}</div><div class="tk-name">${x.n}</div><div class="tk-desc">${x.d}</div><div class="tk-foot">${foot}</div></div>` + (arrow ? '<div class="tk-arrow">▼</div>' : '');
}
function techHTML(S) {
  const t = techS(S), tab = MODS.techTab || 'EKONOMI', cats = RF_TECH_TAB[tab];
  const tabs = Object.keys(RF_TECH_TAB).map(k => `<button class="tk-tab ${k === tab ? 'on' : ''}" data-act="techtab:${k}">${k}</button>`).join('');
  const cols = cats.map(cat => {
    const nodes = RF_TECH.filter(x => x.cat === cat).map((x, i, arr) => techNode(S, t, x, i < arr.length - 1)).join('');
    return `<div class="tk-col"><div class="tk-root">${IMG(RF_CAT_ICON[cat], 24)}<span>${cat}</span></div>${nodes}</div>`;
  }).join('');
  const cur = t.cur ? RF_TECH.find(q => q.id === t.cur) : null;
  return `<div class="tk-tabs">${tabs}</div>` +
    `<div class="tk-stat">${IMG('gold', 18)}<b id="tkGold"></b> emas · ${cur ? 'Riset: ' + cur.n : 'Tidak ada riset berjalan'}</div>` +
    `<div class="tk-grid">${cols}</div>` +
    `<div class="tk-note">Ketuk Riset untuk memulai. Satu riset berjalan dalam satu waktu. Teknologi terbuka berurutan dalam tiap cabang.</div>`;
}
function techFab() {
  const b = rfFab('techFab', 'tech', 'chart', 'TEKNOLOGI', ''); if (!b) return;
  const on = MODS.live(); if (on !== techFab._on) { b.style.display = on ? 'flex' : 'none'; techFab._on = on; }
}
Object.assign(ACT, {
  tech() { MODS.techTab = MODS.techTab || 'EKONOMI'; openList('tech'); },
  techtab(k) { MODS.techTab = k; openList('tech'); },
  techgo(id) { if (UI.S) MODS.techStart(UI.S, id); }
});

/* perbarui angka hidup di layar Teknologi tanpa membangun ulang HTML (menghindari lag saat digulir) */
function techLive(S) {
  const g = document.getElementById('tkGold'); if (!g) return;
  const t = techS(S);
  g.textContent = S.players[VP].stock.gold;
  if (t.cur) {
    const b = document.getElementById('tkBar'), l = document.getElementById('tkLeft');
    if (b) b.style.width = Math.min(100, t.prog / t.dur * 100).toFixed(1) + '%';
    if (l) l.textContent = Math.max(0, Math.ceil(t.dur - t.prog)) + ' dtk lagi';
  }
}

/* ===== Rekrutmen desa, milisi gubernur, dan tampilan Wilayah ===== */
const RF_VROLE = ['Pejabat Desa', 'Penasihat Desa', 'Juru Tulis', 'Bendahara Desa', 'Kepala Pengawal Desa'];
const RF_MILISI_COLOR = ['#e25a5a', '#4ea3ff', '#5ce07a', '#ffd24a', '#b07aff', '#4ee3c1', '#ff8c42', '#ff6fb1'];
function vCityOwn(S, id) { return S.cities.find(q => q.id == id && q.owner === VP && !q.isCap); }
Object.assign(ACT, {
  vrec(id) {
    const S = UI.S, c = S && vCityOwn(S, id); if (!c) return;
    c.vx = c.vx || [];
    const role = RF_VROLE[c.vx.length % RF_VROLE.length] + (c.vx.length >= RF_VROLE.length ? ' ' + (Math.floor(c.vx.length / RF_VROLE.length) + 1) : '');
    const key = 'v' + c.id + '|x' + c.vx.length;
    govChar(S, key, role, role, 'Gubernur', VP); c.vx.push(key);
    say(role + ' direkrut di ' + c.name, true); openList('officials');
  },
  vmil(id) {
    const S = UI.S, c = S && vCityOwn(S, id), p = S && S.players[VP]; if (!c) return;
    if (p.stock.gold < 40) { say('Emas kurang: butuh 40', false); return; }
    p.stock.gold -= 40; c.militia = (c.militia || 0) + 5;
    say('Milisi ' + c.name + ' bertambah 5 orang', true); openList('officials');
  },
  wilayah() { openList('wilayah'); }
});
function milisiColor(c) { return RF_MILISI_COLOR[(c.id | 0) % RF_MILISI_COLOR.length]; }
// wilayah: kerajaan > provinsi (sektor peta) > kota/kabupaten > kecamatan > kelurahan > desa
function wilayahHTML(S) {
  const mine = S.cities.filter(c => c.owner === VP), W = S.W, H = S.H;
  const sec = c => Math.min(2, Math.floor(c.x * 3 / W)) + '-' + Math.min(2, Math.floor(c.y * 3 / H));
  const prov = {};
  for (const c of mine) (prov[sec(c)] = prov[sec(c)] || []).push(c);
  const nama = ['Utara', 'Tengah', 'Selatan'], timur = ['Barat', 'Tengah', 'Timur'];
  let h = `<div class="gl">Wilayah ${S.players[VP].name}</div><div class="dim">Kerajaan → Provinsi → Kota/Kabupaten → Kecamatan → Kelurahan → Desa</div>`;
  for (const k of Object.keys(prov).sort()) {
    const cs = prov[k], [sy, sx] = k.split('-').map(Number), pn = 'Provinsi ' + nama[sy] + ' ' + timur[sx];
    const regs = cs.filter(c => c.isCap || c.level >= 1), vils = cs.filter(c => !c.isCap && c.level === 0);
    h += `<div class="it rf-prov"><div class="g"><b>${pn}</b> · ${cs.length} pemukiman</div>`;
    for (const r of regs) {
      const ds = vils.filter(v => Math.hypot(v.x - r.x, v.y - r.y) <= 10).sort((a, b) => a.id - b.id);
      h += `<div class="row rf-kab" style="margin-left:12px">Kota/Kabupaten <b>${r.name}</b>${r.isCap ? ' · ibu kota' : ''}</div>`;
      for (let i = 0; i < ds.length; i += 4) {
        h += `<div class="row rf-kec" style="margin-left:24px">Kecamatan ${Math.floor(i / 4) + 1}</div>`;
        for (let j = i; j < Math.min(ds.length, i + 4); j += 2) {
          h += `<div class="row rf-kel" style="margin-left:36px">Kelurahan ${Math.floor(j / 2) + 1}`;
          for (const v of ds.slice(j, j + 2)) h += `<div class="dim" style="margin-left:12px">Desa ${v.name} · <span style="color:${milisiColor(v)}">●</span> milisi ${v.militia || 0}</div>`;
          h += `</div>`;
        }
      }
    }
    h += `</div>`;
  }
  return h;
}

/* ===== Kendali desa (ditampilkan di layar Pejabat, setelah daftar dari realm.js) ===== */
function villageCtlHTML(S) {
  const desa = S.cities.filter(c => c.owner === VP && !c.isCap);
  let h = `<div class="btns">${btn('wilayah', 'WILAYAH', 'gold')}</div><div class="gl">Kendali desa dan kota</div>`;
  if (!desa.length) return h + '<div class="dim">Belum ada desa atau kota kecil milik kamu.</div>';
  for (const c of desa) {
    const [w, gu] = villageOfficials(S, c);
    h += `<div class="it rf-desa"><div class="g"><b>${c.name}</b> · level ${c.level}` +
      ` <span style="color:${milisiColor(c)}">●</span> milisi ${c.militia || 0}</div>` +
      `<div class="dim">Walikota ${w.name} · Gubernur ${gu.name} · pejabat tambahan ${(c.vx || []).length} · pajak ${villageTax(S, c)}/hari</div>` +
      `<div class="btns">${btn('vtax:' + c.id, 'Pajak: ' + ['rendah', 'normal', 'tinggi'][taxLvOf(c)], '')} ${btn('vguard:' + c.id, c.guard ? 'Jaga: aktif' : 'Jaga: nonaktif', '')}</div>` +
      `<div class="btns">${btn('vrec:' + c.id, 'Rekrut pejabat', '')} ${btn('vmil:' + c.id, 'Milisi +5 (40)', '')}</div></div>`;
  }
  return h;
}
