'use strict';
/* ===== RealmForge+ (ext.js): fitur tambahan ===================================================
   Musim & cuaca, spionase, pernikahan politik, agama, rute dagang permanen, teknologi tambahan,
   misi & prestasi, kampanye, statistik & replay, slot simpan, tantangan harian.
   Semua berjalan hanya di mode offline (seperti MODS) supaya multiplayer lockstep tidak desync.
   Data per-permainan disimpan di players[VP].ex (ikut save/load); data global di localStorage "rf_x_meta". */
(function () {
  /* terjemahan label inti: [es, vi, de, fr, it, zh, ja]; bahasa lain memakai Inggris */
  const TRK = { es: 0, vi: 1, de: 2, fr: 3, it: 4, zh: 5, ja: 6 };
  const TR = {
    'Seasons & weather': ['Estaciones y clima', 'Mùa & thời tiết', 'Jahreszeiten & Wetter', 'Saisons & météo', 'Stagioni e meteo', '季节与天气', '季節と天気'],
    'Espionage': ['Espionaje', 'Gián điệp', 'Spionage', 'Espionnage', 'Spionaggio', '间谍', '諜報'],
    'Royal marriages': ['Matrimonios reales', 'Hôn nhân hoàng gia', 'Königliche Ehen', 'Mariages royaux', 'Matrimoni reali', '王室联姻', '王室の婚姻'],
    'Faith': ['Fe', 'Tín ngưỡng', 'Glaube', 'Foi', 'Fede', '信仰', '信仰'],
    'Trade routes': ['Rutas comerciales', 'Tuyến thương mại', 'Handelsrouten', 'Routes commerciales', 'Rotte commerciali', '贸易路线', '交易路'],
    'Quests & achievements': ['Misiones y logros', 'Nhiệm vụ & thành tựu', 'Aufgaben & Erfolge', 'Quêtes & succès', 'Missioni e obiettivi', '任务与成就', 'クエストと実績'],
    'Stats & replay': ['Estadísticas y repetición', 'Thống kê & xem lại', 'Statistik & Wiederholung', 'Stats & rediffusion', 'Statistiche e replay', '统计与回放', '統計とリプレイ'],
    'Stats & Replay': ['Estadísticas y repetición', 'Thống kê & xem lại', 'Statistik & Wiederholung', 'Stats & rediffusion', 'Statistiche e replay', '统计与回放', '統計とリプレイ'],
    'Save slots': ['Ranuras de guardado', 'Ô lưu game', 'Speicherplätze', 'Emplacements de sauvegarde', 'Slot di salvataggio', '存档位', 'セーブスロット'],
    'Daily challenge': ['Desafío diario', 'Thử thách hằng ngày', 'Tägliche Herausforderung', 'Défi quotidien', 'Sfida giornaliera', '每日挑战', 'デイリーチャレンジ'],
    'Campaign': ['Campaña', 'Chiến dịch', 'Kampagne', 'Campagne', 'Campagna', '战役', 'キャンペーン'],
    'Settings': ['Ajustes', 'Cài đặt', 'Einstellungen', 'Paramètres', 'Impostazioni', '设置', '設定'],
    'Close': ['Cerrar', 'Đóng', 'Schließen', 'Fermer', 'Chiudi', '关闭', '閉じる'],
    'Save': ['Guardar', 'Lưu', 'Speichern', 'Enregistrer', 'Salva', '保存', '保存'],
    'Load': ['Cargar', 'Tải', 'Laden', 'Charger', 'Carica', '读取', 'ロード'],
    'Delete': ['Borrar', 'Xóa', 'Löschen', 'Supprimer', 'Elimina', '删除', '削除'],
    'Start': ['Iniciar', 'Bắt đầu', 'Starten', 'Démarrer', 'Inizia', '开始', '開始'],
    'Replay': ['Repetir', 'Xem lại', 'Wiederholen', 'Rejouer', 'Rigioca', '重播', 'リプレイ'],
    'Achievements': ['Logros', 'Thành tựu', 'Erfolge', 'Succès', 'Obiettivi', '成就', '実績'],
    'Quests': ['Misiones', 'Nhiệm vụ', 'Aufgaben', 'Quêtes', 'Missioni', '任务', 'クエスト'],
    'Propose': ['Proponer', 'Cầu hôn', 'Antrag', 'Proposer', 'Proponi', '提亲', '申し込む'],
    'Accept': ['Aceptar', 'Chấp nhận', 'Annehmen', 'Accepter', 'Accetta', '接受', '受ける'],
    'Decline': ['Rechazar', 'Từ chối', 'Ablehnen', 'Refuser', 'Rifiuta', '拒绝', '断る'],
    'Upgrade': ['Mejorar', 'Nâng cấp', 'Aufwerten', 'Améliorer', 'Potenzia', '升级', '強化'],
    'Open': ['Abrir', 'Mở', 'Öffnen', 'Ouvrir', 'Apri', '开通', '開設'],
    'Cancel': ['Cancelar', 'Hủy', 'Abbrechen', 'Annuler', 'Annulla', '取消', 'キャンセル'],
    'Scout': ['Explorar', 'Do thám', 'Auskundschaften', 'Espionner', 'Esplora', '侦察', '偵察'],
    'Steal': ['Robar', 'Trộm', 'Stehlen', 'Voler', 'Ruba', '盗取', '盗む'],
    'Sabotage': ['Sabotaje', 'Phá hoại', 'Sabotage', 'Sabotage', 'Sabotaggio', '破坏', '妨害'],
    'Incite': ['Incitar', 'Kích động', 'Aufwiegeln', 'Inciter', 'Istiga', '煽动', '扇動'],
    'Spring': ['Primavera', 'Mùa xuân', 'Frühling', 'Printemps', 'Primavera', '春', '春'],
    'Summer': ['Verano', 'Mùa hè', 'Sommer', 'Été', 'Estate', '夏', '夏'],
    'Autumn': ['Otoño', 'Mùa thu', 'Herbst', 'Automne', 'Autunno', '秋', '秋'],
    'Winter': ['Invierno', 'Mùa đông', 'Winter', 'Hiver', 'Inverno', '冬', '冬'],
    'Rain': ['Lluvia', 'Mưa', 'Regen', 'Pluie', 'Pioggia', '雨', '雨'],
    'Flood': ['Inundación', 'Lũ lụt', 'Flut', 'Inondation', 'Alluvione', '洪水', '洪水'],
    'Drought': ['Sequía', 'Hạn hán', 'Dürre', 'Sécheresse', 'Siccità', '干旱', '干ばつ'],
    'Storm': ['Tormenta', 'Bão', 'Sturm', 'Tempête', 'Tempesta', '风暴', '嵐'],
    'Blizzard': ['Ventisca', 'Bão tuyết', 'Schneesturm', 'Blizzard', 'Bufera di neve', '暴风雪', '吹雪'],
    'Clear skies': ['Cielo despejado', 'Trời quang', 'Klarer Himmel', 'Ciel dégagé', 'Cielo sereno', '晴天', '晴れ'],
    'Year': ['Año', 'Năm', 'Jahr', 'An', 'Anno', '年', '年'],
    'Food': ['Comida', 'Lương thực', 'Nahrung', 'Nourriture', 'Cibo', '粮食', '食料'],
    'Adopt': ['Adoptar', 'Theo đạo', 'Annehmen', 'Adopter', 'Adotta', '皈依', '信仰する'],
    'Offering': ['Ofrenda', 'Cúng dường', 'Opfergabe', 'Offrande', 'Offerta', '供奉', '奉納'],
    'Missionary': ['Misionero', 'Nhà truyền giáo', 'Missionar', 'Missionnaire', 'Missionario', '传教士', '宣教師'],
    'Counter-intel': ['Contraespionaje', 'Phản gián', 'Spionageabwehr', 'Contre-espionnage', 'Controspionaggio', '反间谍', '防諜'],
    'Main menu': ['Menú principal', 'Menu chính', 'Hauptmenü', 'Menu principal', 'Menu principale', '主菜单', 'メインメニュー'],
    'Copy result': ['Copiar resultado', 'Sao chép kết quả', 'Ergebnis kopieren', 'Copier le résultat', 'Copia risultato', '复制结果', '結果をコピー'],
    'Top scores': ['Mejores puntuaciones', 'Điểm cao nhất', 'Bestenliste', 'Meilleurs scores', 'Punteggi migliori', '最高分', 'ハイスコア'],
    'Guide': ['Guía', 'Hướng dẫn', 'Anleitung', 'Guide', 'Guida', '指南', 'ガイド'],
    'Buildings': ['Edificios', 'Công trình', 'Gebäude', 'Bâtiments', 'Edifici', '建筑', '建物'],
    'Mild': ['Suave', 'Nhẹ', 'Mild', 'Doux', 'Lieve', '温和', '穏やか'],
    'Harsh': ['Duro', 'Khắc nghiệt', 'Hart', 'Rude', 'Duro', '严酷', '過酷'],
    'Notifications': ['Notificaciones', 'Thông báo', 'Benachrichtigungen', 'Notifications', 'Notifiche', '通知', '通知'],
    'All': ['Todas', 'Tất cả', 'Alle', 'Toutes', 'Tutte', '全部', 'すべて'],
    'Key only': ['Solo clave', 'Chỉ quan trọng', 'Nur wichtige', 'Essentielles', 'Solo importanti', '仅重要', '重要のみ'],
    'Off': ['Apagado', 'Tắt', 'Aus', 'Désactivé', 'Spento', '关', 'オフ']
  };
  const L = (en, id) => {
    if (typeof gxIsEn === 'function' && gxIsEn()) return en;
    const lg = typeof I18N !== 'undefined' ? I18N.lang : '', i = TRK[lg];
    if (i !== undefined) { const t = TR[en]; return t && t[i] ? t[i] : en; }
    return id;
  };
  const cx = (v, a, b) => Math.max(a, Math.min(b, v));
  const SL = RY / 4;                       // satu musim = seperempat tahun
  const FAITH = ['sun', 'green', 'iron'];
  const RFX = window.RFX = {
    cfg: { season: true, fx: true, aiSpy: true, sev: 'normal', notif: 'all' },
    meta: { ach: {}, camp: [], daily: {}, board: [], streak: 0, last: 0, qdone: 0, fr: [], guide: 0 },
    cur: null
  };
  const META_KEY = 'rf_x_meta';
  function metaLoad() { try { const o = JSON.parse(localStorage.getItem(META_KEY) || '{}'); if (o.cfg) Object.assign(RFX.cfg, o.cfg); if (o.meta) Object.assign(RFX.meta, o.meta); } catch (e) { } }
  function metaSave() { try { localStorage.setItem(META_KEY, JSON.stringify({ cfg: RFX.cfg, meta: RFX.meta })); } catch (e) { } }
  metaLoad();

  const on = S => !!S && S === UI.S && !S.tut && MODS.live();
  RFX.on = on;
  function EX(S) {
    const p = S.players[VP], e = p.ex || (p.ex = { v: 1 });
    e.sp = e.sp || { lv: 1, xp: 0, ok: 0, fail: 0, ops: [], cd: {}, intel: {}, ctr: 0, nid: 1 };
    e.mr = e.mr || { list: [], inc: [], cd: {}, rul: {}, claims: {}, war: {}, ui: { kid: null, tier: 0 } };
    e.rl = e.rl || { faith: null, piety: 0 };
    e.rt = e.rt || { list: [], nid: 1, ui: { a: null }, earn: 0 };
    e.q = e.q || { act: [], done: 0, nid: 1 };
    e.h = e.h || { y: [], snaps: [] };
    e.wx = e.wx || { k: null, until: 0 };
    e.st = e.st || { winters: 0, throne: 0, ls: -1, ws: 0, cheat: 0, hd: 0 };
    e.bl = e.bl || []; e.evq = e.evq || [];
    if (e.day === undefined) e.day = -1;
    if (e.yr === undefined) e.yr = -1;
    return e;
  }
  RFX.EX = EX;
  const toast = (S, title, text, low) => { const m = RFX.cfg.notif; if (m === 'off' || (m === 'key' && low)) return; S.toast.push({ title, text, t: S.time }); };
  const tell = (S, title, text, type, low) => { addMsg(S, VP, { type: type || 'pol', title, text }); toast(S, title, text, low); };
  const foes = S => S.players.filter(p => p.id !== VP && p.alive);
  const myCities = S => S.cities.filter(c => c.owner === VP);
  const armyUnits = (S, pid) => S.armies.reduce((s, a) => s + (a.owner === pid ? units(a) : 0), 0);
  const faithOf = p => FAITH[(p.ci | 0) % 3];
  const rulerOf = (S, pid) => { try { const c = R(S).chars[pid + '|raja']; return c && !c.dead ? c : null; } catch (e) { return null; } };
  const dayN = S => Math.floor(S.time / DAY) + 1;
  const yearN = S => Math.floor(S.time / RY) + 1;

  /* ================= 1. MUSIM & CUACA ================= */
  const SEAS = [
    { k: 'spring', e: '✿', n: ['Spring', 'Musim Semi'], d: ['Planting season: crops grow steadily.', 'Musim tanam: panen tumbuh stabil.'] },
    { k: 'summer', e: '☀', n: ['Summer', 'Musim Panas'], d: ['Long days: good harvests, armies march well.', 'Hari panjang: panen bagus, pasukan melaju baik.'] },
    { k: 'autumn', e: '❦', n: ['Autumn', 'Musim Gugur'], d: ['Harvest time: food production peaks.', 'Musim panen: produksi pangan memuncak.'] },
    { k: 'winter', e: '❄', n: ['Winter', 'Musim Dingin'], d: ['Harsh cold: food output drops and armies slow down. Stock up!', 'Dingin menusuk: panen turun dan pasukan melambat. Timbun pangan!'] }
  ];
  const WX = {
    rain: { e: '☂', n: ['Rain', 'Hujan'], d: ['Food +10%', 'Pangan +10%'] },
    flood: { e: '≈', n: ['Flood', 'Banjir'], d: ['Wood -20%, food -10%', 'Kayu -20%, pangan -10%'] },
    drought: { e: '☼', n: ['Drought', 'Kemarau'], d: ['Food -25%', 'Pangan -25%'] },
    storm: { e: '↯', n: ['Storm', 'Badai'], d: ['Armies move 25% slower', 'Pasukan 25% lebih lambat'] },
    harvest: { e: '✦', n: ['Bountiful harvest', 'Panen raya'], d: ['Food +15%', 'Pangan +15%'] },
    blizzard: { e: '❄', n: ['Blizzard', 'Badai salju'], d: ['Armies 40% slower, food -10%', 'Pasukan 40% lebih lambat, pangan -10%'] }
  };
  const seasonIdx = S => Math.floor((S.time % RY) / SL) & 3;
  const wxNow = (S, e) => (e.wx.k && e.wx.until > S.time ? e.wx.k : null);
  const SEV = { easy: 0.6, normal: 1, hard: 1.4 }, sevK = () => SEV[RFX.cfg.sev] || 1;
  const harsh = S => (S.opts && S.opts.camp === 2 ? 0.1 : 0);
  function seasonMul(S, pid, k) {
    const s = seasonIdx(S), e = EX(S), w = techSum(S, 'wint'), wk = wxNow(S, e); let m = 1;
    if (k === 'food') {
      m = [1.05, 1.15, 1.3, pid === VP ? cx(1 - 0.45 * sevK() + w - harsh(S), 0.25, 1) : 1 - 0.2 * sevK()][s];
      if (wk) m *= ({ rain: 1.1, drought: 0.75, harvest: 1.15, blizzard: 0.9, flood: 0.9 })[wk] || 1;
    } else if (k === 'wood') { m = s === 3 ? 0.9 : 1; if (wk === 'flood') m *= 0.8; }
    else if (k === 'mine') m = s === 3 ? 0.9 : 1;
    return m;
  }
  function moveMul(S) {
    const s = seasonIdx(S), e = EX(S), wk = wxNow(S, e); let m = [1, 1.05, 1, 1 - 0.2 * sevK() + techSum(S, 'wint') * 0.5][s];
    if (wk === 'blizzard') m *= 0.6; else if (wk === 'storm') m *= 0.75;
    return cx(m, 0.4, 1.1);
  }
  RFX.season = S => SEAS[seasonIdx(S)];
  function seasonTick(S, e) {
    const s = seasonIdx(S), st = e.st;
    if (st.ls < 0) st.ls = s;
    if (s === 3 && S.players[VP].stock.food <= 0.5) st.ws = 1;
    if (s !== st.ls) {
      if (st.ls === 3 && !st.ws) { st.winters++; tell(S, L('Winter survived', 'Musim dingin terlewati'), L('Your people made it through the cold without starving.', 'Rakyatmu melewati musim dingin tanpa kelaparan.')); }
      if (s === 3) st.ws = 0;
      st.ls = s;
      if (RFX.cfg.season) evRoll(S, e, s);
      if (RFX.cfg.season) tell(S, L(SEAS[s].n[0], SEAS[s].n[1]) + ' ' + SEAS[s].e, L(SEAS[s].d[0], SEAS[s].d[1]), 'pol', true);
    }
  }
  function weatherStep(S, e) {
    const wx = e.wx; if (wx.k && wx.until <= S.time) wx.k = null;
    if (!RFX.cfg.season || wx.k || S.rnd() > 0.3) return;
    const pool = [['rain', 'flood', 'rain'], ['drought', 'rain', 'storm'], ['harvest', 'storm', 'rain'], ['blizzard', 'blizzard', 'storm']][seasonIdx(S)];
    wx.k = pool[Math.floor(S.rnd() * pool.length)]; wx.until = S.time + DAY * (0.8 + S.rnd() * 0.8);
    toast(S, L('Weather', 'Cuaca') + ' ' + WX[wx.k].e, L(WX[wx.k].n[0], WX[wx.k].n[1]) + ': ' + L(WX[wx.k].d[0], WX[wx.k].d[1]), true);
  }
  /* kait ke fungsi inti game */
  const _evMod = evMod;
  evMod = function (S, pid, k) {
    let v = _evMod(S, pid, k);
    try { if (on(S)) { if (RFX.cfg.season) v *= seasonMul(S, pid, k); if (pid === VP) v *= faithMul(S, k); } } catch (e) { }
    return v;
  };
  const _tickMove = tickMove;
  tickMove = function (S, dt) { let f = 1; try { if (on(S) && RFX.cfg.season) f = moveMul(S); } catch (e) { } return _tickMove(S, dt * f); };
  const _calcRates = calcRates;
  calcRates = function (S) {
    _calcRates(S);
    try { if (on(S)) { const p = S.players[VP], e = EX(S); if (e.rl.faith === 'sun' && p.rate.gold > 0) p.rate.gold *= 1 + faithMag(e); } } catch (er) { }
  };
  const _updateHud = updateHud;
  updateHud = function () {
    _updateHud.apply(this, arguments);
    try {
      const S = UI.S; if (!on(S) || !RFX.cfg.season) return; const el = $('clock'), e = EX(S), s = SEAS[seasonIdx(S)], wk = wxNow(S, e);
      if (el) el.textContent += ' ' + s.e + (wk ? WX[wk].e : '');
    } catch (er) { }
  };
  function fxDraw(c, S) {
    if (!RFX.cfg.season || !RFX.cfg.fx) return;
    const s = seasonIdx(S), e = EX(S), wk = wxNow(S, e); let tint = null, kind = null, n = 0;
    if (s === 1) tint = 'rgba(255,196,80,0.05)'; else if (s === 2) tint = 'rgba(214,110,40,0.07)'; else if (s === 3) { tint = 'rgba(170,205,255,0.11)'; kind = 'snow'; n = 70; }
    if (wk === 'rain' || wk === 'storm' || wk === 'flood') { tint = 'rgba(40,60,90,0.16)'; kind = 'rain'; n = wk === 'storm' ? 140 : 90; }
    else if (wk === 'blizzard') { tint = 'rgba(225,235,255,0.2)'; kind = 'snow'; n = 170; }
    else if (wk === 'drought') tint = 'rgba(255,150,40,0.10)';
    else if (wk === 'harvest' || (s === 2 && !wk)) { kind = kind || 'leaf'; n = n || 24; }
    if (!tint && !kind) return;
    const cv = RN.cv, W = cv.width, H = cv.height, d = RN.dpr || 1, t = performance.now() / 1000;
    c.save(); c.setTransform(1, 0, 0, 1, 0, 0);
    if (tint) { c.fillStyle = tint; c.fillRect(0, 0, W, H); }
    if (kind === 'snow') {
      c.fillStyle = 'rgba(255,255,255,.85)';
      for (let i = 0; i < n; i++) { const h1 = (Math.imul(i + 1, 2654435761) >>> 0) / 4294967296, h2 = (Math.imul(i + 7, 2246822519) >>> 0) / 4294967296; const x = (((h1 * W + Math.sin(t * 0.9 + i) * 18 * d + t * 12 * d) % W) + W) % W, y = (h2 * H + t * (35 + h1 * 35) * d) % H; c.fillRect(x, y, (1.5 + h2 * 1.5) * d, (1.5 + h2 * 1.5) * d); }
    } else if (kind === 'rain') {
      c.strokeStyle = 'rgba(170,200,255,.55)'; c.lineWidth = d; c.beginPath();
      for (let i = 0; i < n; i++) { const h1 = (Math.imul(i + 1, 2654435761) >>> 0) / 4294967296, h2 = (Math.imul(i + 7, 2246822519) >>> 0) / 4294967296; const x = (h1 * W + t * 60 * d) % W, y = (h2 * H + t * (420 + h1 * 160) * d) % H; c.moveTo(x, y); c.lineTo(x - 4 * d, y + 12 * d); }
      c.stroke();
    } else if (kind === 'leaf') {
      for (let i = 0; i < n; i++) { const h1 = (Math.imul(i + 1, 2654435761) >>> 0) / 4294967296, h2 = (Math.imul(i + 7, 2246822519) >>> 0) / 4294967296; const x = (((h1 * W + t * 25 * d + Math.sin(t + i) * 20 * d) % W) + W) % W, y = (h2 * H + t * (22 + h1 * 20) * d) % H; c.fillStyle = i % 3 ? '#d9822b' : '#b5532a'; c.fillRect(x, y, 3 * d, 2 * d); }
    }
    c.restore();
  }

  /* ================= 2. SPIONASE ================= */
  const SPY = {
    scout: { c: 40, b: 0.85, n: ['Scout', 'Intai'], d: ['Reveal their treasury, army and cities.', 'Lihat kas, pasukan, dan kota mereka.'] },
    steal: { c: 60, b: 0.6, n: ['Steal', 'Curi'], d: ['Steal gold from their treasury.', 'Curi emas dari kas mereka.'] },
    sabo: { c: 90, b: 0.52, n: ['Sabotage', 'Sabotase'], d: ['Burn granaries and stockpiles.', 'Bakar lumbung dan gudang mereka.'] },
    incite: { c: 80, b: 0.5, n: ['Incite', 'Hasut'], d: ['Stir unrest in one of their cities.', 'Picu kerusuhan di salah satu kota mereka.'] }
  };
  const hasIntelChief = S => { try { const r = R(S); return (r.extra[VP] || []).some(k => { const c = r.chars[k]; return c && !c.dead && /Intelijen/.test(c.t); }); } catch (e) { return false; } };
  const hqN = e => e.bl.filter(b => b.k === 'hq').length, spyCap = e => 1 + Math.floor(e.sp.lv / 2) + hqN(e), spyCost = (e, k) => Math.ceil(SPY[k].c * (hqN(e) ? 0.8 : 1));
  function spyChance(S, e, k, tid) {
    let c = SPY[k].b + 0.04 * (e.sp.lv - 1) + techSum(S, 'spy') + (hasIntelChief(S) ? 0.08 : 0) + 0.06 * hqN(e);
    if (rel(S, VP, tid).ally) c += 0.1;
    return cx(c, 0.1, 0.95);
  }
  function spyGo(S, tid, k) {
    const e = EX(S), sp = e.sp, p = S.players[VP], t = S.players[tid], d = SPY[k];
    if (!t || !t.alive || tid === VP || !d) return;
    if (sp.ops.length >= spyCap(e)) return say(L('All your agents are busy', 'Semua agenmu sedang bertugas'), false);
    if ((sp.cd[tid + k] || 0) > S.time) return say(L('That mission needs time to cool down', 'Misi itu butuh waktu jeda'), false);
    const cost = spyCost(e, k); if (p.stock.gold < cost) return say(L('Not enough gold: ', 'Emas kurang: ') + cost, false);
    p.stock.gold -= cost; sp.cd[tid + k] = S.time + DAY * 0.6;
    sp.ops.push({ id: sp.nid++, tid, k, at: S.time + 10 + S.rnd() * 10 });
    say(L('Agent sent to ', 'Agen dikirim ke ') + t.name, true);
  }
  function spyCounter(S) {
    const e = EX(S), p = S.players[VP], sp = e.sp;
    if (sp.ctr > S.time) return say(L('Counter-intelligence is already active', 'Kontra-intelijen sudah aktif'), false);
    if (p.stock.gold < 50) return say(L('Not enough gold: 50', 'Emas kurang: 50'), false);
    p.stock.gold -= 50; sp.ctr = S.time + RY; say(L('Counter-intelligence active for a year', 'Kontra-intelijen aktif selama setahun'), true);
  }
  function spySnapshot(S, tid) {
    const t = S.players[tid], ru = rulerOf(S, tid);
    return { t: S.time, gold: Math.floor(t.stock.gold), food: Math.floor(t.stock.food), iron: Math.floor(t.stock.iron), cities: S.cities.filter(c => c.owner === tid).length, units: armyUnits(S, tid), power: Math.floor(milPower(S, tid)), ruler: ru ? ru.name : '?', faith: faithOf(t) };
  }
  function spyResolve(S, e, op) {
    const sp = e.sp, p = S.players[VP], t = S.players[op.tid]; if (!t || !t.alive) return;
    const ok = S.rnd() < spyChance(S, e, op.k, op.tid), nm = L(SPY[op.k].n[0], SPY[op.k].n[1]);
    if (ok) {
      let txt = '';
      if (op.k === 'scout') { sp.intel[op.tid] = spySnapshot(S, op.tid); txt = L('Report received on ', 'Laporan diterima tentang ') + t.name; }
      else if (op.k === 'steal') { const amt = Math.floor(Math.min(220, t.stock.gold * 0.12 + 10 + sp.lv * 6)); t.stock.gold = Math.max(0, t.stock.gold - amt); p.stock.gold += amt; txt = L('Stole ', 'Mencuri ') + amt + L(' gold from ', ' emas dari ') + t.name; }
      else if (op.k === 'sabo') { t.stock.food *= 0.7; t.stock.wood *= 0.85; t.stock.iron *= 0.8; txt = t.name + L(': granaries and stockpiles burned', ': lumbung dan gudang terbakar'); }
      else { const cs = S.cities.filter(c => c.owner === op.tid); const c = cs.filter(q => !q.isCap)[0] ? cs.filter(q => !q.isCap)[Math.floor(S.rnd() * cs.filter(q => !q.isCap).length)] : cs[0]; if (c) { c.unrest = cx((c.unrest === undefined ? 25 : c.unrest) + 28, 0, 100); txt = L('Unrest spreads in ', 'Kerusuhan meluas di ') + c.name; } }
      sp.ok++; sp.xp++; sp.lv = Math.min(6, 1 + Math.floor(sp.xp / 3));
      tell(S, L('Spy success: ', 'Mata-mata berhasil: ') + nm, txt);
    } else {
      sp.fail++; const r = rel(S, VP, op.tid), caught = S.rnd() < 0.5;
      if (op.k !== 'scout') r.op -= caught ? 25 : 8; else r.op -= caught ? 10 : 0;
      if (caught && op.k !== 'scout' && r.st === 'peace' && !r.ally && S.rnd() < 0.2) r.trade = false;
      tell(S, L('Spy failed: ', 'Mata-mata gagal: ') + nm, caught ? t.name + L(' caught your agent! Relations worsen.', ' menangkap agenmu! Hubungan memburuk.') : L('The agent returned empty-handed.', 'Agen pulang dengan tangan kosong.'));
    }
  }
  function spyTick(S, e) {
    const sp = e.sp; if (!sp.ops.length) return;
    const due = sp.ops.filter(o => o.at <= S.time); if (!due.length) return;
    sp.ops = sp.ops.filter(o => o.at > S.time);
    for (const o of due) spyResolve(S, e, o);
  }
  function spyAIDay(S, e) {   // mata-mata musuh menyerang kita
    if (!RFX.cfg.aiSpy) return;
    const sp = e.sp, p = S.players[VP];
    for (const f of foes(S)) {
      const r = rel(S, VP, f.id); if (!(r.st === 'war' || r.op < -30)) continue; if (S.rnd() > 0.1) continue;
      const k = ['steal', 'incite', 'sabo'][Math.floor(S.rnd() * 3)];
      const catchP = cx(0.35 + 0.05 * (sp.lv - 1) + techSum(S, 'spy') + (sp.ctr > S.time ? 0.25 : 0), 0.1, 0.9);
      if (S.rnd() < catchP) { r.op += 3; tell(S, L('Enemy spy caught', 'Mata-mata musuh tertangkap'), f.name + L(' sent a spy, but he was caught.', ' mengirim mata-mata, tapi tertangkap.')); continue; }
      if (k === 'steal') { const a = Math.floor(Math.min(80, p.stock.gold * 0.06)); p.stock.gold -= a; f.stock.gold += a; tell(S, L('Gold stolen', 'Emas dicuri'), f.name + L(' spies stole ', ' mencuri ') + a + L(' gold.', ' emas.')); }
      else if (k === 'incite') { const cs = myCities(S); const c = cs[Math.floor(S.rnd() * cs.length)]; if (c) { c.unrest = cx((c.unrest === undefined ? 25 : c.unrest) + 15, 0, 100); tell(S, L('Agitators at work', 'Penghasut beraksi'), f.name + L(' stirs unrest in ', ' memicu kerusuhan di ') + c.name); } }
      else { p.stock.food *= 0.88; tell(S, L('Sabotage', 'Sabotase'), f.name + L(' spies burned part of your granaries.', ' membakar sebagian lumbungmu.')); }
    }
  }

  /* ================= 3. PERNIKAHAN POLITIK ================= */
  const MR_TIERS = [0, 100, 250];
  function mrKids(S) { const r = R(S), fam = r.fam[VP]; if (!fam) return []; return fam.kids.map(k => r.people[k]).filter(c => c && !c.dead && c.umur >= 16 && !c.asing && !c.nikah); }
  function mrChance(S, tid, tier) {
    const r = rel(S, VP, tid), e = EX(S); if (r.st === 'war') return 0;
    let c = 0.3 + r.op / 250 + (r.trade ? 0.1 : 0) + (r.ally ? 0.2 : 0) + tier * 0.1 - (r.st === 'truce' ? 0.1 : 0);
    if (e.rl.faith) c += e.rl.faith === faithOf(S.players[tid]) ? 0.08 : -0.08;
    return cx(c, 0.05, 0.95);
  }
  function mrApply(S, e, kid, tid) {
    const r = rel(S, VP, tid), t = S.players[tid];
    kid.asing = 1; kid.nikah = { pid: tid, t: S.time };
    e.mr.list.push({ ck: kid.ck, name: kid.name, pid: tid, t: S.time });
    r.ally = true; r.op = Math.min(100, r.op + 30); if (r.st === 'truce') r.st = 'peace';
    for (const c of myCities(S)) c.unrest = cx((c.unrest === undefined ? 25 : c.unrest) - 8, 0, 100);
    tell(S, L('Royal wedding!', 'Pernikahan kerajaan!'), cname(kid) + L(' wed into ', ' menikah ke ') + t.name + L('. An alliance is sealed.', '. Aliansi pun terjalin.'), 'life');
  }
  function mrPropose(S, tid) {
    const e = EX(S), p = S.players[VP], ui = e.mr.ui, kid = R(S).people[ui.kid], t = S.players[tid], tier = ui.tier | 0, cost = MR_TIERS[tier];
    if (!kid || kid.dead || kid.asing || kid.nikah) return say(L('Choose a royal child first', 'Pilih anak raja dulu'), false);
    if (!t || !t.alive) return;
    if ((e.mr.cd[tid] || 0) > S.time) return say(L('They need time before another proposal', 'Mereka butuh waktu sebelum lamaran berikutnya'), false);
    if (p.stock.gold < cost) return say(L('Not enough gold: ', 'Emas kurang: ') + cost, false);
    const ch = mrChance(S, tid, tier); if (!ch) return say(L('No marriage during war', 'Tak bisa menikah saat perang'), false);
    p.stock.gold -= cost;
    if (S.rnd() < ch) { mrApply(S, e, kid, tid); ui.kid = null; }
    else { e.mr.cd[tid] = S.time + DAY; rel(S, VP, tid).op -= 4; tell(S, L('Proposal refused', 'Lamaran ditolak'), t.name + L(' politely declined the match.', ' menolak lamaran dengan sopan.')); }
  }
  function mrAnswer(S, i, yes) {
    const e = EX(S), p = S.players[VP], inc = e.mr.inc[i]; if (!inc) return; e.mr.inc.splice(i, 1);
    if (!yes) { rel(S, VP, inc.pid).op -= 2; return; }
    const kid = R(S).people[inc.ck], t = S.players[inc.pid];
    if (!kid || kid.dead || kid.asing || kid.nikah || !t || !t.alive) return say(L('That match is no longer possible', 'Perjodohan itu tak lagi mungkin'), false);
    const g = Math.floor(Math.min(120, t.stock.gold)); t.stock.gold -= g; p.stock.gold += g;
    mrApply(S, e, kid, inc.pid); if (g) say(L('Dowry received: ', 'Mas kawin diterima: ') + g, true);
  }
  function mrClaimWar(S, tid) {
    const e = EX(S), p = S.players[VP], c = e.mr.claims[tid]; if (!c || c.until < S.time) return say(L('The claim has expired', 'Klaim sudah kedaluwarsa'), false);
    if (p.stock.gold < 120) return say(L('Not enough gold: 120', 'Emas kurang: 120'), false);
    const cap = S.cities.find(q => q.isCap && q.owner === tid); p.stock.gold -= 120;
    const r = rel2(S, VP, tid); r.ally = false; if (r.st !== 'war') startWar(S, VP, tid);
    e.mr.war[tid] = cap ? cap.id : -1; delete e.mr.claims[tid];
    tell(S, L('War of succession', 'Perang suksesi'), L('You march to claim the throne of ', 'Kau maju menuntut takhta ') + S.players[tid].name + '.', 'war');
  }
  function mrDay(S, e) {
    const m = e.mr;
    m.inc = m.inc.filter(q => q.until > S.time);
    for (const l of m.list) {
      if (l.end) continue; const kid = R(S).people[l.ck];
      if (!kid || kid.dead) { l.end = 1; rel(S, VP, l.pid).op -= 10; tell(S, L('Marriage ended', 'Pernikahan berakhir'), l.name + L(' has died. The bond with ', ' telah wafat. Ikatan dengan ') + S.players[l.pid].name + L(' weakens.', ' melemah.'), 'life'); }
    }
    for (const f of foes(S)) {
      const ru = rulerOf(S, f.id), nm = ru ? ru.name : '', old = m.rul[f.id];
      if (old === undefined) { m.rul[f.id] = nm; continue; }
      if (nm && old !== nm) {
        m.rul[f.id] = nm;
        if (m.list.some(l => !l.end && l.pid === f.id) && !m.war[f.id]) { m.claims[f.id] = { until: S.time + DAY * 6 }; tell(S, L('Throne claim', 'Klaim takhta'), f.name + L(' has a new ruler. Your child\'s marriage gives you a claim to the throne!', ' punya penguasa baru. Pernikahan anakmu memberimu klaim atas takhta!'), 'war'); }
      }
    }
    for (const k of Object.keys(m.claims)) if (m.claims[k].until < S.time) delete m.claims[k];
    for (const k of Object.keys(m.war)) {
      const tid = +k, capId = m.war[k], c = S.cities.find(q => q.id === capId);
      if (c && c.owner === VP) { delete m.war[k]; e.st.throne++; S.players[VP].stock.gold += 400; tell(S, L('Throne seized!', 'Takhta direbut!'), L('You took the capital of ', 'Kau merebut ibu kota ') + S.players[tid].name + L('! +400 gold.', '! +400 emas.'), 'war'); }
      else if (!S.players[tid] || !S.players[tid].alive || rel(S, VP, tid).st !== 'war') delete m.war[k];
    }
  }
  function mrYear(S, e) {
    const m = e.mr, act = m.list.filter(l => !l.end);
    if (act.length) { const g = 40 * act.length; S.players[VP].stock.gold += g; for (const l of act) { const r = rel(S, VP, l.pid); r.op = Math.min(100, r.op + 2); } tell(S, L('Royal gifts', 'Hadiah kerajaan'), L('Your in-laws send ', 'Besan mengirim ') + g + L(' gold.', ' emas.'), 'life', true); }
    const kids = mrKids(S); if (!kids.length) return;
    for (const f of foes(S)) {
      const r = rel(S, VP, f.id); if (r.st === 'war' || r.op < 15 || m.inc.length >= 3) continue;
      if (m.list.some(l => !l.end && l.pid === f.id) || m.inc.some(q => q.pid === f.id)) continue;
      if (S.rnd() < 0.12) { const kid = kids[Math.floor(S.rnd() * kids.length)]; m.inc.push({ pid: f.id, ck: kid.ck, until: S.time + DAY * 4 }); tell(S, L('Marriage proposal', 'Lamaran masuk'), f.name + L(' asks for the hand of ', ' melamar ') + kid.name + '.', 'life'); }
    }
  }

  /* ================= 4. AGAMA ================= */
  const FA = {
    sun: { e: '☀', n: ['Order of the Sun', 'Orde Matahari'], d: ['Gold income +', 'Pendapatan emas +'] },
    green: { e: '❦', n: ['Green Path', 'Jalan Hijau'], d: ['Food production +', 'Produksi pangan +'] },
    iron: { e: '⚔', n: ['Iron Creed', 'Ajaran Besi'], d: ['Army attack +', 'Serangan pasukan +'] }
  };
  const faithName = f => L(FA[f].n[0], FA[f].n[1]);
  function faithMag(e) { return e.rl.faith ? 0.04 + 0.12 * e.rl.piety / 100 : 0; }
  function faithMul(S, k) { const e = EX(S); return e.rl.faith === 'green' && k === 'food' ? 1 + faithMag(e) : 1; }
  function faithChoose(S, f) {
    const e = EX(S), rl = e.rl, p = S.players[VP]; if (!FA[f] || rl.faith === f) return;
    if (rl.faith) {
      if (p.stock.gold < 100) return say(L('Not enough gold: 100', 'Emas kurang: 100'), false);
      p.stock.gold -= 100; for (const c of myCities(S)) c.unrest = cx((c.unrest === undefined ? 25 : c.unrest) + 8, 0, 100);
      for (const c of myCities(S)) c.fx = f;
      tell(S, L('Religious reform', 'Reformasi agama'), L('The realm adopts the ', 'Kerajaan memeluk ') + faithName(f) + L('. The people grumble.', '. Rakyat mengeluh.'));
    } else say(L('Faith chosen: ', 'Agama dipilih: ') + faithName(f), true);
    rl.faith = f; rl.piety = 10;
  }
  function faithGive(S) {
    const e = EX(S), p = S.players[VP]; if (!e.rl.faith) return;
    if (p.stock.gold < 60) return say(L('Not enough gold: 60', 'Emas kurang: 60'), false);
    p.stock.gold -= 60; e.rl.piety = cx(e.rl.piety + 12, 0, 100); say(L('Offering made. Piety +12', 'Persembahan diberikan. Kesalehan +12'), true);
  }
  function faithMission(S, cid) {
    const e = EX(S), p = S.players[VP], c = S.cities.find(q => q.id === +cid && q.owner === VP); if (!c || !e.rl.faith) return;
    if (p.stock.gold < 50) return say(L('Not enough gold: 50', 'Emas kurang: 50'), false);
    p.stock.gold -= 50;
    if (S.rnd() < 0.75) { c.fx = e.rl.faith; c.unrest = cx((c.unrest === undefined ? 25 : c.unrest) - 5, 0, 100); say(c.name + L(' converted', ' berpindah keyakinan'), true); }
    else { e.rl.piety = cx(e.rl.piety - 2, 0, 100); say(L('The missionary was driven out', 'Misionaris diusir'), false); }
  }
  function faithDay(S, e) {
    const rl = e.rl;
    for (const c of S.cities) if (c.owner >= 0 && c.owner !== VP) c.fx = faithOf(S.players[c.owner]);
    if (!rl.faith) return;
    const tn = e.bl.filter(b => b.k === 'temple').length; rl.piety = cx(rl.piety + techSum(S, 'faith') + 0.5 * tn - (rl.piety > 60 ? 0.8 : 0.3), 0, 100);
    const relief = rl.piety / 60 + 0.3 * tn;
    for (const c of myCities(S)) { const u = c.unrest === undefined ? 25 : c.unrest, foreign = c.fx && c.fx !== rl.faith; c.unrest = cx(u - relief + (foreign ? 0.9 : 0), 0, 100); }
  }
  function faithYear(S, e) {
    const rl = e.rl; if (!rl.faith) return;
    for (const f of foes(S)) { const r = rel(S, VP, f.id); if (faithOf(f) === rl.faith) r.op = Math.min(100, r.op + 3); else if (r.op > -60) r.op -= 1; }
    if (rl.piety < 12 && S.rnd() < 0.25) {
      const cs = myCities(S), c = cs[Math.floor(S.rnd() * cs.length)];
      if (c) { c.unrest = cx((c.unrest === undefined ? 25 : c.unrest) + 15, 0, 100); rl.piety += 10; tell(S, L('Schism!', 'Perpecahan sekte!'), L('Heretics stir trouble in ', 'Para bidah membuat onar di ') + c.name + '.'); }
    }
  }
  const foreignCities = (S, e) => (e.rl.faith ? myCities(S).filter(c => c.fx && c.fx !== e.rl.faith) : []);

  /* ================= 5. RUTE DAGANG PERMANEN ================= */
  const rtMax = S => Math.min(10, 2 + S.buildings.filter(b => b.owner === VP && b.type === 'market' && !(b.cons > 0)).length);
  const rtCost = len => 40 + len * 2;
  function rtInc(S, rt) { return (5 + rt.len * 0.3) * (1 + techSum(S, 'trade')) * (1 + 0.3 * (rt.lv - 1)) * (rt.fo ? 1.4 : 1) * (RFX.cfg.season && seasonIdx(S) === 3 ? 0.8 : 1); }
  function rtCreate(S, aid, bid) {
    const e = EX(S), p = S.players[VP], a = S.cities.find(c => c.id === +aid && c.owner === VP), b = S.cities.find(c => c.id === +bid);
    if (!a || !b || a.id === b.id) return;
    if (e.rt.list.length >= rtMax(S)) return say(L('Route limit reached. Build more markets.', 'Batas rute tercapai. Bangun lebih banyak pasar.'), false);
    if (e.rt.list.some(r => (r.a === a.id && r.b === b.id) || (r.a === b.id && r.b === a.id))) return say(L('That route already exists', 'Rute itu sudah ada'), false);
    if (b.owner < 0 || (b.owner !== VP && atWar(S, VP, b.owner))) return say(L('Cannot trade with an enemy', 'Tak bisa berdagang dengan musuh'), false);
    const path = MODS.landPath(S, a, b); if (!path || path.length < 2) return say(L('No land route between these cities', 'Tak ada jalur darat antar kota ini'), false);
    const cost = rtCost(path.length); if (p.stock.gold < cost) return say(L('Not enough gold: ', 'Emas kurang: ') + cost, false);
    p.stock.gold -= cost;
    e.rt.list.push({ id: e.rt.nid++, a: a.id, b: b.id, len: path.length, path, lv: 1, guard: 0, fo: b.owner !== VP ? 1 : 0, bo: b.owner, st: 'ok', earn: 0 });
    e.rt.ui.a = null; say(L('Trade route opened: ', 'Rute dagang dibuka: ') + a.name + ' ↔ ' + b.name, true);
  }
  function rtUpgrade(S, id) {
    const e = EX(S), p = S.players[VP], rt = e.rt.list.find(r => r.id === +id); if (!rt || rt.lv >= 3) return;
    const cost = 100 * rt.lv; if (p.stock.gold < cost) return say(L('Not enough gold: ', 'Emas kurang: ') + cost, false);
    p.stock.gold -= cost; rt.lv++; say(L('Route upgraded', 'Rute ditingkatkan'), true);
  }
  function rtFlags(S, e) {
    for (const rt of e.rt.list) {
      rt.st = 'ok'; const smp = []; for (let i = 0; i < rt.path.length; i += 5) smp.push(rt.path[i]);
      for (const a of S.armies) { if (a.ship || a.owner === VP || !atWar(S, VP, a.owner)) continue; if (smp.some(s => Math.abs(s[0] - a.x) < 3.5 && Math.abs(s[1] - a.y) < 3.5)) { rt.st = 'block'; break; } }
    }
  }
  function rtDay(S, e) {
    const p = S.players[VP]; let tot = 0;
    e.rt.list = e.rt.list.filter(rt => {
      const a = S.cities.find(c => c.id === rt.a), b = S.cities.find(c => c.id === rt.b);
      if (!a || a.owner !== VP || !b || b.owner < 0) { tell(S, L('Trade route lost', 'Rute dagang hilang'), L('A route was cut when a city changed hands.', 'Sebuah rute putus karena kota berpindah tangan.'), 'trade'); return false; }
      if (b.owner !== VP && atWar(S, VP, b.owner)) { tell(S, L('Trade route cut', 'Rute dagang putus'), L('War closed the route to ', 'Perang menutup rute ke ') + b.name + '.', 'trade'); return false; }
      rt.fo = b.owner !== VP ? 1 : 0; rt.bo = b.owner; return true;
    });
    rtFlags(S, e);
    for (const rt of e.rt.list) {
      if (rt.guard) { if (p.stock.gold >= 4) p.stock.gold -= 4; else rt.guard = 0; }
      if (rt.st === 'block') { tell(S, L('Route blockaded', 'Rute diblokade'), L('Enemy troops block your trade route.', 'Pasukan musuh memblokade rute dagangmu.'), 'trade', true); continue; }
      const inc = rtInc(S, rt);
      if (!rt.guard && S.rnd() < 0.05) { const loss = Math.floor(inc * 2); p.stock.gold = Math.max(0, p.stock.gold - loss); tell(S, L('Bandit raid!', 'Perampokan!'), L('Bandits robbed a caravan: -', 'Bandit merampok kafilah: -') + loss + L(' gold. Hire guards!', ' emas. Sewa pengawal!'), 'trade'); continue; }
      p.stock.gold += inc; rt.earn += inc; e.rt.earn += inc; tot += inc;
      if (rt.fo && rt.bo >= 0 && S.players[rt.bo] && S.players[rt.bo].alive) S.players[rt.bo].stock.gold += inc * 0.4;
    }
    e.rt.today = Math.floor(tot);
  }
  function rtDraw(c, S, vx0, vx1, vy0, vy1) {
    const e = EX(S); if (!e.rt.list.length) return; const t = performance.now() / 1000;
    for (const rt of e.rt.list) {
      const P = rt.path; if (!P || P.length < 2) continue;
      c.save(); c.strokeStyle = rt.st === 'block' ? 'rgba(255,90,70,.75)' : 'rgba(240,200,110,.6)'; c.lineWidth = 1.4; c.setLineDash([3, 3]); c.beginPath();
      let pen = false;
      for (let i = 0; i < P.length; i++) { const x = P[i][0], y = P[i][1], vis = x >= vx0 - 2 && x <= vx1 + 2 && y >= vy0 - 2 && y <= vy1 + 2; if (!vis) { pen = false; continue; } if (!pen) { c.moveTo((x + 0.5) * TS, (y + 0.5) * TS); pen = true; } else c.lineTo((x + 0.5) * TS, (y + 0.5) * TS); }
      c.stroke(); c.setLineDash([]);
      if (rt.st !== 'block') for (let k = 0; k < 2; k++) {
        const u = (t * 0.03 + rt.id * 0.37 + k * 0.5) % 1, i = Math.min(P.length - 1, Math.floor(u * (P.length - 1))), q = P[i]; if (q[0] < vx0 - 2 || q[0] > vx1 + 2 || q[1] < vy0 - 2 || q[1] > vy1 + 2) continue;
        c.fillStyle = '#2b1c0e'; c.fillRect((q[0] + 0.5) * TS - 3, (q[1] + 0.5) * TS - 2, 6, 4); c.fillStyle = '#f0c56a'; c.fillRect((q[0] + 0.5) * TS - 2, (q[1] + 0.5) * TS - 3, 4, 3);
      }
      c.restore();
    }
  }

  /* ================= 6. TEKNOLOGI TAMBAHAN ================= */
  function T(id, cat, nEn, nId, dEn, dId, c, t, props) {
    return Object.assign({ id, cat, c, t, get n() { return L(nEn, nId); }, get d() { return L(dEn, dId); } }, props);
  }
  const NEWT = [
    T('intai', 'Intelijen', 'Scout Network', 'Jaringan Pengintai', 'Spy success +5%', 'Keberhasilan mata-mata +5%', 90, 120, { spy: 0.05 }),
    T('sandi', 'Intelijen', 'Secret Cipher', 'Sandi Rahasia', 'Spy success +5%', 'Keberhasilan mata-mata +5%', 150, 170, { spy: 0.05 }),
    T('bayang', 'Intelijen', 'Shadow Academy', 'Akademi Bayangan', 'Spy success +8%', 'Keberhasilan mata-mata +8%', 230, 230, { spy: 0.08 }),
    T('upacara', 'Budaya', 'Rites & Rituals', 'Tata Upacara', 'Piety +0.6 per day', 'Kesalehan +0.6 per hari', 80, 110, { faith: 0.6 }),
    T('pustaka', 'Budaya', 'Holy Library', 'Perpustakaan Suci', 'Piety +0.8 per day', 'Kesalehan +0.8 per hari', 150, 170, { faith: 0.8 }),
    T('festival', 'Budaya', 'Grand Festival', 'Festival Raya', '+3 gold daily, piety +0.6', '+3 emas harian, kesalehan +0.6', 220, 220, { faith: 0.6, gold: 3 }),
    T('gudangd', 'Musim', 'Winter Storehouse', 'Gudang Musim Dingin', 'Winter harvest +10%', 'Panen musim dingin +10%', 80, 110, { wint: 0.10 }),
    T('wol', 'Musim', 'Wool Cloaks', 'Mantel Wol', 'Winter harvest +10%, march speed up', 'Panen dingin +10%, pasukan lebih cepat', 140, 160, { wint: 0.10 }),
    T('cadangan', 'Musim', 'Reserve Granary', 'Lumbung Cadangan', 'Winter harvest +10%', 'Panen musim dingin +10%', 210, 220, { wint: 0.10 }),
    T('garnisun', 'Pertahanan', 'Field Barracks', 'Barak Lapangan', 'Troops heal in your land', 'Pasukan pulih di wilayahmu', 90, 120, { heal: 0.15 }),
    T('tabib', 'Pertahanan', 'War Healers', 'Tabib Perang', 'Faster troop healing', 'Pemulihan pasukan lebih cepat', 160, 180, { heal: 0.2 }),
    T('benteng', 'Pertahanan', 'Border Fortress', 'Benteng Perbatasan', 'Much faster troop healing', 'Pemulihan pasukan jauh lebih cepat', 240, 240, { heal: 0.3 })
  ];
  for (const x of NEWT) if (!RF_TECH.some(q => q.id === x.id)) RF_TECH.push(x);
  RF_TECH_TAB.CIVIL = ['Intelijen', 'Budaya']; RF_TECH_TAB.NATURE = ['Musim', 'Pertahanan'];
  Object.assign(RF_CAT_ICON, { Intelijen: 'mail', Budaya: 'medal', Musim: 'food', Pertahanan: 'armH' });
  Object.assign(RF_TECH_ICON, { intai: 'mail', sandi: 'mail', bayang: 'mail', upacara: 'medal', pustaka: 'medal', festival: 'gold', gudangd: 'food', wol: 'wood', cadangan: 'food', garnisun: 'armL', tabib: 'armH', benteng: 'armH' });
  function healTick(S, dt) {
    const h = techSum(S, 'heal'); if (!h) return;
    for (const a of S.armies) {
      if (a.owner !== VP || a.ship || a.fight) continue;
      if (S.terr[Math.floor(a.y) * S.W + Math.floor(a.x)] !== VP) continue;
      for (const q of a.sq) { const mx = SQ[q.t].hp; let ch = false; for (const s of q.s) if (s.hp < mx) { s.hp = Math.min(mx, s.hp + h * dt); ch = true; } if (ch) syncSq(q); }
    }
  }

  /* ================= 7. MISI, PRESTASI, KAMPANYE, HARIAN ================= */
  const ownCount = (S, t) => S.buildings.filter(b => b.owner === VP && b.type === t && !(b.cons > 0)).length;
  const alliesN = S => foes(S).filter(f => rel(S, VP, f.id).ally).length;
  const QDEF = [
    { id: 'cities', t: ['Own %n cities', 'Kuasai %n kota'], get: S => myCities(S).length, goal: c => c + 1, rw: 150 },
    { id: 'market', t: ['Have %n markets', 'Miliki %n pasar'], get: S => ownCount(S, 'market'), goal: c => c + 1, rw: 120 },
    { id: 'farm', t: ['Have %n farms', 'Miliki %n ladang'], get: S => ownCount(S, 'farm'), goal: c => c + 2, rw: 110 },
    { id: 'tech', t: ['Research %n technologies', 'Riset %n teknologi'], get: S => techS(S).done.length, goal: c => c + 1, rw: 140 },
    { id: 'spy', t: ['Succeed in %n spy missions', 'Sukses %n misi mata-mata'], get: (S, e) => e.sp.ok, goal: c => c + 1, rw: 120 },
    { id: 'route', t: ['Open %n trade routes', 'Buka %n rute dagang'], get: (S, e) => e.rt.list.length, goal: c => c + 1, rw: 130 },
    { id: 'gold', t: ['Hold %n gold', 'Kumpulkan %n emas'], get: S => Math.floor(S.players[VP].stock.gold), goal: c => Math.max(600, Math.ceil(c * 1.5 / 100) * 100), rw: 150 },
    { id: 'army', t: ['Field %n soldiers', 'Miliki %n prajurit'], get: S => armyUnits(S, VP), goal: c => c + 12, rw: 140 },
    { id: 'ally', t: ['Have %n allies', 'Miliki %n sekutu'], get: S => alliesN(S), goal: c => c + 1, rw: 160 },
    { id: 'piety', t: ['Reach piety %n', 'Capai kesalehan %n'], get: (S, e) => (e.rl.faith ? Math.floor(e.rl.piety) : 0), goal: c => Math.min(100, Math.max(30, c + 25)), rw: 120 },
    { id: 'marry', t: ['Arrange %n royal marriages', 'Atur %n pernikahan kerajaan'], get: (S, e) => e.mr.list.length, goal: c => c + 1, rw: 180 },
    { id: 'winter', t: ['Survive %n winters', 'Lewati %n musim dingin'], get: (S, e) => e.st.winters, goal: c => c + 1, rw: 200 }
  ];
  const qText = (d, goal) => L(d.t[0], d.t[1]).replace('%n', goal);
  function questFill(S, e) {
    let guard = 0;
    while (e.q.act.length < 3 && guard++ < 30) {
      const d = QDEF[Math.floor(S.rnd() * QDEF.length)];
      if (e.q.act.some(q => q.k === d.id)) continue;
      if ((d.id === 'spy' || d.id === 'ally' || d.id === 'marry') && !foes(S).length) continue;
      e.q.act.push({ id: e.q.nid++, k: d.id, goal: d.goal(d.get(S, e)), rw: d.rw });
    }
  }
  function questTick(S, e) {
    const p = S.players[VP]; let changed = false;
    for (const q of e.q.act.slice()) {
      const d = QDEF.find(x => x.id === q.k); if (!d || d.get(S, e) < q.goal) continue;
      p.stock.gold += q.rw; e.q.done++; RFX.meta.qdone++; metaSave(); changed = true;
      e.q.act = e.q.act.filter(x => x !== q);
      tell(S, L('Quest complete', 'Misi selesai'), qText(d, q.goal) + ' · +' + q.rw + L(' gold', ' emas'));
    }
    if (changed || e.q.act.length < 3) questFill(S, e);
  }
  const ACH = [
    ['city2', ['First expansion', 'Ekspansi pertama'], ['Own 2 cities', 'Kuasai 2 kota'], (S, e, c) => c.cities >= 2],
    ['city6', ['Realm builder', 'Pembangun kerajaan'], ['Own 6 cities', 'Kuasai 6 kota'], (S, e, c) => c.cities >= 6],
    ['city12', ['Empire', 'Kekaisaran'], ['Own 12 cities', 'Kuasai 12 kota'], (S, e, c) => c.cities >= 12],
    ['gold3k', ['Treasure hoard', 'Timbunan harta'], ['Hold 3000 gold', 'Simpan 3000 emas'], (S, e, c) => c.gold >= 3000],
    ['tech4', ['Scholar', 'Cendekiawan'], ['Research 4 technologies', 'Riset 4 teknologi'], (S, e, c) => c.techs >= 4],
    ['tech12', ['Polymath', 'Serba tahu'], ['Research 12 technologies', 'Riset 12 teknologi'], (S, e, c) => c.techs >= 12],
    ['spy1', ['Quiet steps', 'Gerak senyap'], ['Complete a spy mission', 'Selesaikan 1 misi mata-mata'], (S, e) => e.sp.ok >= 1],
    ['spy10', ['Spymaster', 'Kepala mata-mata'], ['10 successful spy missions', '10 misi mata-mata sukses'], (S, e) => e.sp.ok >= 10],
    ['ally2', ['Diplomat', 'Diplomat'], ['Have 2 allies', 'Miliki 2 sekutu'], (S, e, c) => c.allies >= 2],
    ['wed1', ['Royal wedding', 'Pernikahan kerajaan'], ['Marry a royal child abroad', 'Nikahkan anak raja ke luar negeri'], (S, e) => e.mr.list.length >= 1],
    ['wed3', ['Dynasty builder', 'Pembangun dinasti'], ['3 political marriages', '3 pernikahan politik'], (S, e) => e.mr.list.length >= 3],
    ['throne', ['Kingmaker', 'Perebut takhta'], ['Seize a throne in a succession war', 'Rebut takhta lewat perang suksesi'], (S, e) => e.st.throne >= 1],
    ['faith70', ['Devout', 'Taat beragama'], ['Reach piety 70', 'Capai kesalehan 70'], (S, e) => e.rl.piety >= 70],
    ['route3', ['Merchant prince', 'Pangeran saudagar'], ['Open 3 trade routes', 'Buka 3 rute dagang'], (S, e) => e.rt.list.length >= 3],
    ['route1k', ['Silk road', 'Jalur sutra'], ['Earn 1000 gold from routes', 'Raih 1000 emas dari rute'], (S, e) => e.rt.earn >= 1000],
    ['win1', ['First winter', 'Musim dingin pertama'], ['Survive a winter', 'Lewati 1 musim dingin'], (S, e) => e.st.winters >= 1],
    ['win3', ['Frostproof', 'Tahan beku'], ['Survive 3 winters', 'Lewati 3 musim dingin'], (S, e) => e.st.winters >= 3],
    ['vet', ['Veteran', 'Veteran'], ['Win 10 battles', 'Menangkan 10 pertempuran'], (S, e, c, m, p) => p.wins >= 10],
    ['conq', ['Conqueror', 'Penakluk'], ['Capture 3 cities', 'Rebut 3 kota'], (S, e, c, m, p) => p.captured >= 3],
    ['year10', ['Long reign', 'Pemerintahan panjang'], ['Reign for 10 years', 'Berkuasa 10 tahun'], (S, e, c) => c.years >= 10],
    ['q5', ['Dutiful', 'Berbakti'], ['Complete 5 quests', 'Selesaikan 5 misi'], (S, e, c, m) => m.qdone >= 5],
    ['q20', ['Hero of the realm', 'Pahlawan kerajaan'], ['Complete 20 quests', 'Selesaikan 20 misi'], (S, e, c, m) => m.qdone >= 20],
    ['camp1', ['Campaigner', 'Panglima kampanye'], ['Finish a campaign chapter', 'Tamatkan 1 bab kampanye'], (S, e, c, m) => m.camp.length >= 1],
    ['camp5', ['Saga complete', 'Saga tamat'], ['Finish every campaign chapter', 'Tamatkan semua bab kampanye'], (S, e, c, m) => m.camp.length >= 5],
    ['daily1', ['Daily challenger', 'Penantang harian'], ['Finish a daily challenge', 'Selesaikan tantangan harian'], (S, e, c, m) => Object.keys(m.daily).length >= 1],
    ['streak3', ['On a roll', 'Beruntun'], ['3-day daily streak', 'Streak harian 3 hari'], (S, e, c, m) => m.streak >= 3],
    ['victory', ['Victorious', 'Pemenang'], ['Win a game', 'Menangkan sebuah permainan'], () => false]
  ];
  function achUnlock(id) {
    const m = RFX.meta; if (m.ach[id]) return; m.ach[id] = Date.now(); metaSave();
    const a = ACH.find(x => x[0] === id); if (!a) return;
    if (UI.S) toast(UI.S, L('Achievement', 'Prestasi') + ' ★', L(a[1][0], a[1][1]), false);
  }
  function achCheck(S, e) {
    const m = RFX.meta, p = S.players[VP], c = { cities: myCities(S).length, gold: p.stock.gold, techs: techS(S).done.length, allies: alliesN(S), years: Math.floor(S.time / RY) };
    for (const a of ACH) if (!m.ach[a[0]] && a[3](S, e, c, m, p)) achUnlock(a[0]);
  }
  /* ----- kampanye ----- */
  const capsOwned = S => S.cities.filter(c => c.isCap && c.owner === VP).length;
  const CH = [
    { n: ['Dawn of the Realm', 'Fajar Kerajaan'], d: ['Grow a young kingdom: 4 cities and 1000 gold within 6 years.', 'Bangun kerajaan muda: 4 kota dan 1000 emas dalam 6 tahun.'], yrs: 6, o: { type: 'continent', size: 's', bots: 1, diff: 'easy', nation: 0 },
      obj: [[['Cities', 'Kota'], S => myCities(S).length, 4], [['Gold', 'Emas'], S => Math.floor(S.players[VP].stock.gold), 1000]] },
    { n: ['The Long Winter', 'Musim Dingin Panjang'], d: ['Harsh winters ahead. Survive 3 winters without starving and hold 5 cities within 8 years.', 'Musim dingin kejam. Lewati 3 musim dingin tanpa kelaparan dan kuasai 5 kota dalam 8 tahun.'], yrs: 8, o: { type: 'continent', size: 's', bots: 2, diff: 'normal', nation: 1 },
      obj: [[['Winters survived', 'Musim dingin terlewati'], (S, e) => e.st.winters, 3], [['Cities', 'Kota'], S => myCities(S).length, 5]] },
    { n: ['Bonds of Blood', 'Ikatan Darah'], d: ['Forge 2 alliances, at least one sealed by a royal marriage, within 8 years.', 'Jalin 2 aliansi, minimal satu lewat pernikahan kerajaan, dalam 8 tahun.'], yrs: 8, o: { type: 'continents', size: 's', bots: 3, diff: 'normal', nation: 2 },
      obj: [[['Allies', 'Sekutu'], S => alliesN(S), 2], [['Marriages', 'Pernikahan'], (S, e) => e.mr.list.length, 1]] },
    { n: ['Eyes and Ears', 'Mata dan Telinga'], d: ['Run 6 successful spy missions and research 5 technologies within 8 years.', 'Lakukan 6 misi mata-mata sukses dan riset 5 teknologi dalam 8 tahun.'], yrs: 8, o: { type: 'lakes', size: 's', bots: 2, diff: 'normal', nation: 3 },
      obj: [[['Spy missions', 'Misi mata-mata'], (S, e) => e.sp.ok, 6], [['Technologies', 'Teknologi'], S => techS(S).done.length, 5]] },
    { n: ['Conqueror of the Continent', 'Penakluk Benua'], d: ['Seize 2 enemy capitals (3 in total) within 12 years.', 'Rebut 2 ibu kota musuh (total 3) dalam 12 tahun.'], yrs: 12, o: { type: 'continents', size: 's', bots: 3, diff: 'normal', nation: 4 },
      obj: [[['Capitals held', 'Ibu kota dikuasai'], S => capsOwned(S), 3]] }
  ];
  RFX.CH = CH;
  const chOpen = i => i === 0 || RFX.meta.camp.includes(i);
  function campStart(i) {
    const ch = CH[i]; if (!ch || !chOpen(i)) return;
    const o = Object.assign({ win: 'score', target: 99999999, sandbox: false }, ch.o, { camp: i + 1 });
    const S = newGame(o); startGame(S);
    tell(S, L('Chapter ', 'Bab ') + (i + 1) + ': ' + L(ch.n[0], ch.n[1]), L(ch.d[0], ch.d[1]));
  }
  const campProg = (S, e, ch) => ch.obj.map(o => ({ lbl: L(o[0][0], o[0][1]), cur: Math.min(o[2], o[1](S, e)), goal: o[2] }));
  function campCheck(S, e) {
    const ch = CH[S.opts.camp - 1]; if (!ch || S.over) return;
    if (S.opts.camp === 2 && e.st.ws) { S.over = { winner: -1, why: L('Your people starved in winter.', 'Rakyatmu kelaparan di musim dingin.') }; return; }
    if (campProg(S, e, ch).every(x => x.cur >= x.goal)) { S.over = { winner: VP, why: L('Chapter complete: ', 'Bab selesai: ') + L(ch.n[0], ch.n[1]) }; return; }
    if (S.time >= ch.yrs * RY) S.over = { winner: -1, why: L('Time ran out for this chapter.', 'Waktu bab ini habis.') };
  }
  /* ----- tantangan harian ----- */
  const DAILY_YEARS = 8;
  const dayKey = () => { const d = new Date(); return d.getUTCFullYear() * 10000 + (d.getUTCMonth() + 1) * 100 + d.getUTCDate(); };
  const prevKey = k => { const y = Math.floor(k / 10000), m = Math.floor(k / 100) % 100, d = k % 100, t = new Date(Date.UTC(y, m - 1, d - 1)); return t.getUTCFullYear() * 10000 + (t.getUTCMonth() + 1) * 100 + t.getUTCDate(); };
  function dailyOpts(key) {
    const r = mulberry32((key * 2654435761) >>> 0), types = ['continent', 'continents', 'islands', 'lakes'];
    return { type: types[Math.floor(r() * 4)], size: 's', bots: 3, diff: 'normal', win: 'score', target: 99999999, nation: Math.floor(r() * 8), seed: key, sandbox: false, daily: key };
  }
  function dailyStart() { const S = newGame(dailyOpts(dayKey())); startGame(S); tell(S, L('Daily challenge', 'Tantangan harian'), L('Highest score in 8 years. Same map for everyone today!', 'Skor tertinggi dalam 8 tahun. Peta sama untuk semua pemain hari ini!')); }
  function dailyCheck(S, e) {
    if (S.over || S.time < DAILY_YEARS * RY) return;
    calcScore(S); const best = S.players.slice().sort((a, b) => b.score - a.score)[0];
    S.over = { winner: best.id, why: L('Daily challenge complete (8 years).', 'Tantangan harian selesai (8 tahun).') };
  }
  /* dipanggil dari modal akhir permainan (main.js): rekam hasil sekali, kembalikan HTML tambahan */
  function finalize(S) {
    if (!S || S._xf) return ''; S._xf = 1; let html = '';
    try {
      const e = EX(S), p = S.players[VP], won = S.over && S.over.winner === VP, m = RFX.meta; calcScore(S); histRecord(S, e);
      if (won) achUnlock('victory');
      if (S.opts.camp && won && !e.st.cheat && !m.camp.includes(S.opts.camp)) { m.camp.push(S.opts.camp); metaSave(); html += `<div class="gd" style="margin-top:6px">${L('Chapter unlocked!', 'Bab berikutnya terbuka!')}</div>`; }
      if (S.opts.daily) {
        const key = S.opts.daily;
        if (e.st.cheat) html += `<div class="bad" style="margin-top:6px">${L('Mods were active: score not recorded.', 'Mods aktif: skor tidak dicatat.')}</div>`;
        else {
          const sc = p.score | 0; m.daily[key] = Math.max(m.daily[key] || 0, sc);
          m.board.push({ k: key, s: sc, n: p.name }); m.board.sort((a, b) => b.s - a.s); m.board = m.board.slice(0, 10);
          if (m.last !== key) { m.streak = m.last === prevKey(key) ? m.streak + 1 : 1; m.last = key; }
          RFX.share = 'RealmForge Daily ' + key + ' · ' + p.name + ' · ' + sc + ' pts · streak ' + m.streak + '\n' + mkCode(key, sc, p.ci);
          html += `<div class="gl" style="margin-top:6px">${L('Daily score: ', 'Skor harian: ')}<b>${sc}</b> · ${L('streak', 'beruntun')} ${m.streak}</div>`;
          achCheck(S, e);
        }
      }
      metaSave();
    } catch (er) { console.error(er); }
    return html;
  }
  RFX.overHtml = S => finalize(S);
  RFX.overBtn = () => btn('xstat', L('Stats & Replay', 'Statistik & Replay')) + (RFX.share ? btn('xcopy', L('Copy result', 'Salin hasil')) : '');

  /* ================= 8. STATISTIK & REPLAY ================= */
  function terrSnap(S) {
    const W = S.W, H = S.H, bw = Math.ceil(W / 4), bh = Math.ceil(H / 4), u = new Uint8Array(bw * bh);
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      const x = Math.min(W - 1, bx * 4 + 2), y = Math.min(H - 1, by * 4 + 2), i = y * W + x;
      u[by * bw + bx] = isWater(S.ter[i]) ? 254 : (S.terr[i] >= 0 ? S.terr[i] + 1 : 0);
    }
    return { y: yearN(S), w: bw, h: bh, d: b64(u) };
  }
  function histRecord(S, e) {
    const row = S.players.map(p => [p.score | 0, S.cities.filter(c => c.owner === p.id).length, armyUnits(S, p.id), Math.floor(p.stock.gold)]);
    e.h.y.push({ y: yearN(S) - 1, r: row }); if (e.h.y.length > 150) e.h.y.shift();
    e.h.snaps.push(terrSnap(S)); if (e.h.snaps.length > 48) e.h.snaps = e.h.snaps.filter((q, i) => i % 2 === 0 || i === e.h.snaps.length - 1);
  }
  const METRICS = { score: [0, ['Score', 'Skor']], cities: [1, ['Cities', 'Kota']], army: [2, ['Army', 'Pasukan']], gold: [3, ['Gold', 'Emas']] };
  function drawChart(S, e, mk) {
    const cv = document.getElementById('xchart'); if (!cv) return; const c = cv.getContext('2d'), W = cv.width, H = cv.height, ix = METRICS[mk][0], ys = e.h.y;
    c.clearRect(0, 0, W, H); c.fillStyle = '#10131c'; c.fillRect(0, 0, W, H); if (ys.length < 2) { c.fillStyle = '#9aa3c2'; c.font = '12px sans-serif'; c.fillText(L('Play a few years to see the chart.', 'Mainkan beberapa tahun untuk melihat grafik.'), 12, H / 2); return; }
    let mx = 1; for (const q of ys) for (const r of q.r) mx = Math.max(mx, r[ix]);
    c.strokeStyle = 'rgba(255,255,255,.12)'; c.lineWidth = 1; for (let g = 1; g < 4; g++) { c.beginPath(); c.moveTo(0, H * g / 4); c.lineTo(W, H * g / 4); c.stroke(); }
    S.players.forEach((p, pi) => {
      c.strokeStyle = p.col; c.lineWidth = pi === VP ? 3 : 1.5; c.beginPath();
      ys.forEach((q, k) => { const x = 8 + (W - 16) * k / (ys.length - 1), y = H - 8 - (H - 16) * ((q.r[pi] ? q.r[pi][ix] : 0) / mx); if (k) c.lineTo(x, y); else c.moveTo(x, y); });
      c.stroke();
    });
    c.fillStyle = '#9aa3c2'; c.font = '11px sans-serif'; c.fillText('max ' + mx, 6, 12);
  }
  function drawReplay(S, e, i) {
    const cv = document.getElementById('xrep'), sn = e.h.snaps[i]; if (!cv || !sn) return;
    const c = cv.getContext('2d'), u = unb64(sn.d), cs = Math.floor(cv.width / sn.w) || 1;
    c.fillStyle = '#10131c'; c.fillRect(0, 0, cv.width, cv.height);
    for (let y = 0; y < sn.h; y++) for (let x = 0; x < sn.w; x++) {
      const v = u[y * sn.w + x]; c.fillStyle = v === 254 ? '#1b3556' : v === 0 ? '#3b4a35' : (S.players[v - 1] ? S.players[v - 1].col : '#888'); c.fillRect(x * cs, y * cs, cs, cs);
    }
    const lb = document.getElementById('xrepl'); if (lb) lb.textContent = L('Year ', 'Tahun ') + sn.y + '  (' + (i + 1) + '/' + e.h.snaps.length + ')';
  }
  function replayPlay(S, e) {
    if (RFX.rep) clearInterval(RFX.rep.t); const st = RFX.rep = { i: 0 };
    drawReplay(S, e, 0);
    st.t = setInterval(() => { if (!document.getElementById('xrep')) { clearInterval(st.t); return; } st.i = (st.i + 1) % Math.max(1, e.h.snaps.length); drawReplay(S, e, st.i); }, 500);
  }

  /* ================= 9. SLOT SIMPAN ================= */
  const slotMeta = n => { try { return JSON.parse(localStorage.getItem('kc_slotm' + n)); } catch (er) { return null; } };
  function slotSave(n) {
    const S = UI.S; if (!S || S.tut || S.over) return say(L('Cannot save now', 'Tidak bisa menyimpan sekarang'), false);
    if (!saveGame(S)) return say(L('Save failed (storage full?)', 'Gagal menyimpan (penyimpanan penuh?)'), false);
    try {
      localStorage.setItem('kc_slot' + n, localStorage.getItem('kc_save'));
      localStorage.setItem('kc_slotm' + n, JSON.stringify({ t: Date.now(), y: yearN(S), sc: S.players[VP].score | 0, nm: S.players[VP].name, c: myCities(S).length }));
      say(L('Saved to slot ', 'Tersimpan di slot ') + n, true);
    } catch (er) { say(L('Slot full: free some space', 'Slot penuh: kosongkan ruang'), false); }
  }
  function slotLoad(n) {
    const raw = localStorage.getItem('kc_slot' + n); if (!raw) return;
    try { localStorage.setItem('kc_save', raw); } catch (er) { return; }
    const S = loadGame(); if (S) { $('modal').classList.add('hidden'); startGame(S); } else if (UI.S) say(L('Slot is corrupted', 'Slot rusak'), false);
  }

  /* ================= 10. PANEL UI ================= */
  const hd = t => `<div class="mh">${t}</div>`, hint = t => `<div class="mhint">${t}</div>`, card = h => `<div class="xcard">${h}</div>`;
  const bar = (v, mx) => `<div class="xbar"><i style="width:${cx(v / Math.max(1, mx) * 100, 0, 100).toFixed(0)}%"></i></div>`;
  const nm = p => `<b style="color:${p.col}">${esc(p.name)}</b>`;
  const mrow = (act, t, sub) => `<button class="mrow" data-act="${act}"><span class="mt"><b>${t}</b><i>${sub}</i></span><span class="xarr">›</span></button>`;
  const foot = (back) => (back ? btn('xhub', '‹ EXTRA') : '') + (UI.S && UI.S.over ? btn('tomenu', L('Main menu', 'Menu utama')) : '') + btn('closemodal', L('Close', 'Tutup'), 'gold');
  function show(title, body, back, fn) {
    RFX.cur = fn || null; const bd0 = document.querySelector('#modal .bd'), keep = bd0 && !$('modal').classList.contains('hidden') ? bd0.scrollTop : 0;
    showModal(title, `<div class="xp">${body}</div>`, foot(back)); const bd = document.querySelector('#modal .bd'); if (bd) bd.scrollTop = keep;
  }
  const re = () => { if (RFX.cur) RFX.cur(); };
  const relTxt = (S, id) => { const r = rel(S, VP, id); return r.st === 'war' ? L('War', 'Perang') : r.ally ? L('Allied', 'Sekutu') : r.st === 'truce' ? L('Truce', 'Gencatan') : L('Peace', 'Damai'); };
  const cfgRow = (k, t, d) => `<button class="mrow ${RFX.cfg[k] ? 'on' : ''}" data-act="xcfg:${k}"><span class="mt"><b>${t}</b><i>${d}</i></span><span class="sw2"></span></button>`;

  function pHub() {
    const S = UI.S, live = S && on(S); let b = '';
    if (live) {
      const e = EX(S), s = SEAS[seasonIdx(S)], wk = wxNow(S, e), p = S.players[VP];
      b += `<div class="mnote">${s.e} ${L(s.n[0], s.n[1])} · ${wk ? WX[wk].e + ' ' + L(WX[wk].n[0], WX[wk].n[1]) : L('Clear skies', 'Cerah')} · ${L('Year', 'Tahun')} ${yearN(S)}</div>`;
      b += mrow('xseas', L('Seasons & weather', 'Musim & cuaca'), L(s.d[0], s.d[1]));
      b += mrow('xspy', L('Espionage', 'Mata-mata'), L('Agent level ', 'Level agen ') + e.sp.lv + ' · ' + e.sp.ok + L(' successes', ' sukses'));
      b += mrow('xmarry', L('Royal marriages', 'Pernikahan kerajaan'), e.mr.list.filter(l => !l.end).length + L(' active', ' aktif') + (e.mr.inc.length ? ' · ' + e.mr.inc.length + L(' proposals!', ' lamaran!') : ''));
      b += mrow('xfaith', L('Faith', 'Agama'), e.rl.faith ? faithName(e.rl.faith) + ' · ' + L('piety ', 'kesalehan ') + Math.floor(e.rl.piety) : L('No faith chosen', 'Belum memilih agama'));
      b += mrow('xrt', L('Trade routes', 'Rute dagang'), e.rt.list.length + '/' + rtMax(S) + ' · +' + (e.rt.today || 0) + L('/day', '/hari'));
      b += mrow('xq', L('Quests & achievements', 'Misi & prestasi'), e.q.act.length + L(' active', ' aktif') + ' · ' + Object.keys(RFX.meta.ach).length + '/' + ACH.length + ' ★');
      b += mrow('xbld', L('Buildings', 'Bangunan'), L('Temples & Intel HQ', 'Kuil & Markas Intel'));
      b += mrow('xstat', L('Stats & replay', 'Statistik & replay'), L('Charts and territory time-lapse', 'Grafik dan time-lapse wilayah'));
      b += mrow('xslots', L('Save slots', 'Slot simpan'), L('3 manual save slots', '3 slot simpan manual'));
    } else if (S && !S.tut) b += `<div class="mnote">${L('Extra systems only run in offline games.', 'Sistem tambahan hanya berjalan di permainan offline.')}</div>`;
    if (!S) b += mrow('xcamp', L('Campaign', 'Kampanye'), RFX.meta.camp.length + '/' + CH.length + L(' chapters cleared', ' bab selesai'));
    b += mrow('xdaily', L('Daily challenge', 'Tantangan harian'), L('Streak ', 'Beruntun ') + RFX.meta.streak);
    if (!live) { b += mrow('xach', L('Achievements', 'Prestasi'), Object.keys(RFX.meta.ach).length + '/' + ACH.length); b += mrow('xslots', L('Save slots', 'Slot simpan'), L('Load a manual save', 'Muat simpanan manual')); }
    b += mrow('xguide', L('Guide', 'Panduan'), L('How the new systems work', 'Cara kerja sistem baru'));
    b += mrow('xcfg', L('Settings', 'Pengaturan'), L('Toggle seasons, effects, enemy spies', 'Atur musim, efek, mata-mata musuh'));
    show('EXTRA', b, false, pHub);
  }
  function pSeason() {
    const S = UI.S; if (!S) return; const e = EX(S), si = seasonIdx(S), wk = wxNow(S, e), w = techSum(S, 'wint');
    let b = card(`<b>${SEAS[si].e} ${L(SEAS[si].n[0], SEAS[si].n[1])}</b>${hint(L(SEAS[si].d[0], SEAS[si].d[1]))}${wk ? hint(WX[wk].e + ' ' + L(WX[wk].n[0], WX[wk].n[1]) + ': ' + L(WX[wk].d[0], WX[wk].d[1])) : ''}`);
    b += hd(L('Year cycle', 'Siklus tahun'));
    b += SEAS.map((s, i) => `<div class="xrow ${i === si ? 'xon' : ''}"><span>${s.e} ${L(s.n[0], s.n[1])}</span><span>${L('Food', 'Pangan')} ×${[1.05, 1.15, 1.3, cx(1 - 0.45 * sevK() + w - harsh(S), 0.25, 1)][i].toFixed(2)}</span></div>`).join('');
    b += hint(L('Winter tech (Nature tab) softens the cold. Weather lasts about a day.', 'Teknologi musim dingin (tab Nature) meredam dingin. Cuaca berlangsung sekitar sehari.'));
    show(L('Seasons & weather', 'Musim & cuaca'), b, true, pSeason);
  }
  function pSpy() {
    const S = UI.S; if (!S) return; const e = EX(S), sp = e.sp, p = S.players[VP];
    let b = `<div class="mnote">${L('Agent level', 'Level agen')} ${sp.lv} · XP ${sp.xp} · ${sp.ok} ✓ / ${sp.fail} ✗ · ${L('agents', 'agen')} ${sp.ops.length}/${spyCap(e)}${hasIntelChief(S) ? ' · ' + L('Intel chief +8%', 'Kepala Intelijen +8%') : ''}</div>`;
    b += `<div class="xbtns">${btn('xspyctr', L('Counter-intel', 'Kontra-intel') + ' 50 ' + IMG('gold', 14), sp.ctr > S.time ? 'dis' : '')}</div>` + hint(sp.ctr > S.time ? L('Counter-intelligence active.', 'Kontra-intelijen aktif.') : L('Counter-intel raises the chance to catch enemy spies for a year.', 'Kontra-intel menaikkan peluang menangkap mata-mata musuh setahun.'));
    if (sp.ops.length) b += hd(L('Missions underway', 'Misi berjalan')) + sp.ops.map(o => `<div class="xrow"><span>${L(SPY[o.k].n[0], SPY[o.k].n[1])} → ${nm(S.players[o.tid])}</span><span>${Math.max(0, Math.ceil(o.at - S.time))}s</span></div>`).join('');
    for (const f of foes(S)) {
      const it = sp.intel[f.id];
      let h = `<div class="xrow"><span>${nm(f)}</span><span>${relTxt(S, f.id)} · ${rel(S, VP, f.id).op | 0}</span></div>`;
      if (it) h += hint(`${L('Intel day ', 'Intel hari ')}${Math.floor(it.t / DAY) + 1}: ${L('gold', 'emas')} ${it.gold} · ${L('food', 'pangan')} ${it.food} · ${L('cities', 'kota')} ${it.cities} · ${L('troops', 'pasukan')} ${it.units} · ${L('ruler', 'penguasa')} ${esc(it.ruler)} · ${FA[it.faith].e}`);
      h += `<div class="xbtns">` + Object.keys(SPY).map(k => btn('xspygo:' + f.id + '~' + k, L(SPY[k].n[0], SPY[k].n[1]) + ' ' + Math.round(spyChance(S, e, k, f.id) * 100) + '% · ' + spyCost(e, k) + ' ' + IMG('gold', 12), p.stock.gold < spyCost(e, k) || (sp.cd[f.id + k] || 0) > S.time ? 'dis' : '')).join('') + `</div>`;
      b += card(h);
    }
    if (!foes(S).length) b += hint(L('No other kingdoms to spy on.', 'Tidak ada kerajaan lain untuk dimata-matai.'));
    show(L('Espionage', 'Mata-mata'), b, true, pSpy);
  }
  function pMarry() {
    const S = UI.S; if (!S) return; const e = EX(S), m = e.mr, kids = mrKids(S), ui = m.ui, p = S.players[VP];
    let b = '';
    if (m.inc.length) { b += hd(L('Incoming proposals', 'Lamaran masuk')); b += m.inc.map((q, i) => { const k = R(S).people[q.ck], t = S.players[q.pid]; return card(`${nm(t)} → ${k ? esc(cname(k)) : '?'}<div class="xbtns">${btn('xmans:' + i + '~1', L('Accept', 'Terima'), 'gold')}${btn('xmans:' + i + '~0', L('Decline', 'Tolak'))}</div>`); }).join(''); }
    for (const k of Object.keys(m.claims)) { const c = m.claims[k]; b += card(`<b>${L('Throne claim: ', 'Klaim takhta: ')}</b>${nm(S.players[k])}<div class="mhint">${L('Expires in ', 'Berakhir dalam ')}${Math.max(0, Math.ceil((c.until - S.time) / DAY))}${L(' days', ' hari')}</div><div class="xbtns">${btn('xmclaim:' + k, L('Claim throne (war)', 'Tuntut takhta (perang)') + ' 120 ' + IMG('gold', 12))}</div>`); }
    b += hd(L('Arrange a marriage', 'Atur pernikahan'));
    if (!kids.length) b += hint(L('No unmarried royal child aged 16+. Grow your dynasty first.', 'Belum ada anak raja usia 16+ yang belum menikah. Besarkan dinasti dulu.'));
    else {
      if (!kids.some(k => k.ck === ui.kid)) ui.kid = null;
      b += `<div class="mseg" style="flex-wrap:wrap">${kids.map(k => `<button class="${k.ck === ui.kid ? 'on' : ''}" data-act="xmk:${k.ck}">${esc(cname(k))} (${k.umur})</button>`).join('')}</div>`;
      b += `<div class="mseg">${MR_TIERS.map((c, i) => `<button class="${i === (ui.tier | 0) ? 'on' : ''}" data-act="xmt:${i}">${i ? L('Dowry ', 'Mas kawin ') + c : L('No dowry', 'Tanpa mas kawin')}</button>`).join('')}</div>`;
      if (ui.kid) b += foes(S).map(f => { const ch = mrChance(S, f.id, ui.tier | 0); return `<div class="xrow"><span>${nm(f)} · ${relTxt(S, f.id)}</span><span>${Math.round(ch * 100)}% ${btn('xmp:' + f.id, L('Propose', 'Lamar'), ch ? (p.stock.gold < MR_TIERS[ui.tier | 0] || (m.cd[f.id] || 0) > S.time ? 'dis' : 'gold') : 'dis')}</span></div>`; }).join('');
      else b += hint(L('Pick a child to see candidate kingdoms.', 'Pilih anak untuk melihat kerajaan calon besan.'));
    }
    b += hd(L('Marriages', 'Pernikahan')); b += m.list.length ? m.list.map(l => `<div class="xrow"><span>${esc(l.name)} ⚭ ${nm(S.players[l.pid])}</span><span>${l.end ? L('ended', 'berakhir') : L('active', 'aktif')}</span></div>`).join('') : hint(L('None yet.', 'Belum ada.'));
    b += hint(L('An allied marriage seals an alliance, sends yearly gifts, and may open a throne claim when their ruler changes.', 'Pernikahan membentuk aliansi, mengirim hadiah tahunan, dan bisa membuka klaim takhta saat penguasa mereka berganti.'));
    show(L('Royal marriages', 'Pernikahan kerajaan'), b, true, pMarry);
  }
  function pFaith() {
    const S = UI.S; if (!S) return; const e = EX(S), rl = e.rl; let b = '';
    if (!rl.faith) {
      b += hint(L('Choose the faith of your realm. Reforming later costs gold and stirs unrest.', 'Pilih keyakinan kerajaanmu. Mengganti nanti butuh emas dan memicu kerusuhan.'));
      b += FAITH.map(f => card(`<b>${FA[f].e} ${faithName(f)}</b>${hint(L(FA[f].d[0], FA[f].d[1]) + '4–16%')}<div class="xbtns">${btn('xfset:' + f, L('Adopt', 'Peluk'), 'gold')}</div>`)).join('');
    } else {
      b += card(`<b>${FA[rl.faith].e} ${faithName(rl.faith)}</b>${hint(L(FA[rl.faith].d[0], FA[rl.faith].d[1]) + Math.round(faithMag(e) * 100) + '%')}${bar(rl.piety, 100)}${hint(L('Piety ', 'Kesalehan ') + Math.floor(rl.piety) + '/100 · ' + L('reduces unrest each day', 'menurunkan kerusuhan tiap hari'))}<div class="xbtns">${btn('xfgive', L('Offering', 'Persembahan') + ' 60 ' + IMG('gold', 12))}</div>`);
      const fc = foreignCities(S, e);
      b += hd(L('Cities of other faiths', 'Kota berkeyakinan lain')) + (fc.length ? fc.map(c => `<div class="xrow"><span>${esc(c.name)} ${FA[c.fx].e}</span><span>${btn('xfmis:' + c.id, L('Missionary', 'Misionaris') + ' 50', 'gold')}</span></div>`).join('') : hint(L('All your cities share your faith.', 'Semua kotamu seiman.')));
      b += hd(L('Reform', 'Reformasi')) + `<div class="mseg">${FAITH.filter(f => f !== rl.faith).map(f => `<button data-act="xfset:${f}">${FA[f].e} ${faithName(f)} · 100</button>`).join('')}</div>`;
    }
    b += hint(L('Neighbours of your faith warm to you each year; others cool.', 'Tetangga seiman makin akrab tiap tahun; yang beda keyakinan menjauh.'));
    show(L('Faith', 'Agama'), b, true, pFaith);
  }
  function pRoutes() {
    const S = UI.S; if (!S) return; const e = EX(S), ui = e.rt.ui, p = S.players[VP]; let b = '';
    b += `<div class="mnote">${e.rt.list.length}/${rtMax(S)} ${L('routes · earned ', 'rute · total ')}${Math.floor(e.rt.earn)} ${IMG('gold', 12)} · ${L('Markets raise the limit.', 'Pasar menaikkan batas.')}</div>`;
    for (const rt of e.rt.list) {
      const a = S.cities.find(c => c.id === rt.a), bb = S.cities.find(c => c.id === rt.b); if (!a || !bb) continue;
      b += card(`<div class="xrow"><span><b>${esc(a.name)} ↔ ${esc(bb.name)}</b></span><span>${rt.st === 'block' ? '⚠ ' + L('blocked', 'diblokade') : '+' + Math.floor(rtInc(S, rt)) + L('/day', '/hari')}</span></div>${hint(L('Level ', 'Level ') + rt.lv + ' · ' + rt.len + L(' tiles', ' petak') + (rt.fo ? ' · ' + L('foreign partner', 'mitra asing') : '') + (rt.guard ? ' · ' + L('guarded', 'dikawal') : ''))}<div class="xbtns">${rt.lv < 3 ? btn('xrtup:' + rt.id, L('Upgrade', 'Tingkatkan') + ' ' + 100 * rt.lv, p.stock.gold < 100 * rt.lv ? 'dis' : '') : ''}${btn('xrtg:' + rt.id, rt.guard ? L('Guards off', 'Hentikan pengawal') : L('Guards 4/day', 'Pengawal 4/hari'))}${btn('xrtdel:' + rt.id, L('Close', 'Tutup rute'))}</div>`);
    }
    b += hd(L('New route', 'Rute baru'));
    if (e.rt.list.length >= rtMax(S)) b += hint(L('Limit reached. Build markets to open more routes.', 'Batas tercapai. Bangun pasar untuk membuka rute lagi.'));
    else if (!ui.a) b += hint(L('Choose your starting city:', 'Pilih kota asal:')) + `<div class="mseg" style="flex-wrap:wrap">${myCities(S).map(c => `<button data-act="xrta:${c.id}">${esc(c.name)}</button>`).join('')}</div>`;
    else {
      const a = S.cities.find(c => c.id === ui.a);
      if (!a) ui.a = null; else {
        b += hint(L('From ', 'Dari ') + esc(a.name) + L(' to:', ' ke:'));
        const cand = S.cities.filter(c => c.id !== a.id && c.owner >= 0 && (c.owner === VP || !atWar(S, VP, c.owner)) && S.comp[c.y * S.W + c.x] === S.comp[a.y * S.W + a.x]).sort((x, y) => (Math.abs(x.x - a.x) + Math.abs(x.y - a.y)) - (Math.abs(y.x - a.x) + Math.abs(y.y - a.y))).slice(0, 8);
        b += cand.length ? cand.map(c => `<div class="xrow"><span>${esc(c.name)} <i style="color:${S.players[c.owner].col}">●</i></span><span>≈${rtCost(Math.abs(c.x - a.x) + Math.abs(c.y - a.y))} ${btn('xrtb:' + c.id, L('Open', 'Buka'), 'gold')}</span></div>`).join('') : hint(L('No reachable partner by land.', 'Tak ada mitra yang terjangkau lewat darat.'));
        b += `<div class="xbtns">${btn('xrtcancel', L('Cancel', 'Batal'))}</div>`;
      }
    }
    b += hint(L('Routes pay daily, but enemy armies near the road block them and bandits raid unguarded caravans.', 'Rute membayar tiap hari, tapi pasukan musuh di dekat jalan memblokade dan bandit merampok kafilah tanpa pengawal.'));
    show(L('Trade routes', 'Rute dagang'), b, true, pRoutes);
  }
  function achList() { const m = RFX.meta; return hd(L('Achievements', 'Prestasi') + ' ' + Object.keys(m.ach).length + '/' + ACH.length) + ACH.map(a => `<div class="xrow ${m.ach[a[0]] ? 'xon' : 'xlock'}"><span>${m.ach[a[0]] ? '★' : '☆'} <b>${L(a[1][0], a[1][1])}</b></span><span class="mhint">${L(a[2][0], a[2][1])}</span></div>`).join(''); }
  function pQuests() {
    const S = UI.S; if (!S) return; const e = EX(S); let b = '';
    const ch = S.opts.camp && CH[S.opts.camp - 1];
    if (ch) b += hd(L('Campaign goal', 'Tujuan kampanye')) + card(`<b>${L(ch.n[0], ch.n[1])}</b>${hint(L('Time left: ', 'Sisa waktu: ') + Math.max(0, ((ch.yrs * RY - S.time) / RY)).toFixed(1) + L(' years', ' tahun'))}` + campProg(S, e, ch).map(x => `<div class="xrow"><span>${x.lbl}</span><span>${x.cur}/${x.goal}</span></div>${bar(x.cur, x.goal)}`).join(''));
    if (S.opts.daily) b += card(`<b>${L('Daily challenge', 'Tantangan harian')}</b>${hint(L('Time left: ', 'Sisa waktu: ') + Math.max(0, ((DAILY_YEARS * RY - S.time) / RY)).toFixed(1) + L(' years · score ', ' tahun · skor ') + (S.players[VP].score | 0))}`);
    b += hd(L('Quests', 'Misi') + ' · ' + e.q.done + L(' done', ' selesai'));
    b += e.q.act.map(q => { const d = QDEF.find(x => x.id === q.k), cur = Math.min(q.goal, d.get(S, e)); return card(`<div class="xrow"><span>${qText(d, q.goal)}</span><span>+${q.rw} ${IMG('gold', 12)}</span></div>${bar(cur, q.goal)}<div class="mhint">${cur}/${q.goal}</div>`); }).join('');
    b += achList(); show(L('Quests & achievements', 'Misi & prestasi'), b, true, pQuests);
  }
  function pAch() { show(L('Achievements', 'Prestasi'), achList(), true, pAch); }
  function pStat() {
    const S = UI.S; if (!S) return; const e = EX(S), mk = RFX.metric || 'score';
    if (!e.h.y.length) histRecord(S, e);
    let b = `<div class="mseg">${Object.keys(METRICS).map(k => `<button class="${k === mk ? 'on' : ''}" data-act="xstm:${k}">${L(METRICS[k][1][0], METRICS[k][1][1])}</button>`).join('')}</div>`;
    b += `<canvas id="xchart" width="300" height="160" class="xcv"></canvas><div class="xleg">${S.players.map(p => `<span><i style="background:${p.col}"></i>${esc(p.name)}</span>`).join('')}</div>`;
    b += hd(L('Territory time-lapse', 'Time-lapse wilayah')) + `<canvas id="xrep" width="300" height="300" class="xcv"></canvas><div class="mhint" id="xrepl"></div><div class="xbtns">${btn('xrepplay', L('Replay', 'Putar ulang'))}</div>`;
    show(L('Stats & replay', 'Statistik & replay'), b, !S.over, null); RFX.cur = null;
    drawChart(S, e, mk); replayPlay(S, e);
  }
  function pSlots() {
    const S = UI.S, live = S && !S.tut && !S.over; let b = hint(L('Manual saves are kept separately from the autosave.', 'Simpanan manual terpisah dari autosave.'));
    for (let n = 1; n <= 3; n++) {
      const m = slotMeta(n);
      b += card(`<b>${L('Slot ', 'Slot ')}${n}</b>${m ? hint(esc(m.nm) + ' · ' + L('year ', 'tahun ') + m.y + ' · ' + m.c + L(' cities', ' kota') + ' · ' + m.sc + ' ★ · ' + new Date(m.t).toLocaleString()) : hint(L('Empty', 'Kosong'))}<div class="xbtns">${live ? btn('xsave:' + n, L('Save', 'Simpan'), 'gold') : ''}${m ? btn('xload:' + n, L('Load', 'Muat')) + btn('xdel:' + n, L('Delete', 'Hapus')) : ''}</div>`);
    }
    b += hd(L('Backup file', 'File cadangan')) + hint(L('Export your current game to a file, or import one to continue on another device.', 'Ekspor game saat ini ke file, atau impor file untuk melanjutkan di perangkat lain.')) + `<div class="xbtns">${live ? btn('xexport', L('Export', 'Ekspor')) : ''}${btn('ximport', L('Import', 'Impor'))}</div>`;
    show(L('Save slots', 'Slot simpan'), b, true, pSlots);
  }
  function pDaily() {
    const key = dayKey(), o = dailyOpts(key), m = RFX.meta, S = UI.S; let b = card(`<b>${L('Today', 'Hari ini')}: ${key}</b>${hint(L('Map: ', 'Peta: ') + o.type + ' · ' + L('nation #', 'bangsa #') + (o.nation + 1) + ' · 3 bots · 8 ' + L('years', 'tahun'))}${hint(L('Best today: ', 'Terbaik hari ini: ') + (m.daily[key] || '-') + ' · ' + L('streak ', 'beruntun ') + m.streak)}${S ? '' : `<div class="xbtns">${btn('xdgo', L('Start', 'Mulai'), 'gold')}</div>`}`);
    b += hint(L('Everyone gets the same map today. Mods and cheats void your score. The board is stored on this device; use Copy result to share your score.', 'Semua pemain mendapat peta yang sama hari ini. Mods dan cheat membatalkan skor. Papan peringkat tersimpan di perangkat ini; gunakan Salin hasil untuk membagikan skormu.'));
    const frs = m.fr.filter(x => x.k === key); b += hd(L('Friends today', 'Teman hari ini')) + (frs.length ? frs.map((x, i) => `<div class="xrow"><span>${i + 1}. ${esc(PNAMES[x.ci] || '?')}</span><span>${x.s}</span></div>`).join('') : hint(L('No friend codes yet.', 'Belum ada kode teman.'))) + `<div class="xbtns">${btn('xfadd', L('Add friend code', 'Tambah kode teman'))}</div>`;
    b += hd(L('Top scores', 'Skor tertinggi')) + (m.board.length ? m.board.map((x, i) => `<div class="xrow"><span>${i + 1}. ${esc(x.n)}</span><span>${x.s} <i class="mhint">${x.k}</i></span></div>`).join('') : hint(L('No scores yet.', 'Belum ada skor.')));
    show(L('Daily challenge', 'Tantangan harian'), b, true, pDaily);
  }
  function pCamp() {
    let b = hint(L('Complete each chapter to unlock the next. Seasons, spies, marriages and more all matter.', 'Selesaikan tiap bab untuk membuka bab berikutnya. Musim, mata-mata, pernikahan, dan lainnya berperan.'));
    b += CH.map((ch, i) => { const open = chOpen(i), done = RFX.meta.camp.includes(i + 1); return card(`<b>${open ? (done ? '✓ ' : '') : '🔒 '}${L('Chapter ', 'Bab ')}${i + 1}: ${L(ch.n[0], ch.n[1])}</b>${hint(L(ch.d[0], ch.d[1]))}${open ? `<div class="xbtns">${btn('xcgo:' + i, done ? L('Replay', 'Main lagi') : L('Start', 'Mulai'), 'gold')}</div>` : ''}`); }).join('');
    show(L('Campaign', 'Kampanye'), b, true, pCamp);
  }
  function pCfg() {
    let b = cfgRow('season', L('Seasons & weather', 'Musim & cuaca'), L('Affects harvests and army speed', 'Memengaruhi panen dan kecepatan pasukan')) + cfgRow('fx', L('Weather visuals', 'Visual cuaca'), L('Snow, rain, falling leaves', 'Salju, hujan, daun gugur')) + cfgRow('aiSpy', L('Enemy spies', 'Mata-mata musuh'), L('Hostile kingdoms may spy on you', 'Kerajaan musuh bisa memata-matai kamu'));
    const seg = (act, vals, cur, f) => `<div class="mseg">${vals.map(v => `<button class="${cur === v ? 'on' : ''}" data-act="${act}:${v}">${f(v)}</button>`).join('')}</div>`;
    b += hd(L('Winter severity', 'Keparahan musim dingin')) + seg('xsev', ['easy', 'normal', 'hard'], RFX.cfg.sev, v => ({ easy: L('Mild', 'Ringan'), normal: 'Normal', hard: L('Harsh', 'Keras') })[v]);
    b += hd(L('Notifications', 'Notifikasi')) + seg('xnotif', ['all', 'key', 'off'], RFX.cfg.notif, v => ({ all: L('All', 'Semua'), key: L('Key only', 'Penting saja'), off: L('Off', 'Mati') })[v]);
    show(L('Settings', 'Pengaturan'), b, true, pCfg);
  }

  /* ================= BANGUNAN: KUIL & MARKAS INTEL ================= */
  const BLD = {
    temple: { c: { gold: 150, wood: 60 }, max: 3, n: ['Temple', 'Kuil'], d: ['+0.5 piety/day and calmer cities (needs a faith)', '+0.5 kesalehan/hari dan kota lebih tenang (butuh agama)'] },
    hq: { c: { gold: 200, iron: 50 }, max: 1, n: ['Intel HQ', 'Markas Intel'], d: ['+6% spy success, +1 agent, missions 20% cheaper', '+6% sukses mata-mata, +1 agen, misi 20% lebih murah'] }
  };
  const blN = (S, e, k) => e.bl.filter(b => b.k === k && (S.cities.find(c => c.id === b.cid) || {}).owner === VP).length;
  function blPlace(S, cap) {
    const W = S.W, H = S.H, x0 = cap.x + 1, y0 = cap.y + 1;
    for (let r = 3; r <= 9; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
      const x = x0 + dx, y = y0 + dy; if (x < 1 || y < 1 || x >= W - 1 || y >= H - 1) continue;
      const i = y * W + x, t = S.ter[i]; if (isWater(t) || t === TR.MOUNT || S.occ[i] !== -1 || S.terr[i] !== VP) continue;
      if (EX(S).bl.some(b => b.x === x && b.y === y)) continue;
      return [x, y];
    }
    return null;
  }
  function blBuy(S, k) {
    const e = EX(S), p = S.players[VP], d = BLD[k], cap = S.cities.find(c => c.isCap && c.owner === VP); if (!d || !cap) return;
    if (blN(S, e, k) >= d.max) return say(L('Limit reached', 'Batas tercapai'), false);
    for (const r in d.c) if ((p.stock[r] || 0) < d.c[r]) return say(L('Not enough ', 'Kurang ') + r + ': ' + d.c[r], false);
    const pos = blPlace(S, cap); if (!pos) return say(L('No free land near the capital', 'Tak ada lahan kosong dekat ibu kota'), false);
    for (const r in d.c) p.stock[r] -= d.c[r];
    e.bl.push({ k, cid: cap.id, x: pos[0], y: pos[1] }); say(L(d.n[0], d.n[1]) + L(' built', ' dibangun'), true);
  }
  function blCheck(S, e) {
    e.bl = e.bl.filter(b => { const c = S.cities.find(q => q.id === b.cid); return c && c.owner === VP; });
    for (const b of e.bl) if (S.occ[b.y * S.W + b.x] !== -1) { const cap = S.cities.find(q => q.id === b.cid), pos = cap && blPlace(S, cap); if (pos) { b.x = pos[0]; b.y = pos[1]; } }
  }
  function blDraw(c, S, vx0, vx1, vy0, vy1) {
    const e = EX(S); if (!e.bl.length) return; const f = Math.max(0, FAITH.indexOf(e.rl.faith || 'sun')), roof = ['#e8b53a', '#3f9d5a', '#8a8f9c'][f];
    for (const b of e.bl) {
      if (b.x < vx0 - 2 || b.x > vx1 + 2 || b.y < vy0 - 2 || b.y > vy1 + 2) continue; const X = b.x * TS, Y = b.y * TS;
      if (b.k === 'temple') {
        c.fillStyle = '#2a2118'; c.fillRect(X + 1, Y + 5, TS - 2, TS - 6); c.fillStyle = '#d9d2c0'; c.fillRect(X + 2, Y + 6, TS - 4, TS - 8);
        c.fillStyle = '#b8b09b'; for (const k of [4, 8, 12]) c.fillRect(X + k, Y + 8, 2, TS - 10);
        c.fillStyle = roof; c.beginPath(); c.moveTo(X, Y + 6); c.lineTo(X + TS / 2, Y); c.lineTo(X + TS, Y + 6); c.closePath(); c.fill();
      } else {
        c.fillStyle = '#1d1d26'; c.fillRect(X + 3, Y + 3, TS - 6, TS - 4); c.fillStyle = '#34344a'; c.fillRect(X + 4, Y + 4, TS - 8, TS - 6);
        c.fillStyle = '#0c0c12'; c.fillRect(X + 6, Y + 8, 4, 5); c.fillStyle = '#ff4a3a'; c.fillRect(X + TS / 2 - 1, Y - 3, 2, 6); c.fillRect(X + TS / 2 + 1, Y - 3, 4, 3);
      }
    }
  }
  function pBld() {
    const S = UI.S; if (!S) return; const e = EX(S);
    let b = hint(L('Built near your capital; they work while you hold it.', 'Dibangun dekat ibu kota; berfungsi selama ibu kota masih milikmu.'));
    for (const k of Object.keys(BLD)) { const d = BLD[k], n = blN(S, e, k); b += card(`<b>${L(d.n[0], d.n[1])} ${n}/${d.max}</b>${hint(L(d.d[0], d.d[1]))}${hint(Object.keys(d.c).map(r => d.c[r] + ' ' + r).join(', '))}<div class="xbtns">${btn('xbbuy:' + k, L('Build', 'Bangun'), n >= d.max ? 'dis' : 'gold')}</div>`); }
    show(L('Buildings', 'Bangunan'), b, true, pBld);
  }

  /* ================= PERISTIWA MUSIMAN ================= */
  const EVD = {
    festival: { t: ['Harvest Festival', 'Festival Panen'], d: ['The villages beg to hold a harvest festival. It costs gold but lifts spirits.', 'Desa-desa memohon festival panen. Biayanya emas, tapi mengangkat semangat rakyat.'],
      o: [{ l: ['Hold it (80 gold)', 'Gelar (80 emas)'], cost: 80, f: (S, e) => { for (const c of myCities(S)) c.unrest = cx((c.unrest === undefined ? 25 : c.unrest) - 10, 0, 100); if (e.rl.faith) e.rl.piety = cx(e.rl.piety + 8, 0, 100); } },
        { l: ['Skip it (+30 gold in taxes)', 'Lewati (+30 emas pajak)'], f: S => { S.players[VP].stock.gold += 30; } }] },
    plague: { t: ['Winter Plague', 'Wabah Musim Dingin'], d: ['Sickness spreads through the cold, crowded towns.', 'Penyakit menyebar di kota-kota yang dingin dan padat.'],
      o: [{ l: ['Quarantine & healers (100 gold)', 'Karantina & tabib (100 emas)'], cost: 100, f: () => { } },
        { l: ['Ignore it', 'Abaikan'], f: S => { S.players[VP].stock.food *= 0.8; const cs = myCities(S); for (let i = 0; i < 2 && cs.length; i++) { const c = cs[Math.floor(S.rnd() * cs.length)]; c.unrest = cx((c.unrest === undefined ? 25 : c.unrest) + 10, 0, 100); } } }] },
    pilgrim: { t: ['Pilgrimage', 'Ziarah'], d: ['Pilgrims ask for safe passage and lodging through your lands.', 'Para peziarah meminta jalan aman dan penginapan di wilayahmu.'],
      o: [{ l: ['Sponsor it (60 gold)', 'Danai (60 emas)'], cost: 60, f: (S, e) => { e.rl.piety = cx(e.rl.piety + 15, 0, 100); S.players[VP].stock.gold += 40; } },
        { l: ['Decline', 'Tolak'], f: () => { } }] }
  };
  function evRoll(S, e, s) {
    if (s === 2 && S.rnd() < 0.6) e.evq.push('festival');
    else if (s === 3 && S.rnd() < 0.35) {
      if (ownCount(S, 'hospital') > 0 || techSum(S, 'heal') >= 0.35) tell(S, L('Plague averted', 'Wabah dicegah'), L('Your healers and hospitals stopped a winter plague.', 'Tabib dan rumah sakitmu menghentikan wabah musim dingin.'), 'pol', true);
      else e.evq.push('plague');
    } else if (s === 0 && e.rl.faith && e.rl.piety >= 30 && S.rnd() < 0.4) e.evq.push('pilgrim');
  }
  function evShow(S, e) {
    if (!e.evq.length || !$('modal').classList.contains('hidden')) return;
    const k = e.evq.shift(), d = EVD[k]; if (!d) return;
    show(L(d.t[0], d.t[1]), `<div class="mnote">${L(d.d[0], d.d[1])}</div>` + d.o.map((o, i) => `<button class="mrow" data-act="xev:${k}~${i}"><span class="mt"><b>${L(o.l[0], o.l[1])}</b></span></button>`).join(''), false, null);
  }
  function evAnswer(S, a) {
    const [k, i] = sp2(a), d = EVD[k], o = d && d.o[+i], e = EX(S), p = S.players[VP]; if (!o) return;
    if (o.cost && p.stock.gold < o.cost) return say(L('Not enough gold: ', 'Emas kurang: ') + o.cost, false);
    if (o.cost) p.stock.gold -= o.cost; o.f(S, e); ACT.closemodal();
  }

  /* ================= AI IKUT BERMAIN ================= */
  function aiYear(S) {
    const ais = foes(S);
    for (let i = 0; i < ais.length; i++) for (let j = i + 1; j < ais.length; j++) {
      const a = ais[i], b = ais[j], r = rel(S, a.id, b.id);
      if (r.st === 'war') { if (S.rnd() < 0.15) { const amt = Math.floor(Math.min(60, b.stock.gold * 0.05)); b.stock.gold -= amt; a.stock.gold += amt; } continue; }
      if (faithOf(a) === faithOf(b)) r.op = Math.min(100, r.op + 2); else if (r.op > -60) r.op -= 1;
      if (!r.ally && r.st === 'peace' && r.op >= 25 && S.rnd() < 0.18) {
        r.ally = true; r.op = Math.min(100, r.op + 15);
        tell(S, L('Royal alliance', 'Aliansi kerajaan'), a.name + L(' and ', ' dan ') + b.name + L(' sealed an alliance with a royal marriage.', ' mengikat aliansi lewat pernikahan kerajaan.'), 'pol', true);
      }
    }
  }

  /* ================= EKSPOR / IMPOR SAVE ================= */
  const info2 = t => { if (UI.S) say(t, true); else showModal('EXTRA', `<div class="xp"><div class="mnote">${esc(t)}</div></div>`, btn('xhub', '‹ EXTRA') + btn('closemodal', L('Close', 'Tutup'), 'gold')); };
  function saveExport() {
    const S = UI.S; if (!S || S.tut || S.over) return info2(L('Nothing to export', 'Tidak ada yang bisa diekspor'));
    if (!saveGame(S)) return info2(L('Save failed', 'Gagal menyimpan'));
    const raw = localStorage.getItem('kc_save'), name = 'realmforge-y' + yearN(S) + '.rfsave';
    try { const f = new File([raw], name, { type: 'text/plain' }); if (navigator.canShare && navigator.canShare({ files: [f] })) { navigator.share({ files: [f], title: name }).catch(() => { }); return; } } catch (er) { }
    try { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([raw], { type: 'text/plain' })); a.download = name; document.body.appendChild(a); a.click(); a.remove(); info2(L('Save file exported', 'File simpanan diekspor')); return; } catch (er) { }
    try { navigator.clipboard.writeText(raw); info2(L('Save copied to clipboard', 'Simpanan disalin ke clipboard')); } catch (er) { info2(L('Export is not supported here', 'Ekspor tidak didukung di sini')); }
  }
  function saveImport() {
    const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.rfsave,.txt,.json,text/plain'; inp.style.display = 'none';
    inp.onchange = () => {
      const f = inp.files && inp.files[0]; if (!f) return; const rd = new FileReader();
      rd.onload = () => { try { const d = JSON.parse(rd.result); if (!d || d.v !== 1 || !d.players) throw new Error('bad'); localStorage.setItem('kc_save', rd.result); const S = loadGame(); if (S) { $('modal').classList.add('hidden'); startGame(S); } } catch (er) { info2(L('Invalid save file', 'File simpanan tidak valid')); } };
      rd.readAsText(f);
    };
    document.body.appendChild(inp); inp.click();
  }

  /* ================= KODE HASIL & SKOR TEMAN ================= */
  const chk = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h.toString(36).slice(0, 6); };
  const mkCode = (key, sc, ci) => { const b = key + '.' + sc + '.' + (ci | 0); return 'RF1.' + b + '.' + chk(b + 'rf!'); };
  function friendAdd() {
    const t = (window.prompt(L('Paste a friend\'s result code', 'Tempel kode hasil teman')) || '').trim(), m = t.match(/RF1\.(\d+)\.(\d+)\.(\d+)\.([0-9a-z]+)/);
    if (!m || chk(m[1] + '.' + m[2] + '.' + m[3] + 'rf!') !== m[4]) return info2(L('Invalid code', 'Kode tidak valid'));
    const x = { k: +m[1], s: +m[2], ci: +m[3] }, fr = RFX.meta.fr;
    if (!fr.some(q => q.k === x.k && q.s === x.s && q.ci === x.ci)) fr.push(x);
    fr.sort((a, b) => b.s - a.s); RFX.meta.fr = fr.slice(0, 40); metaSave(); pDaily();
  }

  /* ================= PANDUAN ================= */
  const GUIDE = [
    [['Seasons & weather', 'Musim & cuaca'], ['Winter cuts harvests and slows armies. Stock food in autumn and research Nature techs.', 'Musim dingin memangkas panen dan memperlambat pasukan. Timbun pangan di musim gugur dan riset teknologi Nature.']],
    [['Espionage', 'Mata-mata'], ['Send agents to scout, steal, sabotage or incite. Success grows with agent level and Intel techs.', 'Kirim agen untuk mengintai, mencuri, sabotase, atau menghasut. Peluang naik seiring level agen dan teknologi Intel.']],
    [['Royal marriages', 'Pernikahan kerajaan'], ['Marry your adult children into other kingdoms for alliances, yearly gifts and throne claims.', 'Nikahkan anak dewasamu ke kerajaan lain untuk aliansi, hadiah tahunan, dan klaim takhta.']],
    [['Faith', 'Agama'], ['Pick a faith, make offerings, convert cities and build temples to raise piety and calm unrest.', 'Pilih agama, beri persembahan, konversi kota, dan bangun kuil untuk menaikkan kesalehan dan menenangkan rakyat.']],
    [['Trade routes', 'Rute dagang'], ['Link two cities by land for daily gold. Guard routes against bandits; markets raise your route limit.', 'Hubungkan dua kota lewat darat untuk emas harian. Kawal rute dari bandit; pasar menaikkan batas rute.']],
    [['Quests, campaign, daily', 'Misi, kampanye, harian'], ['Complete quests for gold, unlock achievements, play the 5-chapter campaign or the daily challenge.', 'Selesaikan misi untuk emas, buka prestasi, mainkan kampanye 5 bab atau tantangan harian.']]
  ];
  function pGuide() {
    let b = `<div class="mnote">${L('Tap the EXTRA button on the right side of the map any time to open these systems.', 'Ketuk tombol EXTRA di sisi kanan peta kapan saja untuk membuka sistem ini.')}</div>`;
    b += GUIDE.map(g => card(`<b>${L(g[0][0], g[0][1])}</b>${hint(L(g[1][0], g[1][1]))}`)).join('');
    show(L('Guide', 'Panduan'), b, !!UI.S, pGuide);
  }

  /* ----- aksi ----- */
  const sp2 = a => a.split('~');
  const guard = f => function (a) { const S = UI.S; if (!S) return; try { f(S, a); } catch (er) { console.error(er); } };
  Object.assign(ACT, {
    xhub: pHub, xmenu: pHub, xseas: pSeason, xspy: pSpy, xmarry: pMarry, xfaith: pFaith, xrt: pRoutes, xq: pQuests, xach: pAch, xslots: pSlots, xdaily: pDaily, xcamp: pCamp, xcfg(k) { if (k && k in RFX.cfg) { RFX.cfg[k] = !RFX.cfg[k]; metaSave(); } pCfg(); },
    xstat: pStat,
    xspygo: guard((S, a) => { const [t, k] = sp2(a); spyGo(S, +t, k); re(); }), xspyctr: guard(S => { spyCounter(S); re(); }),
    xmk: guard((S, a) => { EX(S).mr.ui.kid = a; re(); }), xmt: guard((S, a) => { EX(S).mr.ui.tier = +a; re(); }), xmp: guard((S, a) => { mrPropose(S, +a); re(); }),
    xmans: guard((S, a) => { const [i, y] = sp2(a); mrAnswer(S, +i, y === '1'); re(); }), xmclaim: guard((S, a) => { mrClaimWar(S, +a); re(); }),
    xfset: guard((S, a) => { faithChoose(S, a); re(); }), xfgive: guard(S => { faithGive(S); re(); }), xfmis: guard((S, a) => { faithMission(S, a); re(); }),
    xrta: guard((S, a) => { EX(S).rt.ui.a = +a; re(); }), xrtb: guard((S, a) => { rtCreate(S, EX(S).rt.ui.a, +a); re(); }), xrtcancel: guard(S => { EX(S).rt.ui.a = null; re(); }),
    xrtup: guard((S, a) => { rtUpgrade(S, a); re(); }), xrtg: guard((S, a) => { const r = EX(S).rt.list.find(q => q.id === +a); if (r) r.guard = r.guard ? 0 : 1; re(); }),
    xrtdel: guard((S, a) => { const e = EX(S); e.rt.list = e.rt.list.filter(q => q.id !== +a); re(); }),
    xstm(k) { RFX.metric = k; pStat(); }, xrepplay() { const S = UI.S; if (S) replayPlay(S, EX(S)); },
    xsave(n) { slotSave(+n); pSlots(); }, xload(n) { slotLoad(+n); }, xdel(n) { try { localStorage.removeItem('kc_slot' + n); localStorage.removeItem('kc_slotm' + n); } catch (er) { } pSlots(); },
    xdgo() { dailyStart(); }, xcgo(i) { campStart(+i); }, xbld: pBld, xbbuy: guard((S, a) => { blBuy(S, a); re(); }), xguide: pGuide, xev: guard((S, a) => evAnswer(S, a)),
    xsev(v) { if (v in SEV) { RFX.cfg.sev = v; metaSave(); } pCfg(); }, xnotif(v) { if (['all', 'key', 'off'].includes(v)) { RFX.cfg.notif = v; metaSave(); } pCfg(); },
    xexport() { saveExport(); }, ximport() { saveImport(); }, xfadd() { friendAdd(); },
    xcopy() { const t = RFX.share || ''; try { navigator.clipboard.writeText(t); } catch (er) { } if (UI.S) say(L('Result copied', 'Hasil disalin'), true); }
  });
  /* kecepatan x8 (offline) */
  const _speed = ACT.speed;
  ACT.speed = function () { if (NET.active) return _speed.call(ACT); UI.speed = UI.speed === 1 ? 2 : UI.speed === 2 ? 4 : UI.speed === 4 ? 8 : 1; renderTabs(); };
  /* menu jeda: tambah tombol EXTRA */
  const _smm = showMenuModal;
  showMenuModal = function () { _smm(); try { const ft = document.querySelector('#modal .ft'); if (ft && on(UI.S)) ft.insertAdjacentHTML('afterbegin', btn('xhub', 'EXTRA', 'gold')); } catch (er) { } };

  /* ================= LOOP ================= */
  function fab() {
    const b = rfFab('xFab', 'xhub', 'scroll', 'EXTRA', ''); if (!b) return; const v = on(UI.S);
    if (v !== fab._v) { b.style.display = v ? 'flex' : 'none'; fab._v = v; }
  }
  function dayStep(S, e) {
    weatherStep(S, e); spyAIDay(S, e); mrDay(S, e); faithDay(S, e); rtDay(S, e);
  }
  function yearStep(S, e) { mrYear(S, e); faithYear(S, e); aiYear(S); histRecord(S, e); }
  function secTick(S, e) {
    const p = S.players[VP], m = MODS.cfg; seasonTick(S, e);
    p.atkMod = 1 + techSum(S, 'atk') + (e.rl.faith === 'iron' ? faithMag(e) * 0.8 : 0);
    if (m.build || m.train || m.rich || m.god || m.auto || m.power > 1) e.st.cheat = 1;
    if (S.tk % 20 === 0) rtFlags(S, e);
    if (S.tk % 8 === 0) { questTick(S, e); achCheck(S, e); }
    if (S.tk % 8 === 4) blCheck(S, e);
    evShow(S, e);
    if (!RFX.meta.guide && S.time > 15 && $('modal').classList.contains('hidden')) { RFX.meta.guide = 1; metaSave(); pGuide(); }
    if (S.opts.camp) campCheck(S, e); if (S.opts.daily) dailyCheck(S, e);
  }
  function xTick(S, dt) {
    const e = EX(S); fab();
    if (e.day < 0) { e.day = Math.floor(S.time / DAY); e.yr = Math.floor(S.time / RY); if (!e.h.y.length) histRecord(S, e); if (!e.q.act.length) questFill(S, e); }
    spyTick(S, e); healTick(S, dt);
    if (S.tk % 4 === 0) secTick(S, e);
    const d = Math.floor(S.time / DAY); let n = 0; while (e.day < d && n++ < 400) { e.day++; dayStep(S, e); }
    const y = Math.floor(S.time / RY); while (e.yr < y) { e.yr++; yearStep(S, e); }
  }
  const _tick = tick;
  tick = function (S, dt) { try { if (on(S)) xTick(S, dt); } catch (er) { console.error(er); } return _tick(S, dt); };
  const _draw = MODS.draw;
  MODS.draw = function (c, S, vx0, vx1, vy0, vy1) {
    _draw.call(MODS, c, S, vx0, vx1, vy0, vy1);
    try { if (on(S)) { blDraw(c, S, vx0, vx1, vy0, vy1); rtDraw(c, S, vx0, vx1, vy0, vy1); fxDraw(c, S); } } catch (er) { }
  };
})();
