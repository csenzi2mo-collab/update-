'use strict';
/* ===== Экраны «Игра по сети»: создание, список найденных игр (автопоиск), вход по IP/коду, лобби ===== */
const NU = { name: (localStorage.getItem('kc_name') || '').slice(0, 16), answer: null, offer: null, codeInv: false, err: '', inLobby: false, lastCount: 0, opts: { type: 'continent', size: 'm', bots: 2, diff: 'normal', win: 'caps', target: 30000, sandbox: 0 } };
const nuScreen = html => { $('menu').classList.add('hidden'); const el = $('create'); el.classList.remove('hidden'); el.innerHTML = '<div class="nbox">' + html + '</div>'; };
const nuNote = (t, ok) => { const e = $('nnote'); if (e) { e.textContent = t || ''; e.className = ok ? 'gd' : 'bad'; } };
const nuName = () => { const e = $('nname'); const v = ((e && e.value) || NU.name || '').trim().slice(0, 16) || 'Игрок'; NU.name = v; localStorage.setItem('kc_name', v); return v; };
const nuHelp = 'Телефоны должны быть в одной Wi-Fi сети. Если игры не находятся — включите точку доступа на телефоне хозяина и подключите остальных к ней. Интернет не нужен.';
function nuCopy(id) {
  const t = $(id); if (!t) return; t.focus(); t.select(); t.setSelectionRange(0, 1e6); let ok = false;
  try { ok = document.execCommand('copy'); } catch (e) {}
  if (!ok && navigator.clipboard) navigator.clipboard.writeText(t.value).then(() => nuNote('Код скопирован', true), () => nuNote('Выделите код и скопируйте вручную', false));
  else nuNote(ok ? 'Код скопирован' : 'Выделите код и скопируйте вручную', ok);
}
const codeBox = (id, val, ro) => `<textarea id="${id}" class="code" ${ro ? 'readonly' : ''} placeholder="${ro ? '' : 'Вставьте код сюда'}" spellcheck="false" autocomplete="off" autocapitalize="off">${val || ''}</textarea>`;
const codeBtns = id => `<div class="seg">${btn('netcopy:' + id, 'Копировать')}${navigator.share ? btn('netshare:' + id, 'Отправить') : ''}${btn('netpaste:' + id, 'Вставить')}</div>`;

function showNetMenu() {
  NET.stop(); LAN.stopScan(); NU.inLobby = false; NU.answer = null; NU.offer = null; NU.codeInv = false;
  nuScreen(`<h2>Игра по сети</h2><div class="dim" style="text-align:center">${nuHelp}</div>
  <div class="grp"><div class="lb">Ваше имя</div><input id="nname" class="txt" maxlength="16" value="${esc(NU.name)}" placeholder="Игрок"></div>
  <div class="col" style="margin:8px auto;width:100%"><button class="px big gold" data-act="nethost">СОЗДАТЬ ИГРУ</button><button class="px big" data-act="netjoin">ПРИСОЕДИНИТЬСЯ</button><button class="px" data-act="netback">НАЗАД</button></div>`);
}
/* Экран гостя: найденные игры появляются сами, достаточно нажать на нужную */
function showJoin() {
  nuScreen(`<h2>Найти игру</h2><div class="dim" style="text-align:center">${nuHelp}</div>
  <div class="grp"><div class="lb">Ваше имя</div><input id="nname" class="txt" maxlength="16" value="${esc(NU.name)}" placeholder="Игрок"></div>
  <div class="grp"><div class="lb">Игры в сети</div><div id="nsrv"></div></div>
  <div id="nnote" class="bad" style="min-height:20px"></div>
  <div class="col" style="margin:6px auto;width:100%"><button class="px" data-act="netrescan">ОБНОВИТЬ</button><button class="px" data-act="netmanual">ДРУГИЕ СПОСОБЫ</button><button class="px" data-act="netmenu">НАЗАД</button></div>`);
  NU.scanErr = '';
  if (!LAN.plug()) { NU.scanErr = 'Автопоиск работает только в установленном приложении (APK). Откройте «ДРУГИЕ СПОСОБЫ».'; renderServers(); return; }
  renderServers();
  LAN.startScan().catch(e => { NU.scanErr = 'Не удалось начать поиск игр'; renderServers(); });
}
function renderServers() {
  const e = $('nsrv'); if (!e) return;
  if (NU.scanErr) { e.innerHTML = `<div class="bad">${esc(NU.scanErr)}</div>`; return; }
  const list = LAN.list();
  if (!list.length) { e.innerHTML = '<div class="dim">Ищем игры в сети… Пусть друг нажмёт «СОЗДАТЬ ИГРУ» — она появится здесь сама.</div>'; return; }
  e.innerHTML = list.map(s => {
    const bad = s.ver && s.ver !== NET_VER, run = !!s.started, back = run && s.gone > 0, full = !run && s.players >= s.max;
    const st = bad ? 'другая версия игры — обновите приложение' : back ? 'идёт игра — можно вернуться под своим именем' : run ? 'игра уже идёт' : full ? 'нет мест' : 'ждёт игроков';
    const ok = !bad && !full && (!run || back);
    return `<button class="px srv${ok ? '' : ' off'}" data-act="${ok ? 'netpick:' + esc(s.id) : 'netnop'}"><b>${esc(s.name)}</b> <span class="dim">${s.players}/${s.max}</span><br><span class="${ok ? 'gd' : 'dim'}">${st}</span></button>`;
  }).join('');
}
NET.sub('servers', renderServers);
/* Запасные способы: вход по IP хозяина и по коду (если автопоиск не работает) */
function showJoinManual() {
  nuScreen(`<h2>Другие способы</h2>
  <div class="grp"><div class="lb">По адресу хозяина (он виден у него в лобби)</div><div class="seg"><input id="nip" class="txt" style="flex:3" inputmode="decimal" placeholder="192.168.0.5" value="${esc(NU.ip || '')}">${btn('netip', 'Войти', 'gold')}</div></div>
  <div class="grp"><div class="lb">По коду (без автопоиска)</div>
  <div class="dim">1. Получите свой код и отправьте его хозяину игры (мессенджер, СМС).</div>
  ${NU.offer ? codeBox('noffer', NU.offer, true) + codeBtns('noffer') : `<button class="px big gold" data-act="netoffer">ПОЛУЧИТЬ КОД</button>`}
  <div class="dim" style="margin-top:8px">2. Хозяин пришлёт ответный код — вставьте его и подключайтесь.</div>
  ${codeBox('nans', '', false)}${codeBtns('nans')}</div>
  <div id="nnote" class="bad" style="min-height:20px"></div>
  <div class="col" style="margin:6px auto;width:100%"><button class="px big gold" data-act="netconnect">ПОДКЛЮЧИТЬСЯ ПО КОДУ</button><button class="px" data-act="netjoin">НАЗАД К СПИСКУ</button></div>`);
}
function showLobby() {
  NU.inLobby = true; NU.lastCount = 0; NU.invShown = false;
  nuScreen(`<h2>Лобби</h2><div id="nnote" class="bad" style="min-height:20px"></div>
  <div class="grp"><div class="lb">Игроки</div><div id="nlist"></div></div>
  <div class="grp"><div class="lb">Ваше государство</div><div class="seg" id="nnat"></div></div>
  <div id="nopts"></div><div id="ninv"></div>
  <div class="grp"><div class="lb">Чат</div><div id="nchat" class="dim" style="max-height:90px;overflow-y:auto"></div><div class="seg"><input id="nchatin" class="txt" maxlength="120" placeholder="Сообщение" style="flex:3">${btn('netsay', 'Отправить')}</div></div>
  <div class="col" style="margin:8px auto;width:100%"><button class="px big gold" id="nstart" data-act="netstart">НАЧАТЬ ИГРУ</button><button class="px" data-act="netleave">ВЫЙТИ</button></div>`);
  if (NET.lobby) nuLobby(NET.lobby);
}
function renderInv() {
  const e = $('ninv'); if (!e) return;
  if (!NET.host) { e.innerHTML = ''; return; }
  const lan = NET.lan, hasLan = !!LAN.plug();
  const info = !hasLan ? '<div class="dim">Автопоиск работает только в приложении (APK). Приглашайте игроков по коду.</div>'
    : !lan ? '<div class="dim">Открываем игру для сети…</div>'
    : lan.err ? '<div class="bad">Автопоиск не запустился. Приглашайте по коду.</div>'
    : `<div class="gd">Ваша игра видна всем в сети — гости увидят её в списке сами.</div>${lan.ips && lan.ips.length ? `<div class="dim">Адрес для входа вручную: ${lan.ips.map(esc).join(', ')}</div>` : ''}`;
  const code = `<div class="dim">1. Гость открывает «ДРУГИЕ СПОСОБЫ», нажимает «ПОЛУЧИТЬ КОД» и присылает вам код. Вставьте его:</div>${codeBox('nin', '', false)}
    <div class="seg">${btn('netpaste:nin', 'Вставить')}${btn('netaccept', 'Принять гостя', 'gold')}</div>
    ${NU.answer ? `<div class="dim" style="margin-top:6px">2. Отправьте этот ответный код гостю — он появится в списке:</div>${codeBox('nout', NU.answer, true)}${codeBtns('nout')}` : ''}`;
  e.innerHTML = `<div class="grp"><div class="lb">Игроки подключаются</div>${info}${hasLan && !(NU.codeInv || NU.answer) ? btn('netcodeinv', 'Пригласить по коду') : code}</div>`;
}
function nuLobby(m) {
  if (!NU.inLobby || !$('nlist')) return;
  const ps = m.players.filter(Boolean), me = m.players[NET.slot], taken = new Set(ps.filter(p => p.slot !== NET.slot && p.nat >= 0).map(p => p.nat));
  $('nlist').innerHTML = ps.map(p => `<div class="nrow">${p.nat >= 0 ? sw(PCOL[p.nat]) : sw('#555')}<b>${esc(p.name)}</b>${p.host ? ' <span class="dim">хозяин</span>' : ''}${p.slot === NET.slot ? ' <span class="dim">(вы)</span>' : ''}</div>`).join('') + (m.opts.bots ? `<div class="dim">+ ботов: ${m.opts.bots}</div>` : '');
  $('nnat').innerHTML = PNAMES.map((n, i) => taken.has(i) ? `<button class="px" style="opacity:.3" data-act="netnat:-1">${sw(PCOL[i])}</button>` : btn('netnat:' + i, sw(PCOL[i]), me && me.nat === i ? 'on' : '')).join('');
  const o = m.opts, seg = (k, list) => `<div class="seg">${list.map(x => btn(`netset:${k}=${x[0]}`, x[1], o[k] === x[0] ? 'on' : '')).join('')}</div>`;
  const names = { continent: 'Материк', continents: 'Континенты', islands: 'Острова', lakes: 'Озёра' }, sizes = { s: 'малая', m: 'средняя', l: 'большая' }, diffs = { easy: 'лёгкие', normal: 'средние', hard: 'сложные', mixed: 'разные' };
  $('nopts').innerHTML = NET.host ? `<div class="grp"><div class="lb">Карта</div>${seg('type', [['continent', 'Материк'], ['continents', 'Континенты'], ['islands', 'Острова'], ['lakes', 'Озёра']])}${seg('size', [['s', 'Малая'], ['m', 'Средняя'], ['l', 'Большая']])}</div>
    <div class="grp"><div class="lb">Боты: ${o.bots}, сложность</div>${seg('bots', [[0, '0'], [1, '1'], [2, '2'], [3, '3'], [4, '4'], [5, '5']])}${seg('diff', [['easy', 'Лёгкая'], ['normal', 'Средняя'], ['hard', 'Сложная'], ['mixed', 'Разная']])}</div>
    <div class="grp"><div class="lb">Конец игры</div>${seg('win', [['score', 'По очкам'], ['caps', 'Захват столиц']])}${seg('sandbox', [[0, 'Обычная'], [1, 'Песочница']])}</div>`
    : `<div class="dim">Карта: ${names[o.type]}, ${sizes[o.size]}. Боты: ${o.bots} (${diffs[o.diff]}). ${o.sandbox ? 'Песочница.' : o.win === 'score' ? 'Победа по очкам.' : 'Победа: захват столиц.'}</div><div class="dim">Ждите, пока хозяин начнёт игру.</div>`;
  $('nstart').classList.toggle('hidden', !NET.host); $('nstart').textContent = 'НАЧАТЬ ИГРУ (' + ps.length + ')';
  if (NET.host && !NU.invShown) { NU.invShown = true; renderInv(); } if (!NET.host && NU.invShown) { NU.invShown = false; $('ninv').innerHTML = ''; }
  if (ps.length > NU.lastCount && NU.answer) { NU.answer = null; renderInv(); } NU.lastCount = ps.length;
}
NET.sub('lobby', nuLobby);
NET.sub('start', () => { NU.inLobby = false; });
NET.sub('error', m => { NU.err = m.msg; nuNote(m.msg, false); });
NET.sub('lan', () => renderInv());
NET.sub('desync', () => { if (UI.S && !UI.S.over) say('Игры на устройствах разошлись. Если это повторяется — начните заново.', false); });
NET.sub('closed', () => { if (NU.inLobby && !NET.active) { const why = NU.err; NU.err = ''; showNetMenu(); nuNote(why || 'Связь с хозяином потеряна', false); } });

Object.assign(ACT, {
  netmenu() { showNetMenu(); },
  netback() { NET.stop(); LAN.stopScan(); NU.inLobby = false; $('create').classList.add('hidden'); $('menu').classList.remove('hidden'); },
  nethost() { nuName(); NU.answer = null; NU.codeInv = false; NU.err = ''; NET.hostGame(NU.name, NU.opts); showLobby(); },
  netjoin() { nuName(); NU.offer = null; NU.err = ''; NET.stop(); LAN.stopScan(); showJoin(); },
  netrescan() { LAN.stopScan(); NU.scanErr = ''; if (LAN.plug()) { renderServers(); LAN.startScan().catch(e => { NU.scanErr = 'Не удалось начать поиск игр'; renderServers(); }); } },
  netnop() { nuNote('В эту игру сейчас нельзя войти', false); },
  netmanual() { nuName(); LAN.stopScan(); NET.stop(); showJoinManual(); },
  netcodeinv() { NU.codeInv = true; renderInv(); },
  async netpick(id) {
    const s = LAN.found.get(id); if (!s) return nuNote('Игра пропала из списка — нажмите «ОБНОВИТЬ»', false);
    nuName(); NU.err = ''; nuNote('Подключаемся…', true);
    try { await NET.joinLan(s, NU.name); LAN.stopScan(); showLobby(); } catch (e) { nuNote('Не удалось подключиться. Проверьте, что оба телефона в одной сети', false); }
  },
  async netip() {
    const t = $('nip'), v = t ? t.value.trim() : ''; if (!/^\d{1,3}(\.\d{1,3}){3}(:\d{1,5})?$/.test(v)) return nuNote('Введите адрес вида 192.168.0.5', false);
    NU.ip = v; nuName(); NU.err = ''; nuNote('Подключаемся…', true); const [ip, port] = v.split(':');
    try { await NET.joinLan({ ip, port: +port || 47601 }, NU.name); showLobby(); } catch (e) { nuNote('Не удалось подключиться. Проверьте, что оба телефона в одной сети', false); }
  },
  async netoffer() { nuNote('Готовим код…', true); try { NU.offer = await NET.guestOffer(); showJoinManual(); } catch (e) { nuNote('Не удалось создать код: ' + e.message, false); } },
  async netconnect() {
    const t = $('nans'); if (!t || !t.value.trim()) return nuNote('Вставьте ответный код хозяина', false);
    if (!NU.offer) return nuNote('Сначала получите свой код и отправьте хозяину', false);
    nuNote('Подключаемся…', true);
    try { await NET.guestFinish(t.value, NU.name); showLobby(); } catch (e) { nuNote(e.message, false); }
  },
  async netaccept() {
    const t = $('nin'); if (!t || !t.value.trim()) return nuNote('Вставьте код гостя', false);
    nuNote('Готовим ответ…', true);
    try { NU.answer = await NET.hostAccept(t.value); renderInv(); nuNote('Отправьте ответный код гостю', true); } catch (e) { nuNote(e.message === 'Неверный код' ? 'Это не код приглашения' : 'Не удалось принять: ' + e.message, false); }
  },
  netset(a) { const [k, v] = a.split('='); NU.opts[k] = isNaN(+v) ? v : +v; if (NU.opts.sandbox) NU.opts.win = 'caps'; NET.setOpts(NU.opts); },
  netnat(a) { if (+a >= 0) NET.setNat(+a); },
  netstart() { NET.startGame(); },
  netleave() { showNetMenu(); },
  netcopy(id) { nuCopy(id); },
  netshare(id) { const t = $(id); if (t && navigator.share) navigator.share({ text: t.value }).catch(() => {}); },
  async netpaste(id) { const t = $(id); try { const s = await navigator.clipboard.readText(); if (t && s) { t.value = s; nuNote('Код вставлен', true); } } catch (e) { nuNote('Нажмите на поле и вставьте код вручную', false); } },
});

/* ----- чат и меню во время сетевой игры ----- */
const nuLine = m => `<div><b style="color:#e8c870">${esc(m.name)}:</b> ${esc(m.text)}</div>`;
NET.sub('chat', m => {
  if (NU.inLobby && $('nchat')) { $('nchat').innerHTML += nuLine(m); $('nchat').scrollTop = 1e6; }
  else if (UI.S) UI.S.toast.push({ title: m.name, text: m.text, t: UI.S.time });
});
function netPlayersHtml() {
  const S = UI.S; return (NET.roster || []).map(r => { const p = S.players[r.pid], on = p && p.human; return `<div class="nrow">${sw(p.col)}<b>${esc(r.name)}</b> <span class="${on ? 'gd' : 'bad'}">${on ? 'в игре' : p.alive ? 'вышел — играет советник' : 'выбыл'}</span>${p.alive ? '' : ' <span class="dim">(без городов)</span>'}</div>`; }).join('');
}
const _menuOrig = showMenuModal;
showMenuModal = function () {
  if (!NET.active) return _menuOrig();
  showModal('Меню', `<div class="dim">Игра идёт у всех одновременно: пауза и сохранение недоступны.</div>${netPlayersHtml()}<div id="nnote" class="bad"></div>`,
    btn('closemodal', 'Продолжить', 'gold') + (NET.host ? btn('netinvite', 'Вернуть игрока') : '') + btn('netchat', 'Написать') + btn('settings', 'Настройки') + btn('howto', 'Как играть') + btn('tomenu', 'В главное меню'));
};
Object.assign(ACT, {
  netinvite() { showModal('Вернуть игрока', `<div class="dim">Вышедший игрок открывает «ПО СЕТИ → ПРИСОЕДИНИТЬСЯ», вводит то же имя и выбирает вашу игру в списке (или присылает вам код). Игра догонит его автоматически.</div><div id="ninv"></div><div id="nnote" class="bad"></div>`, btn('closemodal', 'Закрыть')); NU.answer = null; renderInv(); },
  netchat() { showModal('Сообщение', `<input id="nchatin" class="txt" maxlength="120" placeholder="Сообщение всем игрокам">`, btn('netsay', 'Отправить', 'gold') + btn('closemodal', 'Закрыть')); },
  netsay() { const e = $('nchatin'); if (e && e.value.trim()) { NET.chat(e.value.trim()); e.value = ''; } if (UI.S && !$('nchat')) ACT.closemodal(); },
});
