'use strict';
/* ===== Локальный мультиплеер без сервера =====
   Хозяин (телефон, создавший игру) — «ретранслятор»: раздаёт всем одинаковый поток ходов {n, cmds}
   каждые 250 мс. Каждое устройство считает игру у себя (детерминированный lockstep).
   Связь между телефонами: (1) автоматически по локальной сети — игры хозяев сами появляются в списке у гостей (нативный плагин KCLan:
   UDP-«маяк» + TCP); (2) запасной способ — WebRTC DataChannel, код приглашения/ответа передаётся вручную (копировать/вставить). */

const NET_VER = '1.31.0';   // версия игры: телефоны с разными версиями вместе играть не могут (должна совпадать с package.json)
const TURN_MS = 250, MAX_HUMANS = 8, MAX_CMD_BYTES = 2048, MAX_CMDS_PER_TURN = 12, LAN_GAME_PORT = 47601;
const clone = m => JSON.parse(JSON.stringify(m));

/* Канал связи: {send(m), close(), recv(m) <- вызывает транспорт, onclose() <- вызывает транспорт} */
function makePair() {   // два соединённых канала в памяти (хозяин ↔ сам себе, и тесты)
  const a = { recv: null, onclose: null, dead: false }, b = { recv: null, onclose: null, dead: false };
  const link = (x, y) => { x.send = m => { if (x.dead) return; const c = JSON.stringify(m); queueMicrotask(() => { if (!y.dead && y.recv) y.recv(JSON.parse(c)); }); }; x.close = () => { if (x.dead) return; x.dead = true; y.dead = true; queueMicrotask(() => { x.onclose && x.onclose(); y.onclose && y.onclose(); }); }; };
  link(a, b); link(b, a); return [a, b];
}

function sanitizeOpts(o) {
  o = o || {}; const pick = (v, list, d) => list.includes(v) ? v : d;
  return { type: pick(o.type, ['continent', 'continents', 'islands', 'lakes'], 'continent'), size: pick(o.size, ['s', 'm', 'l'], 'm'),
    bots: Math.max(0, Math.min(7, o.bots | 0)), diff: pick(o.diff, ['easy', 'normal', 'hard', 'mixed'], 'normal'),
    win: pick(o.win, ['score', 'caps'], 'caps'), target: Math.max(0, Math.min(200000, o.target | 0)), sandbox: o.sandbox ? 1 : 0 };
}

/* ----- Хозяин: комната, лобби, поток ходов ----- */
class HostRelay {
  constructor(opts) { this.opts = sanitizeOpts(opts); this.peers = []; this.started = false; this.turn = 0; this.pending = []; this.timer = null; this.hashes = new Map(); this.seed = 0; }
  addPeer(link) {
    let slot = this.peers.findIndex(p => !p); if (slot < 0) slot = this.peers.length;
    if (slot >= MAX_HUMANS || (this.started && !(this.roster || []).some(r => r.gone))) { link.send({ t: 'error', msg: this.started ? 'Игра уже началась' : 'Комната заполнена' }); setTimeout(() => link.close(), 50); return -1; }
    const p = { link, name: 'Игрок', nat: -1, ready: false, pid: -1, hello: false }; this.peers[slot] = p;
    link.recv = m => this.onMsg(slot, m); link.onclose = () => this.onClose(slot, link); return slot;
  }
  bcast(m) { for (const p of this.peers) if (p) p.link.send(m); if (m.t === 'lobby') this.touch(); }
  info() { const h = this.peers[this.hostSlot()]; return { name: h ? h.name : 'Игрок', players: this.peers.filter(p => p && p.hello).length, max: MAX_HUMANS, started: this.started ? 1 : 0, gone: this.started ? (this.roster || []).filter(r => r.gone).length : 0, ver: NET_VER }; }
  touch() { if (this.onInfo) this.onInfo(this.info()); }   // сообщить «маяку» о новом числе игроков
  lobby() { return { t: 'lobby', opts: this.opts, started: this.started, players: this.peers.map((p, i) => p && p.hello ? { slot: i, name: p.name, nat: p.nat, host: i === this.hostSlot(), ready: p.ready } : null) }; }
  hostSlot() { return this.peers.findIndex(p => !!p); }   // хозяин — первый подключённый (его же устройство)
  onMsg(slot, m) {
    const p = this.peers[slot]; if (!p || !m || typeof m.t !== 'string') return;
    switch (m.t) {
      case 'hello': {
        p.name = String(m.name || 'Игрок').replace(/[<>&"]/g, '').slice(0, 16) || 'Игрок';
        if (this.started) {   // возвращение вышедшего игрока: то же имя, повтор партии с начала по журналу ходов
          const r = this.roster.find(q => q.gone && q.name.toLowerCase() === p.name.toLowerCase());
          if (!r) { p.link.send({ t: 'error', msg: 'Нет вышедшего игрока с таким именем. Введите то же имя, с которым играли' }); setTimeout(() => p.link.close(), 50); return; }
          p.hello = true; p.pid = r.pid; r.gone = false; p.link.send({ t: 'joined', slot, host: false }); p.link.send(Object.assign({ t: 'start', pid: r.pid, resume: true }, this.startMsg));
          for (let i = 0; i < this.log.length; i += 500) p.link.send({ t: 'catchup', from: i, turns: this.log.slice(i, i + 500) });
          this.pending.push({ p: r.pid, c: { k: '_back' } }); this.touch(); return;
        }
        p.hello = true; p.link.send({ t: 'joined', slot, host: slot === this.hostSlot() }); this.bcast(this.lobby()); break;
      }
      case 'opts': if (slot === this.hostSlot() && !this.started) { this.opts = sanitizeOpts(m.opts); this.bcast(this.lobby()); } break;
      case 'nat': if (!this.started) { p.nat = (m.v | 0) >= 0 && (m.v | 0) < 8 ? m.v | 0 : -1; this.bcast(this.lobby()); } break;
      case 'ready': if (!this.started) { p.ready = !!m.v; this.bcast(this.lobby()); } break;
      case 'start': if (slot === this.hostSlot() && !this.started) this.start(); break;
      case 'cmd': {
        if (!this.started || !m.c || typeof m.c !== 'object' || p.pid < 0) return;
        if (JSON.stringify(m.c).length > MAX_CMD_BYTES) return;
        if (this.pending.reduce((n, x) => n + (x.p === p.pid ? 1 : 0), 0) >= MAX_CMDS_PER_TURN) return;
        this.pending.push({ p: p.pid, c: m.c }); break;   // pid ставит ХОЗЯИН — выдать себя за другого нельзя
      }
      case 'hash': {
        if (!this.started) return; const e = this.hashes.get(m.n) || { h: m.h, bad: false };
        if (e.h !== m.h && !e.bad) { e.bad = true; this.bcast({ t: 'desync', n: m.n }); } this.hashes.set(m.n, e); if (this.hashes.size > 20) this.hashes.delete(this.hashes.keys().next().value); break;
      }
      case 'chat': this.bcast({ t: 'chat', from: slot, name: p.name, text: String(m.text || '').slice(0, 120) }); break;
    }
  }
  start() {
    const humans = []; this.peers.forEach((p, i) => { if (p && p.hello) humans.push(i); });
    if (!humans.length) return; this.started = true;
    const used = new Set(), nats = {};
    for (const s of humans) { const n = this.peers[s].nat; if (n >= 0 && !used.has(n)) { used.add(n); nats[s] = n; } }
    for (const s of humans) if (nats[s] === undefined) { let n = 0; while (used.has(n)) n++; used.add(n); nats[s] = n; }
    this.seed = ((Math.random() * 1e9) | 0) % 1000000000;
    const roster = humans.map((s, i) => { this.peers[s].pid = i; return { pid: i, slot: s, name: this.peers[s].name, nat: nats[s] }; });
    const opts = Object.assign({}, this.opts, { bots: Math.min(this.opts.bots, 8 - roster.length) });
    this.startMsg = { seed: this.seed, opts, roster }; this.roster = roster.map(r => Object.assign({}, r, { gone: false })); this.log = [];
    for (const p of this.peers) if (p && p.hello) p.link.send(Object.assign({ t: 'start', pid: p.pid }, this.startMsg));
    this.turn = 0; this.pending = []; this.timer = setInterval(() => this.step(), TURN_MS); this.touch();
  }
  step() { const cmds = this.pending; this.pending = []; this.log.push(cmds); this.bcast({ t: 'turn', n: this.turn++, cmds }); }
  onClose(slot, link) {
    const p = this.peers[slot]; if (!p || p.link !== link) return;
    if (!this.started) { this.peers[slot] = null; while (this.peers.length && !this.peers[this.peers.length - 1]) this.peers.pop(); this.bcast(this.lobby()); return; }
    this.peers[slot] = null; if (p.pid < 0) return;
    const r = this.roster.find(q => q.pid === p.pid); if (r) r.gone = true; this.pending.push({ p: p.pid, c: { k: '_left' } }); this.touch();
    if (!this.peers.some(q => q)) this.stop();
  }
  stop() { if (this.timer) clearInterval(this.timer); this.timer = null; for (const p of this.peers) if (p) { try { p.link.close(); } catch (e) {} } this.peers = []; }
}

/* ----- Подключение WebRTC и обмен кодами вручную ----- */
const RTC_CFG = { iceServers: [] };    // одна Wi-Fi сеть / точка доступа: внешние серверы не нужны
const b64u = u8 => { let s = ''; for (let i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
const unb64u = s => { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
async function streamBytes(kind, bytes) { const cs = new (kind === 'z' ? CompressionStream : DecompressionStream)('deflate-raw'); const w = cs.writable.getWriter(); w.write(bytes); w.close(); return new Uint8Array(await new Response(cs.readable).arrayBuffer()); }
async function packCode(obj) {
  const raw = new TextEncoder().encode(JSON.stringify(obj)); let tag = 'p', bytes = raw;
  if (typeof CompressionStream === 'function') { try { bytes = await streamBytes('z', raw); tag = 'z'; } catch (e) { bytes = raw; tag = 'p'; } }
  return 'KC1' + tag + b64u(bytes);
}
async function unpackCode(code) {
  code = String(code || '').replace(/\s+/g, ''); if (!/^KC1[zp]/.test(code)) throw new Error('Неверный код');
  let bytes = unb64u(code.slice(4)); if (code[3] === 'z') bytes = await streamBytes('d', bytes);
  return JSON.parse(new TextDecoder().decode(bytes));
}
function iceDone(pc, ms) { return new Promise(res => { if (pc.iceGatheringState === 'complete') return res(); const f = () => { if (pc.iceGatheringState === 'complete') { pc.removeEventListener('icegatheringstatechange', f); res(); } }; pc.addEventListener('icegatheringstatechange', f); setTimeout(res, ms || 5000); }); }
function rtcLink(dc) {   // обёртка DataChannel в «канал связи»
  const l = { recv: null, onclose: null, send: m => { if (dc.readyState === 'open') dc.send(JSON.stringify(m)); }, close: () => { try { dc.close(); } catch (e) {} } };
  dc.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch (x) { return; } if (l.recv) l.recv(m); };
  dc.onclose = () => { if (l.onclose) l.onclose(); }; return l;
}

/* ----- Автопоиск игр в локальной сети (нативный плагин KCLan, только в APK) ----- */
const LAN = {
  _p: null, _inited: false, myId: '', hosting: false, scanning: false, conns: {}, guest: null, found: new Map(), scanTimer: null,
  plug() {   // нативный плагин или null (в браузере / старом APK его нет)
    if (this._p) return this._p;
    const C = typeof Capacitor !== 'undefined' ? Capacitor : null; if (!C) return null;
    try { if (C.isPluginAvailable && !C.isPluginAvailable('KCLan')) return null; this._p = (C.Plugins && C.Plugins.KCLan) || (C.registerPlugin ? C.registerPlugin('KCLan') : null); } catch (e) { this._p = null; }
    return this._p;
  },
  init() {
    const P = this.plug(); if (!P || this._inited) return; this._inited = true;
    P.addListener('server', d => this.onServer(d)); P.addListener('hostOpen', d => this.onHostOpen(d)); P.addListener('hostMsg', d => this.onHostMsg(d)); P.addListener('hostClose', d => this.onHostClose(d));
    P.addListener('linkMsg', d => this.onLinkMsg(d)); P.addListener('linkClose', d => this.onLinkClose(d));
  },
  /* --- хозяин --- */
  async startHost(info) {
    const P = this.plug(); if (!P) return null; this.init(); this.myId = this.myId || 'k' + Math.random().toString(36).slice(2, 10); this.hosting = true;
    return P.startHost(Object.assign({ id: this.myId }, info));
  },
  update(info) { const P = this.plug(); if (P && this.hosting) P.hostUpdate(Object.assign({ id: this.myId }, info)); },
  stopHost() { if (!this.hosting) return; this.hosting = false; this.conns = {}; const P = this.plug(); if (P) P.stopHost(); },
  onHostOpen(d) {
    const P = this.plug(), id = d.id;
    if (!NET.relay) { P.hostClose({ id }); return; }
    const l = { id, recv: null, onclose: null, send: m => { P.hostSend({ id, data: JSON.stringify(m) }); }, close: () => { P.hostClose({ id }); } };
    this.conns[id] = l; NET.relay.addPeer(l);
  },
  onHostMsg(d) { const l = this.conns[d.id]; if (!l || !l.recv) return; let m; try { m = JSON.parse(d.data); } catch (e) { return; } l.recv(m); },
  onHostClose(d) { const l = this.conns[d.id]; delete this.conns[d.id]; if (l && l.onclose) l.onclose(); },
  /* --- гость: поиск и подключение --- */
  startScan() {
    const P = this.plug(); if (!P) return Promise.reject(new Error('Автопоиск работает только в приложении')); this.init(); this.found.clear(); this.scanning = true;
    if (!this.scanTimer) this.scanTimer = setInterval(() => this.prune(), 1000);
    return P.startScan();
  },
  stopScan() { if (this.scanTimer) { clearInterval(this.scanTimer); this.scanTimer = null; } this.found.clear(); if (!this.scanning) return; this.scanning = false; const P = this.plug(); if (P) P.stopScan(); },
  onServer(d) {
    if (!d || !d.id || d.id === this.myId || !this.scanning) return;
    const o = this.found.get(d.id); this.found.set(d.id, Object.assign({}, d, { seen: Date.now() }));
    if (!o || o.name !== d.name || o.players !== d.players || o.started !== d.started || o.gone !== d.gone || o.ip !== d.ip || o.port !== d.port || o.ver !== d.ver) NET.emit('servers', this.list());
  },
  prune() { let ch = false; const now = Date.now(); for (const [k, v] of this.found) if (now - v.seen > 4500) { this.found.delete(k); ch = true; } if (ch) NET.emit('servers', this.list()); },
  list() { return [...this.found.values()].sort((a, b) => (a.started - b.started) || String(a.name).localeCompare(String(b.name))); },
  async connect(ip, port) {
    const P = this.plug(); if (!P) throw new Error('Автоподключение работает только в приложении');
    this.init(); const r = await P.connect({ ip: String(ip).trim(), port: port | 0 || LAN_GAME_PORT }), id = r.id;
    const l = { id, recv: null, onclose: null, send: m => { P.linkSend({ data: JSON.stringify(m) }); }, close: () => { P.linkClose(); } };
    this.guest = l; return l;
  },
  disconnect() { const l = this.guest; this.guest = null; if (l) l.close(); },
  onLinkMsg(d) { const l = this.guest; if (!l || d.id !== l.id || !l.recv) return; let m; try { m = JSON.parse(d.data); } catch (e) { return; } l.recv(m); },
  onLinkClose(d) { const l = this.guest; if (!l || d.id !== l.id) return; this.guest = null; if (l.onclose) l.onclose(); },
};

/* ----- Клиентская часть (одинакова для хозяина и гостя) ----- */
const NET = {
  active: false,              // идёт сетевая партия
  relay: null, link: null, pc: null,
  slot: -1, pid: -1, host: false, lobby: null, roster: null, seed: 0, opts: null,
  q: [], turn: 0, desync: false, hashFn: null, listeners: {},
  sub(ev, f) { (this.listeners[ev] = this.listeners[ev] || []).push(f); },
  emit(ev, d) { (this.listeners[ev] || []).forEach(f => f(d)); },
  _bind(link, name) { this.link = link; link.recv = m => this.onMsg(m); link.onclose = () => { if (this.link !== link) return; const was = !!this.link; this.link = null; if (was) { this.active = false; this.emit('closed', {}); } }; link.send({ t: 'hello', name }); },
  /* хозяин: создать комнату */
  hostGame(name, opts) {
    this.stop(); this.relay = new HostRelay(opts); const [a, b] = makePair(); this.relay.addPeer(a); this._bind(b, name); this.lan = null;
    if (LAN.plug()) {   // игра сразу становится видна всем в сети: «маяк» + приём подключений
      const relay = this.relay; relay.onInfo = i => LAN.update(i);
      LAN.startHost(Object.assign(relay.info(), { name })).then(r => { if (this.relay === relay) { this.lan = r; this.emit('lan', r); } }, e => { if (this.relay === relay) { this.lan = { err: String((e && e.message) || e) }; this.emit('lan', this.lan); } });
    }
  },
  /* гость: подключиться к игре из списка (или по IP) — коды не нужны */
  async joinLan(srv, name) { this.stop(); const l = await LAN.connect(srv.ip, srv.port); this._bind(l, name); },
  /* хозяин: принять приглашение гостя (offerCode от гостя) → вернуть код-ответ для гостя */
  async hostAccept(offerCode) {
    if (!this.relay) throw new Error('Сначала создайте игру');
    const offer = await unpackCode(offerCode), pc = new RTCPeerConnection(RTC_CFG);
    pc.ondatachannel = e => { const dc = e.channel; const open = () => { this.relay.addPeer(rtcLink(dc)); }; if (dc.readyState === 'open') open(); else dc.onopen = open; };
    await pc.setRemoteDescription({ type: 'offer', sdp: offer.s }); await pc.setLocalDescription(await pc.createAnswer()); await iceDone(pc);
    (this.pcs = this.pcs || []).push(pc); return packCode({ s: pc.localDescription.sdp });
  },
  /* гость: шаг 1 — получить код-приглашение, который нужно отправить хозяину */
  async guestOffer() {
    this.stop(); const pc = this.pc = new RTCPeerConnection(RTC_CFG); this._dc = pc.createDataChannel('kc', { ordered: true });
    await pc.setLocalDescription(await pc.createOffer()); await iceDone(pc); return packCode({ s: pc.localDescription.sdp });
  },
  /* гость: шаг 2 — вставить код-ответ хозяина; вернётся, когда канал откроется */
  async guestFinish(answerCode, name) {
    const ans = await unpackCode(answerCode), pc = this.pc, dc = this._dc; if (!pc) throw new Error('Сначала получите код');
    await pc.setRemoteDescription({ type: 'answer', sdp: ans.s });
    await new Promise((res, rej) => { const t = setTimeout(() => rej(new Error('Не удалось соединиться. Проверьте, что оба телефона в одной сети')), 15000); const ok = () => { clearTimeout(t); res(); }; if (dc.readyState === 'open') ok(); else dc.onopen = ok; });
    this._bind(rtcLink(dc), name);
  },
  stop() { this.active = false; LAN.stopHost(); LAN.disconnect(); this.lan = null; if (this.relay) { this.relay.stop(); this.relay = null; } const l = this.link; this.link = null; if (l) { try { l.close(); } catch (e) {} } for (const p of (this.pcs || [])) { try { p.close(); } catch (e) {} } this.pcs = []; if (this.pc) { try { this.pc.close(); } catch (e) {} this.pc = null; } this.slot = -1; this.pid = -1; this.host = false; this.lobby = null; this.roster = null; this.q = []; this.turn = 0; this.desync = false; },
  send(m) { if (this.link) this.link.send(m); },
  setOpts(o) { this.send({ t: 'opts', opts: o }); }, setNat(v) { this.send({ t: 'nat', v }); }, ready(v) { this.send({ t: 'ready', v }); }, startGame() { this.send({ t: 'start' }); }, chat(text) { this.send({ t: 'chat', text }); },
  cmd(c) { this.send({ t: 'cmd', c }); },
  onMsg(m) {
    switch (m.t) {
      case 'joined': this.slot = m.slot; this.host = !!m.host; this.emit('joined', m); break;
      case 'lobby': this.lobby = m; this.host = !!(m.players[this.slot] && m.players[this.slot].host); this.emit('lobby', m); break;
      case 'start': this.seed = m.seed; this.opts = m.opts; this.roster = m.roster; this.pid = m.pid; this.q = []; this.turn = 0; this.desync = false; this.active = true; this.hashFn = null; this.emit('start', m); break;
      case 'turn': if (this.active) this.q.push(m); break;
      case 'catchup': if (this.active) m.turns.forEach((cmds, i) => this.q.push({ t: 'turn', n: m.from + i, cmds })); break;
      case 'desync': this.desync = true; this.emit('desync', m); break;
      case 'chat': this.emit('chat', m); break;
      case 'error': this.emit('error', m); break;
    }
  },
  /* игровой цикл забирает накопленные ходы; apply(turn) делает команды + один tick */
  drain(apply, max) {
    let n = 0; while (this.q.length && n < (max || 40)) { const t = this.q.shift(); apply(t); this.turn = t.n + 1; n++; if (this.hashFn && this.turn % 40 === 0) this.send({ t: 'hash', n: this.turn, h: this.hashFn() }); }
    return n;
  },
};
/* Запуск партии по сообщению 'start' (одинаково у всех устройств) */
function netGameOpts(m) {
  return Object.assign({}, m.opts, { seed: m.seed, humans: m.roster.length, nations: m.roster.map(r => r.nat), nation: m.roster[0].nat });
}
