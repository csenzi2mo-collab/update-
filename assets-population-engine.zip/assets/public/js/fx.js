'use strict';
/* ===== Шейдеры: пост-обработка картинки на видеокарте (WebGL) =====
   Игра рисует кадр на обычном 2D-холсте #cv. Здесь готовый кадр отдаётся фрагментному шейдеру, который добавляет:
   цветокоррекцию (сочность, холодные тени и тёплый свет, мягкий контраст), свечение ярких мест (снег, пена, окна ночью),
   живую воду (волны и блики привязаны к карте, а не к экрану), виньетку и дизеринг.
   Уровни: low — коррекция и виньетка; med — + вода и свечение; high — + крупная зыбь, широкое свечение.
   Если WebGL недоступен или слишком медленный, картинка остаётся прежней, игра не страдает. */
const FX = {
  q: 'med', eff: 'med', gl: null, cv: null, progs: {}, tex: null, dead: false, avg: 16.7, lastT: 0, cool: 0, N: { low: 1, med: 2, high: 3 },
  VS: 'attribute vec2 aP; varying vec2 vUv; void main(){ vUv = vec2(aP.x * 0.5 + 0.5, 0.5 - aP.y * 0.5); gl_Position = vec4(aP, 0.0, 1.0); }',
  fs(Q) {
    const dirs = [[1, 0], [0.7071, 0.7071], [0, 1], [-0.7071, 0.7071], [-1, 0], [-0.7071, -0.7071], [0, -1], [0.7071, -0.7071]];
    const ring = (r, k) => dirs.map(d => `bl += tap(vec2(${(d[0] * r).toFixed(3)}, ${(d[1] * r).toFixed(3)}) * uDpr) * ${k};`).join('\n    ');
    const bloom = Q >= 3 ? ring(2.2, '0.07') + '\n    ' + ring(5.5, '0.055') : Q >= 2 ? ring(3.2, '0.11') : '';
    return (`#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uTex; uniform vec2 uRes; uniform vec2 uCam; uniform float uZ, uDpr, uTime, uDark, uGrade; uniform vec3 uTint;
varying vec2 vUv;
float h21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
vec3 grade(vec3 c) { return mix(vec3(dot(c, vec3(0.299, 0.587, 0.114))), c, 1.0 - 0.36 * uGrade) * mix(vec3(1.0), uTint, uGrade); }
vec3 tap(vec2 o) { vec3 s = grade(texture2D(uTex, vUv + o / uRes).rgb); float th = 0.80 - 0.28 * uDark; return s * smoothstep(th, th + 0.18, dot(s, vec3(0.299, 0.587, 0.114))); }
void main() {
  vec3 c = grade(texture2D(uTex, vUv).rgb);
  float lum = dot(c, vec3(0.299, 0.587, 0.114));
  float mx = max(c.r, max(c.g, c.b)), mn = min(c.r, min(c.g, c.b)), sat = (mx - mn) / max(mx, 0.001);
  ${Q >= 2 ? `
  /* вода: синий, насыщенный, не слишком светлый (снег и камень не трогаем) */
  float wm = smoothstep(0.08, 0.2, c.b - max(c.r, c.g * 0.92)) * smoothstep(0.40, 0.52, sat) * (1.0 - smoothstep(0.55, 0.75, lum));
  if (wm > 0.0) {
    vec2 wp = (vUv * uRes / uDpr) / uZ + uCam, q = floor(wp);
    float w = sin(q.x * 0.45 + q.y * 0.28 + uTime * 1.4) * sin(q.y * 0.52 - q.x * 0.21 - uTime);
    c *= 1.0 + 0.07 * w * wm;
    ${Q >= 3 ? 'c *= 1.0 + 0.06 * sin(q.x * 0.07 + uTime * 0.3) * sin(q.y * 0.06 - uTime * 0.2) * wm;' : ''}
    float g = h21(floor(wp * 0.5) + floor(uTime * 1.6) * vec2(7.13, 3.71));
    c += vec3(0.55, 0.75, 0.85) * step(0.988, g) * wm * (1.0 - uDark * 0.6);
  }
  /* свечение ярких мест; ночью сильнее (огни городов, кузни) */
  vec3 bl = vec3(0.0);
    ${bloom}
  c += bl * (0.45 + 0.9 * uDark);` : ''}
  /* цвет: сочность, холодные тени / тёплый свет, мягкий S-контраст */
  float l2 = dot(c, vec3(0.299, 0.587, 0.114));
  c = mix(vec3(l2), c, 1.14);
  c *= mix(vec3(0.91, 0.97, 1.09), vec3(1.07, 1.03, 0.94), smoothstep(0.18, 0.75, l2));
  c = clamp(c, 0.0, 1.0); c = mix(c, c * c * (3.0 - 2.0 * c), 0.3);
  /* виньетка (ночью сильнее) и дизеринг против полос */
  vec2 d = (vUv - 0.5) * vec2(uRes.x / uRes.y, 1.0);
  c *= 1.0 - smoothstep(0.42, 1.0, length(d) * 1.15) * (0.28 + 0.25 * uDark);
  c += (h21(gl_FragCoord.xy + fract(uTime) * 91.7) - 0.5) * (1.6 / 255.0);
  gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}`).replace(/\/\*[\s\S]*?\*\//g, '');
  },
  load() { let v = 'med'; try { v = localStorage.getItem('kc_gfx') || 'med'; } catch (e) {} this.q = this.eff = ['off', 'low', 'med', 'high'].includes(v) ? v : 'med'; },
  setQ(q) { this.q = this.eff = q; this.avg = 16.7; this.cool = 0; try { localStorage.setItem('kc_gfx', q); } catch (e) {} if (this.cv) this.cv.style.display = (q === 'off' || this.dead) ? 'none' : 'block'; },
  init() {
    if (this.dead || typeof document === 'undefined' || !RN.cv) return false;
    try {
      const cv = document.createElement('canvas'); cv.id = 'gl'; RN.cv.parentNode.insertBefore(cv, RN.cv.nextSibling);
      const gl = cv.getContext('webgl', { alpha: false, antialias: false, depth: false, stencil: false, preserveDrawingBuffer: false, powerPreference: 'high-performance' });
      if (!gl) { cv.remove(); this.dead = true; return false; }
      cv.addEventListener('webglcontextlost', e => { e.preventDefault(); this.dead = true; RN.glGrade = false; cv.style.display = 'none'; });
      const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
      const tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, tex);
      for (const [k, v] of [[gl.TEXTURE_MIN_FILTER, gl.LINEAR], [gl.TEXTURE_MAG_FILTER, gl.LINEAR], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]]) gl.texParameteri(gl.TEXTURE_2D, k, v);
      this.cv = cv; this.gl = gl; this.tex = tex; return true;
    } catch (e) { this.dead = true; return false; }
  },
  prog(Q) {
    if (this.progs[Q]) return this.progs[Q];
    const gl = this.gl, sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; };
    const p = gl.createProgram(); gl.attachShader(p, sh(gl.VERTEX_SHADER, this.VS)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, this.fs(Q))); gl.bindAttribLocation(p, 0, 'aP'); gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
    const u = {}; for (const n of ['uTex', 'uRes', 'uCam', 'uZ', 'uDpr', 'uTime', 'uDark', 'uGrade', 'uTint']) u[n] = gl.getUniformLocation(p, n);
    return (this.progs[Q] = { p, u });
  },
  post(S, now) {
    if (this.q === 'off' || this.dead || this.eff === 'off') { RN.glGrade = false; if (this.cv) this.cv.style.display = 'none'; return; }
    if (!this.gl && !this.init()) return;
    const src = RN.cv, gl = this.gl, W = src.width, H = src.height; if (!W || !H) return;
    // слабый телефон: временно снижаем уровень (настройка в меню не меняется)
    const dt = this.lastT ? Math.min(200, now - this.lastT) : 16; this.lastT = now; this.avg = this.avg * 0.97 + dt * 0.03;
    if (this.avg > 30 && now > this.cool) { if (this.eff === 'high') this.eff = 'med'; else if (this.eff === 'med') this.eff = 'low'; else if (this.eff === 'low' && this.avg > 40) this.eff = 'off'; this.cool = now + 6000; this.avg = 24; }   // слабый телефон: убираем эффекты ступенями, пока кадр не станет быстрым
    const P = this.prog(this.N[this.eff]);
    if (this.cv.width !== W || this.cv.height !== H) { this.cv.width = W; this.cv.height = H; }
    this.cv.style.display = 'block';
    let dark = 0; if (S) { const tn = todTint(todHours(S)); dark = Math.max(0, Math.min(1, (255 - tn[1]) / 150)); }
    gl.viewport(0, 0, W, H); gl.useProgram(P.p); gl.bindTexture(gl.TEXTURE_2D, this.tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
    gl.bindBuffer(gl.ARRAY_BUFFER, null); gl.enableVertexAttribArray(0);
    if (!this.vb) { this.vb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.vb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW); }
    gl.bindBuffer(gl.ARRAY_BUFFER, this.vb); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    const u = P.u, cam = RN.cam;
    gl.uniform1i(u.uTex, 0); gl.uniform2f(u.uRes, W, H); gl.uniform2f(u.uCam, cam.x, cam.y); gl.uniform1f(u.uZ, cam.z); gl.uniform1f(u.uDpr, RN.dpr || 1);
    gl.uniform1f(u.uTime, (now / 1000) % 7200); gl.uniform1f(u.uDark, dark);
    const tt = RN.tint || [1, 1, 1], gr = RN.glGrade ? 1 : 0; gl.uniform1f(u.uGrade, gr); gl.uniform3f(u.uTint, tt[0], tt[1], tt[2]);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    RN.glGrade = true;   // цветокоррекцию с этого кадра делает шейдер
  },
};
FX.load();
if (typeof frame === 'function') { const _frame0 = frame; frame = function (S, now) { _frame0(S, now); try { FX.post(S, now); } catch (e) { FX.dead = true; RN.glGrade = false; if (FX.cv) FX.cv.style.display = 'none'; } }; }
