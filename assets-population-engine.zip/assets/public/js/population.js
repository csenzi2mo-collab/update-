'use strict';
/* ===== POPULATION ENGINE (tahap 1) =====
   Penduduk individual yang benar-benar hidup di dunia. Setiap orang punya id, nama, umur, jenis kelamin,
   status hidup, pekerjaan, tempat tinggal, rumah tangga (keluarga), kesehatan, status sosial, dan hubungan.
   - Berjalan pada tick simulasi (POP_STEP), bukan per frame. Penduduk diproses bertahap (POP_SLICE per langkah).
   - Hanya memakai S.rnd() dan S.time, jadi deterministik dan aman untuk lockstep multiplayer.
   - Data disimpan di S.pop (ikut save). Game lama dimigrasi otomatis: penduduk dibuat saat tick pertama.
   - Sistem kerajaan (realm.js: keluarga raja, pejabat, suksesi) tidak diubah dan tetap berjalan. */

const POP_YEAR = DAY * 10;   // 1 tahun game (sama dengan RY di realm.js)
const POP_STEP = 8;          // tiap 8 tick (sekitar 2 detik game)
const POP_SLICE = 500;       // maksimal penduduk yang diproses per langkah (pemrosesan bertahap)

/* jumlah pekerja yang dibutuhkan tiap gedung, dan pekerjaan yang diisi di gedung itu */
const POP_NEED = { farm: 6, sawmill: 4, mine: 5, market: 3, port: 4, forge: 3, workshop: 3, stable: 3, hospital: 3, barracks: 4, siege: 3, academy: 3, firehouse: 3, wall: 2, tower: 2, gate: 1 };
const POP_JOB = { farm: 'Petani', sawmill: 'Penebang', mine: 'Penambang', market: 'Pedagang', port: 'Nelayan', forge: 'Pengrajin', workshop: 'Pengrajin', stable: 'Pengrajin', hospital: 'Tabib', barracks: 'Prajurit', siege: 'Pekerja konstruksi', academy: 'Juru tulis', firehouse: 'Pekerja konstruksi', wall: 'Pekerja konstruksi', tower: 'Prajurit', gate: 'Pekerja konstruksi' };

function popActive(S) { return !!(S.pop && S.pop.v === 1); }
/* pengali produksi gedung dari tenaga kerja (dipanggil dari calcRates). 0,5 jika tidak ada pekerja, 1 jika penuh. */
function popF(S, b) { const P = S.pop; if (!P) return 1; const v = P.sf[b.id]; return v === undefined ? 1 : 0.5 + 0.5 * v; }
/* kapasitas perumahan kota */
function popCap(c) { return c.level === 0 ? 30 + 18 * (c.vs | 0) : 60 * c.level + 40 + (c.isCap ? 80 : 0); }
/* faktor kerusuhan dari penduduk (kelaparan, kepadatan, pengangguran) */
function popUnrest(S, c) { const P = S.pop, st = P && P.C[c.id]; return st ? st.uf : 0; }
function popOwnerOf(S, cid) { const c = S.cities[cid]; return c ? c.owner : -2; }
let POP_BY = null;     // indeks penduduk per kota untuk langkah saat ini (tidak disimpan)
let POP_LIST = null;   // snapshot pemrosesan bertahap (tidak disimpan, agar save tidak menggandakan data)
let POP_LIST_P = null; // snapshot ini milik data penduduk yang mana: game baru tidak boleh memakai sisa game lama

/* ----- pembuatan data ----- */
function popEnsure(S) {
  if (S.pop && S.pop.v === 1) return S.pop;
  const P = S.pop = { v: 1, nid: 1, P: {}, H: {}, C: {}, sf: {}, grv: [], ci: 0, yr: Math.floor(S.time / POP_YEAR), cur: 0, tot: { b: 0, d: 0, mi: 0, mo: 0, ma: 0 } };
  for (const c of S.cities) popCity(S, P, c, true);
  return P;
}
function popCity(S, P, c, initial) {
  P.C[c.id] = { n: 0, b: 0, d: 0, mi: 0, mo: 0, ma: 0, sk: 0, ho: 0, mk: 0, th: 0, op: 0, un: 0, hu: 0, uf: 0 };
  const cap = popCap(c);
  popFound(S, P, c, initial ? Math.round(cap * (0.55 + 0.25 * S.rnd())) : 6);
  P.C[c.id].n = Object.values(P.P).filter(x => x.c === c.id).length;
}
function popSur(S) { const pk = a => a[(S.rnd() * a.length) | 0]; return pk(NM_ONSET) + pk(NM_END_L); }
function popName(S, jk) { const pk = a => a[(S.rnd() * a.length) | 0]; return pk(NM_ONSET) + (S.rnd() < 0.5 ? pk(NM_MID) : '') + pk(jk === 'P' ? NM_END_P : NM_END_L); }
function popHouse(S, P, c, sn, w) { const h = { id: P.nid++, sn, c: c.id, hd: 0, w, m: [] }; P.H[h.id] = h; return h; }
function popMk(S, P, o) {
  const id = P.nid++, p = { id, n: o.n, s: o.s, b: o.b, c: o.c, h: o.h, j: '', w: 0, k: o.k || 'rakyat', hp: o.hp === undefined ? 90 : o.hp, hu: o.hu === undefined ? 10 : o.hu, sp: 0, pa: o.pa || null, rl: [], ac: 'istirahat', at: S.time + S.rnd() * 30, ay: 0, sx: 30 };
  p.ay = Math.floor((S.time - p.b) / POP_YEAR); P.P[id] = p; return p;
}
/* keluarga awal: kepala keluarga, pasangan (kadang), anak, dan orang tua (kadang). Bangsawan hanya di ibu kota. */
function popFound(S, P, c, n) {
  let made = 0, guard = 0;
  while (made < n && guard++ < 999) {
    const noble = c.isCap && made < n * 0.3 && S.rnd() < 0.5;
    const hA = 18 + Math.floor(S.rnd() * 36), sex = S.rnd() < 0.5 ? 'L' : 'P', k = noble ? 'bangsawan' : 'rakyat';
    const h = popHouse(S, P, c, popSur(S), noble ? 260 + S.rnd() * 200 : 20 + S.rnd() * 40);
    const hd = popMk(S, P, { n: popName(S, sex), s: sex, b: S.time - (hA + S.rnd()) * POP_YEAR, c: c.id, h: h.id, k });
    h.hd = hd.id; h.m.push(hd.id); made++;
    let sp = null;
    if (S.rnd() < 0.75) {
      const os = sex === 'L' ? 'P' : 'L', ag = Math.max(18, Math.min(62, hA + Math.round(S.rnd() * 10 - 5)));
      sp = popMk(S, P, { n: popName(S, os), s: os, b: S.time - (ag + S.rnd()) * POP_YEAR, c: c.id, h: h.id, k });
      hd.sp = sp.id; sp.sp = hd.id; h.m.push(sp.id); made++;
    }
    const spId = sp ? sp.id : 0, pa = sex === 'L' ? [hd.id, spId] : [spId, hd.id];
    const nk = Math.floor(S.rnd() * 4);
    for (let i = 0; i < nk && made < n + 3; i++) {
      const ka = Math.floor(S.rnd() * Math.max(1, hA - 18)), ks = S.rnd() < 0.5 ? 'L' : 'P';
      const kid = popMk(S, P, { n: popName(S, ks), s: ks, b: S.time - (ka + S.rnd()) * POP_YEAR, c: c.id, h: h.id, k, pa });
      h.m.push(kid.id); made++;
    }
    if (S.rnd() < 0.2) {   // orang tua kepala keluarga ikut tinggal
      const es = S.rnd() < 0.5 ? 'L' : 'P';
      const el = popMk(S, P, { n: popName(S, es), s: es, b: S.time - (hA + 25 + S.rnd() * 15) * POP_YEAR, c: c.id, h: h.id, k });
      h.m.push(el.id); hd.pa = [el.id, 0]; made++;
    }
  }
}

/* ----- hubungan ----- */
function popLink(S, a, b, kind) {
  if (!a || !b || a.dead || b.dead || a.id === b.id) return;
  if (a.rl.some(x => x[0] === b.id) || a.rl.length >= 4 || b.rl.length >= 4) return;
  a.rl.push([b.id, kind]); b.rl.push([a.id, kind]);
}
function popKin(P, a, b) {
  if (a.pa && a.pa.includes(b.id)) return true;
  if (b.pa && b.pa.includes(a.id)) return true;
  return !!(a.pa && b.pa && a.pa.some(x => x && b.pa.includes(x)));
}
function popFixHead(S, P, h) {
  const mem = h.m.map(id => P.P[id]).filter(Boolean);
  if (!mem.length) return;
  if (P.P[h.hd] && mem.some(x => x.id === h.hd)) return;
  const adults = mem.filter(x => S.time - x.b >= 16 * POP_YEAR);
  const pool = adults.length ? adults : mem;
  pool.sort((a, b) => a.b - b.b || a.id - b.id);   // yang tertua menjadi kepala keluarga
  h.hd = pool[0].id;
}

/* ----- kematian dan pewarisan ----- */
function popDie(S, P, p, cause) {
  if (p.dead) return;
  p.dead = 1; delete P.P[p.id];
  if (p.sp && P.P[p.sp]) P.P[p.sp].sp = 0;
  for (const x of p.rl) { const q = P.P[x[0]]; if (q) q.rl = q.rl.filter(y => y[0] !== p.id); }
  const h = P.H[p.h];
  if (h) {
    h.m = h.m.filter(x => x !== p.id);
    if (!h.m.length) delete P.H[h.id];
    else {
      if (h.hd === p.id) popFixHead(S, P, h);
      // anak yatim tanpa orang dewasa diasuh oleh keluarga lain di kota yang sama
      const adult = h.m.some(id => P.P[id] && S.time - P.P[id].b >= 16 * POP_YEAR);
      if (!adult) {
        const other = Object.values(P.H).find(o => o !== h && o.c === h.c && o.m.some(id => P.P[id] && S.time - P.P[id].b >= 18 * POP_YEAR));
        if (other) { for (const id of h.m) { const q = P.P[id]; if (q) { q.h = other.id; other.m.push(id); } } h.m = []; delete P.H[h.id]; }
      }
    }
  }
  const st = P.C[p.c]; if (st) { st.n--; st.d++; }
  P.tot.d++;
  P.grv.unshift({ n: p.n + (h ? ' ' + h.sn : ''), a: Math.floor((S.time - p.b) / POP_YEAR), c: cause, t: S.time, city: p.c });
  if (P.grv.length > 40) P.grv.pop();
}
function popMort(S, P, p, owner, C) {
  const a = (S.time - p.b) / POP_YEAR;
  let q = a < 5 ? 0.02 : a < 45 ? 0.003 : a < 60 ? 0.008 : 0.03 + (a - 60) * 0.012;
  q *= 1 + (100 - p.hp) / 60;
  if (p.hu > 70) q *= 1.6;
  if (C && C.sk > S.time) q *= 2.2;                       // wabah
  if (owner >= 0) q *= govDeathMult(S, owner);            // dokter (sistem gx yang sudah ada)
  return Math.min(0.6, q);
}

/* ----- kelahiran dan perkawinan ----- */
function popBirth(S, P, mom, dad, h) {
  const sex = S.rnd() < 0.5 ? 'L' : 'P';
  const kid = popMk(S, P, { n: popName(S, sex), s: sex, b: S.time, c: mom.c, h: h.id, k: mom.k, pa: [dad.id, mom.id], hp: 95, hu: 5 });
  h.m.push(kid.id);
  const st = P.C[mom.c]; if (st) { st.n++; st.b++; }
  P.tot.b++;
}
function popWed(S, P, f, m) {
  const fh = P.H[f.h], mh = P.H[m.h];
  f.sp = m.id; m.sp = f.id;
  if (fh) fh.m = fh.m.filter(x => x !== f.id);
  if (mh) { f.h = mh.id; mh.m.push(f.id); }
  if (fh && !fh.m.length) delete P.H[fh.id]; else if (fh) popFixHead(S, P, fh);
  const st = P.C[m.c]; if (st) st.ma++;
  P.tot.ma++;
}
function popMarry(S, P, list) {
  const t = S.time, fem = [], mal = [];
  for (const p of list) {
    if (p.dead || p.sp) continue;
    const a = (t - p.b) / POP_YEAR; if (a < 18 || a > 44) continue;
    (p.s === 'P' ? fem : mal).push(p);
  }
  if (!fem.length || !mal.length) return;
  const tries = Math.min(fem.length, 24);
  for (let i = 0; i < tries && mal.length; i++) {
    const f = fem[(S.rnd() * fem.length) | 0]; if (f.dead || f.sp) continue;
    const af = (t - f.b) / POP_YEAR;
    for (let k = 0; k < 6; k++) {
      const mi = (S.rnd() * mal.length) | 0, m = mal[mi];
      if (m.dead || m.sp || m.h === f.h) continue;
      if (Math.abs((t - m.b) / POP_YEAR - af) > 9) continue;
      if (popKin(P, f, m)) continue;
      if ((f.k === 'bangsawan') !== (m.k === 'bangsawan')) continue;
      if (S.rnd() < 0.5) { popWed(S, P, f, m); mal.splice(mi, 1); break; }
    }
  }
}

/* ----- pekerjaan, tenaga kerja, dan kepegawaian ----- */
function popJobs(S, P, byC) {
  const slots = {};
  for (const c of S.cities) slots[c.id] = [];
  for (const b of S.buildings) {
    if (b.owner < 0 || b.cons > 0 || !POP_NEED[b.type]) continue;
    let best = null, bd = 11;
    for (const c of S.cities) { if (c.owner !== b.owner) continue; const d = dist(b.x + 0.5, b.y + 0.5, c.x + 1, c.y + 1); if (d < bd) { bd = d; best = c; } }
    if (best) slots[best.id].push(b);
  }
  const sf = {};
  for (const c of S.cities) {
    const st = P.C[c.id], ppl = byC[c.id] || [], bl = slots[c.id];
    st.mk = bl.some(b => b.type === 'market') ? 1 : 0;
    const valid = {}; for (const b of bl) valid[b.id] = b;
    for (const p of ppl) if (p.w && !valid[p.w]) { p.w = 0; p.j = ''; }   // gedung hilang / berpindah tangan
    const yrs = x => (S.time - x.b) / POP_YEAR;
    // pejabat dan pendeta: satu kota memiliki sedikit pejabat dari kalangan kaya dan pendeta
    const pej = ppl.filter(p => p.j === 'Pejabat').length, wantP = c.level >= 3 ? 2 : c.level >= 1 ? 1 : 0;
    if (pej < wantP) { const cs = ppl.filter(p => !p.j && yrs(p) >= 30 && yrs(p) < 60 && (p.k === 'bangsawan' || (P.H[p.h] && P.H[p.h].w >= 80))); if (cs.length) cs[(S.rnd() * cs.length) | 0].j = 'Pejabat'; }
    if (!ppl.some(p => p.j === 'Pendeta') && ppl.length >= 30) { const cs = ppl.filter(p => !p.j && yrs(p) >= 25 && yrs(p) < 60); if (cs.length) cs[(S.rnd() * cs.length) | 0].j = 'Pendeta'; }
    // kandidat kerja: dewasa tanpa pekerjaan (bukan bangsawan)
    const cand = ppl.filter(p => !p.j && !p.w && p.k !== 'bangsawan' && yrs(p) >= 16 && yrs(p) < 60);
    const cnt = {}, hcnt = {};
    for (const p of ppl) if (p.w) { cnt[p.w] = (cnt[p.w] || 0) + 1; if (p.hp >= 30) hcnt[p.w] = (hcnt[p.w] || 0) + 1; }
    for (const b of bl) {
      let have = cnt[b.id] || 0; const need = POP_NEED[b.type];
      while (have < need && cand.length) {
        const p = cand.splice((S.rnd() * cand.length) | 0, 1)[0];
        p.w = b.id; p.j = POP_JOB[b.type]; have++; cnt[b.id] = have; if (p.hp >= 30) hcnt[b.id] = (hcnt[b.id] || 0) + 1;
        if (cand.length && S.rnd() < 0.25) popLink(S, p, cand[(S.rnd() * cand.length) | 0], 'r');   // bersaing merebut lowongan
      }
      sf[b.id] = Math.min(1, (hcnt[b.id] || 0) / need);
    }
    let op = 0; for (const b of bl) op += Math.max(0, POP_NEED[b.type] - (cnt[b.id] || 0));
    st.op = op; st.un = cand.length;
  }
  P.sf = sf;
}

/* ----- aktivitas: kebutuhan dan kondisi dunia menentukan tindakan ----- */
function popAct(S, P, p, owner, C, avail) {
  const h = todHours(S), age = (S.time - p.b) / POP_YEAR;
  let ac, dur = 14 + S.rnd() * 20;
  if (owner >= 0 && p.hu >= 35) { ac = avail[owner] >= 0.002 ? 'makan' : 'mencari makanan'; dur = 6; }
  else if (h < 6 || h >= 22) { ac = 'istirahat'; dur = 30; }
  else if (age < 12) ac = 'bermain';
  else if (p.j && (p.w || p.j === 'Pejabat' || p.j === 'Pendeta') && h >= 7 && h < 18) ac = 'bekerja';
  else if (!p.j && age >= 16 && age < 65 && h >= 7 && h < 18) ac = 'mencari kerja';
  else if (C.mk && ((h >= 10 && h < 12) || (h >= 16 && h < 18))) ac = 'pasar';
  else if (h >= 18 && h < 22) ac = S.rnd() < 0.5 ? 'bersosialisasi' : 'mengurus keluarga';
  else ac = 'istirahat';
  p.ac = ac; p.at = S.time + dur;
}

/* ----- satu orang per langkah: lapar, makan, kesehatan, aktivitas, peristiwa tahunan ----- */
function popPerson(S, P, p, dt, avail) {
  const t = S.time, owner = popOwnerOf(S, p.c), C = P.C[p.c] || { sk: 0, ho: 0, th: 0, mk: 0 };
  const age = (t - p.b) / POP_YEAR, child = age < 16;
  p.hu = Math.min(100, p.hu + (child ? 0.12 : 0.25) * dt);
  if (owner < 0) p.hu = 0;                                  // kota bebas: tidak masuk ekonomi pemain
  else if (p.hu >= 35) {                                    // makan dari kas pangan pemilik kota
    const eat = Math.min(2 * dt, p.hu), cost = eat * 0.0016;
    if (avail[owner] >= cost) { avail[owner] -= cost; p.hu -= eat; }
  }
  if (owner >= 0) { if (p.hu > 90) p.hp -= 0.12 * dt; else if (p.hu > 70) p.hp -= 0.05 * dt; else if (p.hu < 40) p.hp += 0.02 * dt; }
  if (C.ho) p.hp += 0.12 * dt;                              // rumah sakit terdekat
  if (C.sk > t && (age < 12 || age > 55)) p.hp -= 0.02 * dt; // wabah
  if (C.th > 0) p.hp -= 0.02 * dt * Math.min(3, C.th);      // perang di kota
  if (p.ac === 'istirahat') p.hp += 0.01 * dt;
  p.hp = Math.max(0, Math.min(100, p.hp));
  if (p.hp <= 0) { popDie(S, P, p, p.hu > 70 ? 'kelaparan' : C.th > 0 ? 'korban peperangan' : C.sk > t ? 'wabah' : 'sakit'); return; }
  if (t >= p.at) popAct(S, P, p, owner, C, avail);
  const h = P.H[p.h];
  if (p.ac === 'bekerja' && h) h.w = Math.min(5000, h.w + 0.012 * dt);
  if ((p.ac === 'bersosialisasi' || p.ac === 'pasar') && POP_BY && S.rnd() < 0.03 * dt) {
    const L = POP_BY[p.c]; if (L && L.length > 1) popLink(S, p, L[(S.rnd() * L.length) | 0], 'f');
  }
  const yi = Math.floor(age);
  if (yi > p.ay) { p.ay = yi; popYearly(S, P, p, yi, owner, C, avail); }
}
/* penyebab kematian diambil dari faktor yang benar-benar aktif */
function popCauseY(S, p, yi, C) {
  if (p.hu > 70) return 'kelaparan';
  if (C && C.sk > S.time && (yi < 12 || yi > 55)) return 'wabah';
  if (C && C.th > 0) return 'korban peperangan';
  if (p.hp < 40) return 'sakit';
  return yi >= 60 ? 'usia lanjut' : 'sakit';
}
function popYearly(S, P, p, yi, owner, C) {
  const q = popMort(S, P, p, owner, C);
  if (S.rnd() < q) { popDie(S, P, p, popCauseY(S, p, yi, C)); return; }
  const h = P.H[p.h];
  if (yi === 18 && !p.sp && h && h.hd !== p.id && h.m.length > 2 && S.rnd() < 0.35) popSplit(S, P, p, h);   // dewasa mendirikan rumah sendiri
  if (p.j && p.w && S.rnd() < 0.06) { p.w = 0; p.j = ''; }   // berpindah pekerjaan: keluar dan mencari lowongan baru
  if (p.s === 'P' && p.sp && yi >= 18 && yi <= 40) {
    const sp = P.P[p.sp], hh = P.H[p.h], city = S.cities[p.c];
    if (sp && !sp.dead && hh && hh.m.length < 12 && city) {
      const room = (P.C[p.c] ? P.C[p.c].n : 0) < popCap(city);
      const fert = 0.4 * (p.hp / 100) * (sp.hp / 100) * (p.hu < 50 && sp.hu < 50 ? 1 : 0.2) * (room ? 1 : 0.1);
      if (S.rnd() < fert) popBirth(S, P, p, sp, hh);
    }
  }
  if (h) { h.w = Math.max(0, h.w - 1.5); p.sx = Math.round(Math.max(0, Math.min(100, 15 + h.w / 8 + (p.k === 'bangsawan' ? 45 : 0) + (p.j === 'Pejabat' ? 20 : 0)))); }
  p.rl = p.rl.filter(x => P.P[x[0]]);
}
function popSplit(S, P, p, h) {
  const city = S.cities[p.c]; if (!city) return;
  h.m = h.m.filter(x => x !== p.id);
  const nh = popHouse(S, P, city, popSur(S), Math.min(60, h.w * 0.2));
  h.w = Math.max(0, h.w - nh.w);
  nh.hd = p.id; nh.m.push(p.id); p.h = nh.id;
  if (h.m.length) popFixHead(S, P, h);
}

/* ----- migrasi: keluarga pergi dari tempat tidak aman, pekerja tertarik ke lowongan ----- */
function popPickCity(S, P, from, size) {
  let best = null, bs = -1e9;
  const fi = from.y * S.W + from.x;
  for (const t of S.cities) {
    if (t === from || t.owner < 0) continue;
    if (S.comp[t.y * S.W + t.x] !== S.comp[fi]) continue;
    if (from.owner !== t.owner && atWar(S, from.owner, t.owner)) continue;
    const ts = P.C[t.id]; if (!ts || ts.th > 0) continue;
    const free = popCap(t) - ts.n; if (free < size) continue;
    const sc = Math.min(3, ts.op) * 0.6 + free * 0.02 + (t.unrest < 40 ? 0.4 : 0) - (ts.sk > S.time ? 1 : 0) - dist(from.x, from.y, t.x, t.y) * 0.02;
    if (sc > bs) { bs = sc; best = t; }
  }
  return best;
}
function popMoveHouse(S, P, h, from, dst) {
  const n = h.m.length, t = S.time;
  for (const id of h.m) { const p = P.P[id]; if (p) { p.c = dst.id; if (p.w) { p.w = 0; p.j = ''; } p.ac = 'pindah'; p.at = t + 20; } }
  h.c = dst.id; h.mv = t;
  const a = P.C[from.id], b = P.C[dst.id];
  if (a) { a.n -= n; a.mo += n; } if (b) { b.n += n; b.mi += n; }
  P.tot.mi += n; P.tot.mo += n;
}
function popDrawWorker(S, P, dst, all) {
  for (let k = 0; k < 30 && all.length; k++) {
    const p = all[(S.rnd() * all.length) | 0];
    if (!p || p.dead || p.c === dst.id || p.w || p.j || p.sp) continue;
    if (p.mv !== undefined && S.time - p.mv < POP_YEAR) continue;
    const a = (S.time - p.b) / POP_YEAR; if (a < 16 || a > 45) continue;
    const src = S.cities[p.c]; if (!src || src.owner < 0) continue;
    if (S.comp[src.y * S.W + src.x] !== S.comp[dst.y * S.W + dst.x]) continue;
    if (src.owner !== dst.owner && atWar(S, src.owner, dst.owner)) continue;
    const h = P.H[p.h];
    if (h && h.m.some(id => { const q = P.P[id]; return q && q !== p && S.time - q.b < 16 * POP_YEAR; })) continue;   // jangan pisahkan anak
    if (h) { h.m = h.m.filter(x => x !== p.id); if (!h.m.length) delete P.H[h.id]; else if (h.hd === p.id) popFixHead(S, P, h); }
    const nh = popHouse(S, P, dst, popSur(S), 5); nh.hd = p.id; nh.m.push(p.id); p.h = nh.id;
    if (p.sp && P.P[p.sp]) { P.P[p.sp].sp = 0; p.sp = 0; }
    popMoveHouse(S, P, { m: [p.id], c: p.c, h: nh.id }, src, dst);
    p.mv = S.time; nh.mv = S.time;
    return true;
  }
  return false;
}
/* keluarga yang belum punya pekerjaan pindah utuh ke kota yang punya lowongan */
function popDrawHouse(S, P, dst) {
  const t = S.time, free = popCap(dst) - P.C[dst.id].n, cands = [];
  for (const h of Object.values(P.H)) {
    if (h.c === dst.id || !h.m.length || h.m.length > Math.min(5, free)) continue;
    if (h.mv !== undefined && t - h.mv < POP_YEAR) continue;   // cooldown: tidak pindah lagi dalam setahun
    const mem = h.m.map(id => P.P[id]).filter(Boolean);
    if (mem.some(q => q.w || q.j === 'Pejabat' || q.j === 'Pendeta')) continue;   // keluarga yang sudah bekerja tidak pindah
    if (!mem.some(q => { const a = (t - q.b) / POP_YEAR; return a >= 16 && a < 60; })) continue;
    const src = S.cities[h.c]; if (!src || src.owner < 0) continue;
    if (S.comp[src.y * S.W + src.x] !== S.comp[dst.y * S.W + dst.x]) continue;
    if (src.owner !== dst.owner && atWar(S, src.owner, dst.owner)) continue;
    cands.push({ h, src }); if (cands.length >= 12) break;
  }
  if (!cands.length) return false;
  const pick = cands[(S.rnd() * cands.length) | 0];
  popMoveHouse(S, P, pick.h, pick.src, dst);
  return true;
}
function popMigrate(S, P, all) {
  const cs = S.cities; if (cs.length < 2) return;
  const c = cs[P.ci % cs.length]; P.ci = (P.ci + 1) % cs.length;
  if (c.owner < 0) return;
  const st = P.C[c.id], cap = popCap(c), t = S.time, pl = S.players[c.owner];
  if (!st || !pl) return;
  let push = 0;
  if (st.th > 0) push += 0.8;                                  // wilayah tidak aman
  if (pl.stock.food < 15) push += 0.3;                         // kelaparan
  if (st.sk > t) push += 0.2;                                  // wabah
  if (st.n > cap) push += 0.3 + Math.min(0.6, (st.n - cap) / cap);   // kepadatan
  if ((c.unrest || 0) >= 60) push += 0.3;                      // kerusuhan
  if (push >= 0.5 && S.rnd() < push) {
    const hs = Object.values(P.H).filter(h => h.c === c.id);
    if (hs.length) {
      const h = hs[(S.rnd() * hs.length) | 0], dst = popPickCity(S, P, c, h.m.length);
      if (dst) popMoveHouse(S, P, h, c, dst);
    }
  }
  if (st.op >= 2 && cap - st.n >= 2 && S.rnd() < 0.3) { if (!popDrawHouse(S, P, c)) popDrawWorker(S, P, c, all); }   // tertarik ke peluang kerja
}

/* ----- peristiwa per kota: perang, wabah, rumah sakit, faktor kerusuhan ----- */
function popOutbreak(S, c) {
  const P = S.pop; if (!P) return; const st = P.C[c.id]; if (!st) return;
  st.sk = S.time + DAY * 4;
  for (const p of Object.values(P.P)) if (p.c === c.id && (((S.time - p.b) / POP_YEAR) < 12 || ((S.time - p.b) / POP_YEAR) > 55) && S.rnd() < 0.12) p.hp -= 35;
}
function popWarCasualty(S, P, c, byC) {
  const L = byC[c.id] || []; if (!L.length) return;
  const sol = L.filter(p => p.j === 'Prajurit'), pool = sol.length && S.rnd() < 0.6 ? sol : L.filter(p => (S.time - p.b) / POP_YEAR >= 16);
  if (!pool.length) return;
  popDie(S, P, pool[(S.rnd() * pool.length) | 0], 'korban peperangan');
}
function popCityCounts(S, P, byC) {
  const threat = {}, hosp = {};
  for (const a of S.armies) {
    if (a.ship) continue;
    for (const c of S.cities) if (dist(a.x, a.y, c.x + 1, c.y + 1) <= 2.6 && a.owner !== c.owner && atWar(S, a.owner, c.owner)) threat[c.id] = (threat[c.id] || 0) + 1;
  }
  for (const b of S.buildings) {
    if (b.type !== 'hospital' || b.owner < 0 || b.cons > 0) continue;
    let best = null, bd = 9; for (const c of S.cities) { if (c.owner !== b.owner) continue; const d = dist(b.x + 0.5, b.y + 0.5, c.x + 1, c.y + 1); if (d < bd) { bd = d; best = c; } }
    if (best) hosp[best.id] = 1;
  }
  for (const c of S.cities) {
    const st = P.C[c.id]; if (!st) continue;
    const L = byC[c.id] || []; st.n = L.length; st.th = threat[c.id] || 0; st.ho = hosp[c.id] ? 1 : 0;
    let hungry = 0; for (const p of L) if (p.hu > 60) hungry++;
    st.hu = hungry;
    const cap = popCap(c), over = st.n > cap ? Math.min(8, (st.n - cap) / cap * 20) : 0;
    const starve = st.n ? (hungry / st.n) * 25 : 0, idle = st.n && st.un > st.n * 0.5 ? 4 : 0;
    st.uf = Math.round(Math.min(18, starve) + over + idle);
  }
}
function popSummary(S, P) {
  const yr = P.yr;
  for (const p of S.players) {
    if (!p.human || !p.alive) continue;
    const mine = S.cities.filter(c => c.owner === p.id), sum = k => mine.reduce((a, c) => a + (P.C[c.id] ? P.C[c.id][k] : 0), 0);
    const n = sum('n'), b = sum('b'), d = sum('d'), mi = sum('mi'), mo = sum('mo'), op = sum('op'), un = sum('un');
    if (!mine.length) continue;
    addMsg(S, p.id, { type: 'life', title: gxl('Population report · year ', 'Laporan penduduk · tahun ') + yr, text: gxl('Population ', 'Penduduk ') + n + gxl(' · born ', ' · lahir ') + b + gxl(' · died ', ' · wafat ') + d + gxl(' · moved in ', ' · pendatang ') + mi + gxl(' · moved out ', ' · pindah keluar ') + mo + gxl(' · open jobs ', ' · lowongan ') + op + gxl(' · unemployed ', ' · pengangguran ') + un });
  }
}
function popAnnual(S, P, byC) {
  for (const c of S.cities) { const L = byC[c.id]; if (L && L.length > 1) popMarry(S, P, L); }
  popSummary(S, P);
  for (const c of S.cities) { const st = P.C[c.id]; if (st) st.b = st.d = st.mi = st.mo = 0; }
}

/* ----- langkah utama (dipanggil dari tick) ----- */
function popStep(S, dt) {
  const P = popEnsure(S), t = S.time;
  for (const c of S.cities) if (!P.C[c.id]) popCity(S, P, c, false);
  const all = Object.values(P.P), byC = {};
  for (const c of S.cities) byC[c.id] = [];
  for (const p of all) { const L = byC[p.c]; if (L) L.push(p); }
  popJobs(S, P, byC);
  popCityCounts(S, P, byC);
  POP_BY = byC;
  const avail = {}; for (const p of S.players) avail[p.id] = p.stock.food;
  // pemrosesan bertahap: setiap orang diperbarui sekali per siklus, dengan dt dikalikan panjang siklus
  if (POP_LIST_P !== P || !POP_LIST || P.cur >= POP_LIST.length) { POP_LIST = all; POP_LIST_P = P; P.cur = 0; }
  const kk = Math.max(1, Math.ceil(POP_LIST.length / POP_SLICE));
  const from = P.cur, to = Math.min(POP_LIST.length, from + POP_SLICE); P.cur = to;
  for (let i = from; i < to; i++) { const p = POP_LIST[i]; if (p && !p.dead) popPerson(S, P, p, dt * kk, avail); }
  for (const p of S.players) if (avail[p.id] !== p.stock.food) p.stock.food = Math.max(0, avail[p.id]);
  for (const c of S.cities) { const st = P.C[c.id]; if (st && st.th > 0 && S.rnd() < 0.03 * dt * Math.min(3, st.th)) popWarCasualty(S, P, c, byC); }
  const yr = Math.floor(t / POP_YEAR);
  if (yr > P.yr) { P.yr = yr; popAnnual(S, P, byC); }
  popMigrate(S, P, all);
  POP_BY = null;
}

/* ----- pengait ke sistem yang sudah ada (tidak menggantikan kode lama) ----- */
/* 1. kerusuhan: penduduk yang lapar, padat, atau menganggur menambah kerusuhan kota */
(function () {
  const _uf = unrestFactors;
  unrestFactors = function (S, c, p) { const f = _uf(S, c, p); if (S.pop) { const v = popUnrest(S, c); f.p = v; f.sum += v; } return f; };
})();
/* 2. wabah dari peristiwa 'plague' yang sudah ada menjangkiti penduduk kota itu */
(function () {
  const _pe = pushEvent;
  pushEvent = function (S, p, id, ctx) { try { if (id === 'plague' && S.pop && ctx && ctx.city) popOutbreak(S, ctx.city); } catch (e) { console.error(e); } return _pe.apply(this, arguments); };
})();
/* 3. tick: setelah langkah sistem lama, jalankan Population Engine tiap POP_STEP tick (bukan tiap frame) */
(function () {
  const _t = tick;
  tick = function (S, dt) {
    const r = _t(S, dt);
    if (!S.over && !S.tut && S.tk % POP_STEP === 0) { try { popStep(S, dt * POP_STEP); } catch (e) { console.error('population:', e); } }
    return r;
  };
})();

/* ----- tampilan singkat untuk lembar kota ----- */
function popSheetRow(S, c) {
  const P = S.pop, st = P && P.C[c.id]; if (!st) return '';
  return `<div class="row">${gxl('Population', 'Penduduk')}: <b>${st.n}</b> / ${popCap(c)} · ${gxl('open jobs', 'lowongan')}: ${st.op} · ${gxl('unemployed', 'pengangguran')}: ${st.un}</div>`;
}
