'use strict';
/* ===== Боты ===== */
function aiRingSet(p) { const o = {}, w = p.ai.walls; if (w) for (const k in w) for (const t of w[k].t) o[t[1] + ',' + t[2]] = 1; return o; }
function aiSeaBig(S, p, x, y) {   // порт нужен у настоящего моря, а не у крошечного озера
  const ai = p.ai; if (!ai.cc) { ai.cc = {}; for (let i = 0; i < S.comp.length; i++) if (isWater(S.ter[i])) ai.cc[S.comp[i]] = (ai.cc[S.comp[i]] || 0) + 1; }
  const w = nearestTile(S, x, y, true, 3); return !!w && (ai.cc[S.comp[w.y * S.W + w.x]] || 0) >= 60;
}
function aiFindSite(S, p, type) {
  const cands = [], ring = type === 'wall' || type === 'tower' || type === 'gate' ? {} : aiRingSet(p);
  for (const c of S.cities) if (c.owner === p.id) {
    const cx = c.x + 1, cy = c.y + 1, r = Math.floor(c.radius) + (type === 'port' ? 3 : 0);
    const hasPort = type === 'port' && S.buildings.some(b => b.owner === p.id && b.type === 'port' && dist(b.x, b.y, cx, cy) < 9);
    for (let y = Math.max(0, cy - r); y <= Math.min(S.H - 1, cy + r); y++) for (let x = Math.max(0, cx - r); x <= Math.min(S.W - 1, cx + r); x++) {
      if (ring[x + ',' + y]) continue; if (siteOk(S, p.id, type, x, y)) continue; const d = dist(x, y, cx, cy);
      if (type === 'port') { if (!aiSeaBig(S, p, x, y)) continue; cands.push({ x, y, d: d + (hasPort ? 12 : 0) }); }
      else if (d >= 2) cands.push({ x, y, d });
    }
  }
  if (!cands.length) return null;
  cands.sort((a, b) => a.d - b.d); const k = Math.min(cands.length, 6);
  return cands[(S.rnd() * k) | 0];
}
function aiCount(S, pid, type) { let n = 0; for (const b of S.buildings) if (b.owner === pid && b.type === type) n++; return n; }
function aiSquadStats(S, pid) {
  const cnt = { archer: 0, light: 0, heavy: 0, cav: 0 };
  for (const a of S.armies) if (a.owner === pid) for (const q of a.sq) if (cnt[q.t] !== undefined) cnt[q.t]++;
  for (const b of S.buildings) if (b.owner === pid && b.type === 'barracks') for (const q of b.queue) if (cnt[q.t] !== undefined) cnt[q.t]++;
  return cnt;
}
function aiThink(S, p) {
  const ai = p.ai; if (S.time < ai.next) return; ai.next = S.time + DIFF[p.diff].think * (0.8 + S.rnd() * 0.4);
  const mine = S.cities.filter(c => c.owner === p.id); if (!mine.length) return; const nc = mine.length;
  // --- строительство
  const lv = AI_LV[p.diff] || AI_LV.normal, rt = p.rate || { food: 1 }, st0 = p.stock, need0 = [];
  if (rt.food < 0.15 && aiCount(S, p.id, 'farm') < 4 + nc * 3) need0.push(['farm', 999]);
  if (st0.wood < 90 && aiCount(S, p.id, 'sawmill') < 3 + nc * 2) need0.push(['sawmill', 999]);
  if (st0.iron < 40 && S.time > 200 && aiCount(S, p.id, 'mine') < 3 + nc) need0.push(['mine', 999]);
  const plan = need0.concat([['farm', 2], ['sawmill', 2], ['mine', 2], ['barracks', 1], ['hospital', 1], ['workshop', 1], ['forge', 1], ['farm', 3], ['stable', 1], ['sawmill', 3], ['market', 1], ['academy', p.diff === 'easy' ? 0 : 1], ['mine', 3],
    ['barracks', 2], ['siege', p.diff === 'easy' ? 0 : 1], ['hospital', 1 + Math.floor(nc / 3)], ['forge', 2], ['farm', 3 + nc * 2], ['workshop', 2], ['stable', 2], ['sawmill', 3 + nc * 2], ['mine', 3 + nc], ['market', 1 + nc]]);
  // стены и порты — по расписанию; если на них не хватает золота, 2 хода из 3 копим (армию и прочую стройку не тратим)
  ai.n = (ai.n || 0) + 1;
  const pr = aiPorts(S, p, lv), wr = aiWalls(S, p, mine, lv), goalBuilt = pr === 'built' || wr === 'built';
  const navalWait = !!ai.wantWar && aiCount(S, p.id, 'port') > 0 && !S.ships.some(q => q.owner === p.id && q.kind === 'war');
  const saving = !goalBuilt && (pr === 'wait' || wr === 'wait' || navalWait) && ai.n % 3 !== 0;
  let built = goalBuilt;
  for (const [type, n] of (goalBuilt ? [] : saving ? need0 : plan)) {
    if (aiCount(S, p.id, type) >= n) continue;
    if ((ai.fails[type] || 0) > 4) continue;
    if (!canAfford(p, BD[type].cost)) break;
    const site = aiFindSite(S, p, type);
    if (!site) { ai.fails[type] = (ai.fails[type] || 0) + 1; continue; }
    doBuild(S, p.id, type, site.x, site.y); built = true; break;
  }

  // новая деревня: выбираем место, где можно занять больше свободной земли
  if (p.autoVillage !== false && nc < 2 + Math.floor(S.time / 300) && nc < 14 && canAfford(p, villageCost(S, p.id)) && p.stock.gold > villageCost(S, p.id).gold + 100 && S.time > 120) {
    let best = null, bs = -1;
    for (let k = 0; k < 70; k++) { const c = mine[(S.rnd() * mine.length) | 0], a = S.rnd() * 6.283, r = CITY_MIN + 1 + S.rnd() * 6, x = Math.round(c.x + 1 + Math.cos(a) * r - 1), y = Math.round(c.y + 1 + Math.sin(a) * r - 1); if (cityOk(S, p.id, x, y)) continue; const cl = cityClaim(S, p.id, x, y), sc = cl.free * 2 + cl.land - cl.forest * 0.5; if (sc > bs) { bs = sc; best = { x, y }; } }
    if (best && bs > 18) doBuild(S, p.id, 'village', best.x, best.y);
  }
  // деревни растут в города, города — в уровни (сначала самые маленькие)
  for (const c of mine.slice().sort((a, b) => a.level - b.level)) if (c.level < 3 + (p.diff === 'hard' ? 2 : 0) && p.stock.gold > upgradeCost(c).gold + 200 && canAfford(p, upgradeCost(c))) { upgradeCity(S, c); break; }
  // --- рецепты
  const tgt = { sword: 20, armL: 15, armH: 12 };
  for (const b of S.buildings) if (b.owner === p.id && b.type === 'forge') { let best = b.recipe, bd = -99; for (const k in tgt) { const d = tgt[k] - p.stock[k]; if (d > bd) { bd = d; best = k; } } if (!b.busy) b.recipe = best; }
  // --- обучение
  const st = aiSquadStats(S, p.id), totSq = st.archer + st.light + st.heavy + st.cav, want = { archer: 3, light: 2.5, heavy: 2, cav: 2.5 };
  for (const b of S.buildings) if (!saving && p.autoMil !== false && b.owner === p.id && b.type === 'barracks' && b.queue.length < 2 && totSq + b.queue.length < 6 + 5 * nc) {
    const ord = Object.keys(want).sort((a, c) => st[a] / want[a] - st[c] / want[c]);
    for (const t of ord) { if (enqueue(S, b, t) === null) { st[t]++; break; } }
  }
  for (const b of S.buildings) if (p.autoMil !== false && b.owner === p.id && b.type === 'siege' && b.queue.length < 1) { let nr = 0, nc2 = 0; for (const a of S.armies) if (a.owner === p.id) for (const q of a.sq) { if (q.t === 'ram') nr++; if (q.t === 'cat') nc2++; } if (nr + nc2 < 2 + nc) enqueue(S, b, nr <= nc2 ? 'ram' : 'cat'); }
  for (const b of S.buildings) if (b.owner === p.id && b.type === 'academy' && !b.queue.length && !hasCommander(S, p.id)) { const cn = { archer: 0, light: 0, heavy: 0, cav: 0 }; for (const a of S.armies) if (a.owner === p.id) for (const q of a.sq) if (cn[q.t] !== undefined) cn[q.t] += q.u; const cls = Object.keys(cn).sort((x, y) => cn[y] - cn[x])[0]; if (cn[cls] >= 10) enqueueCmd(S, b, cls); }
  // --- армии
  if (p.autoMil !== false) aiArmies(S, p, mine);
  // --- дипломатия
  if (S.tk % 40 === 0) aiDiplomacy(S, p);
  // --- порты, торговый и военный флот, морские десанты
  aiNavy(S, p, mine, lv);
}
function aiDiplomacy(S, p) {
  const cch = { easy: 0.03, normal: 0.06, hard: 0.12 }[p.diff];
  for (const q of S.players) {
    if (q.id === p.id || !q.alive) continue; const r = rel(S, p.id, q.id);
    if (r.st === 'peace' && r.trade && !r.ally && r.op > 15 && S.rnd() < 0.05) offer(S, p.id, q.id, 'ally');
    if (!p.peaceful && r.st === 'peace' && !r.ally && S.time > 150 && !claimInfo(S, p.id, q.id) && S.rnd() < cch && milPower(S, q.id) < milPower(S, p.id) * 1.1 && !S.players.some(z => z.id !== p.id && z.alive && rel(S, p.id, z.id).st === 'war' && z.id !== q.id)) startClaim(S, p.id, q.id);
    if (p.autoTrade !== false && r.st === 'peace' && !r.trade && S.rnd() < 0.1 && r.op > -20) offer(S, p.id, q.id, 'trade');
    if (r.st === 'war' && S.time - r.warSince > 120 && milPower(S, p.id) < milPower(S, q.id) * 0.7 && S.rnd() < 0.5) offer(S, p.id, q.id, 'truce');
  }
}
function aiArmies(S, p, mine) {
  const my = S.armies.filter(a => a.owner === p.id && !a.ship); if (!my.length) return;
  const cap = mine[0], hx = cap.x + 1, hy = cap.y + 1;
  my.sort((a, b) => units(b) - units(a)); const main = my[0];
  const need = { easy: 5, normal: 4, hard: 3 }[p.diff], start = { easy: 420, normal: 300, hard: 200 }[p.diff];
  if (p.milJobs) { aiLead(S, p, main, hx, hy, need, start); return; }   // pasukan lain punya pekerjaan sendiri (milJobs)
  let spare = 0;
  for (const a of my) {
    if (a === main || a.st === 'fight') continue;
    if (a.sq.length >= need) { aiLead(S, p, a, hx, hy, need, start); continue; }
    const room = main.sq.length + a.sq.length <= MAX_SQ_ARMY;   // боты, как и игроки: не больше MAX_SQ_ARMY отрядов в армии
    if (room && dist(a.x, a.y, main.x, main.y) < 1.8 && a.st === 'idle') mergeNear(S, main);
    else if (room && (a.st === 'idle' || !a.path.length) && dist(a.x, a.y, main.x, main.y) >= 1.8) orderMove(S, a, main.x, main.y);
    else if (!room && a.st === 'idle') {   // армия уже полная: остальные ждут отдельно, а не слипаются в одну кучу
      const k = spare++, gx = hx + ((k % 4) - 1.5) * 3.2, gy = hy + 3.5 + Math.floor(k / 4) * 2.6;
      if (dist(a.x, a.y, gx, gy) > 2.2) orderMove(S, a, gx, gy);
    }
  }
  aiLead(S, p, main, hx, hy, need, start);
}
function aiLead(S, p, main, hx, hy, need, start) {
  if (main.st === 'fight' || main.ship) return;
  if (aiDefend(S, p, main)) return;
  if (main.bat && !main.retreat && units(main) < main.maxU * 0.5) { retreat(S, main); return; }
  { const hs = nearestHospital(S, main); if (hs && dist(main.x, main.y, hs.x + 0.5, hs.y + 0.5) < 4 && !main.bat && !main.path.length) { const hurt = main.sq.some(q => q.s.some(x => x.hp < SQ[q.t].hp * 0.9) || (q.w > 0 && q.s.length < 10)); if (hurt) return; } }
  if (units(main) < main.maxU * 0.35 && main.sq.length < 3) { if (main.st === 'idle') retreat(S, main); return; }
  if (main.sq.length < need || S.time < start) { if (main.st === 'idle' && dist(main.x, main.y, hx, hy) > 6) orderMove(S, main, hx, hy + 1); return; }
  if (main.st === 'move' && main.path.length) return;
  const comp = S.comp[Math.floor(main.y) * S.W + Math.floor(main.x)];
  let best = null, bs = 1e9;
  for (const c of S.cities) {
    if (c.owner === p.id) continue; if (c.owner >= 0 && !atWar(S, p.id, c.owner)) continue;
    if (S.comp[c.y * S.W + c.x] !== comp) continue;
    let def = 0; for (const a of S.armies) if (a.owner === c.owner && c.owner >= 0 && dist(a.x, a.y, c.x + 1, c.y + 1) < 5) def += units(a);
    if (def > units(main) * 1.3) continue;
    const sc = dist(main.x, main.y, c.x + 1, c.y + 1) * (1 + c.level * 0.2) + (c.owner < 0 ? -10 : 0); if (sc < bs) { bs = sc; best = c; }
  }
  if (!best) {
    if (aiSeaOp(S, p, main)) return;
    for (const q of S.players) { if (q.id === p.id || !q.alive) continue; const ci = claimInfo(S, p.id, q.id); if (!p.peaceful && ci && ci.ready && rel(S, p.id, q.id).st === 'peace' && S.rnd() < 0.7) { declareWar(S, p.id, q.id); break; } }
    const chance = { easy: 0.05, normal: 0.12, hard: 0.25 }[p.diff];
    if (!p.peaceful && S.rnd() < chance) {
      let tg = null, td = 1e9;
      const navalCap = (AI_LV[p.diff] || AI_LV.normal).war > 0 && aiCount(S, p.id, 'port') > 0;
      for (const c of S.cities) if (c.owner >= 0 && c.owner !== p.id && (S.comp[c.y * S.W + c.x] === comp || (navalCap && aiLandingSpot(S, c)))) { const r = rel(S, p.id, c.owner); if (r.st === 'truce') continue; if (milPower(S, c.owner) > milPower(S, p.id) * 1.2) continue; const d = dist(main.x, main.y, c.x, c.y); if (d < td) { td = d; tg = c.owner; } }
      if (tg !== null) { const ci = claimInfo(S, p.id, tg); if (ci && ci.ready) declareWar(S, p.id, tg); else if (!ci) startClaim(S, p.id, tg); }
    }
    if (main.st === 'idle' && dist(main.x, main.y, hx, hy) > 6) orderMove(S, main, hx, hy + 1); return;
  }
  const er = orderMove(S, main, best.x + 1, best.y + 1);
  if (er && S.structs) { let tg = null, td = 14; for (const b of S.structs) { if (b.owner < 0 || b.owner === p.id || !atWar(S, p.id, b.owner)) continue; const d = dist(main.x, main.y, b.x, b.y) + dist(b.x, b.y, best.x, best.y) * 0.3; if (d < td) { td = d; tg = b; } } if (tg) orderMove(S, main, tg.x + 0.5, tg.y + 0.5); }
}

/* ===== Боты v2 (v1.30.0): стены, порты, торговый и военный флот, морские десанты, оборона ===== */
// уровни умений: rings — сколько городов обносить стеной, wallAt — когда начинать, ports — сколько портов, war — военные корабли, tradeMax — торговые
const AI_LV = {
  easy:   { rings: 0, wallAt: 1e9, ports: 1, war: 0, tradeMax: 1 },
  normal: { rings: 2, wallAt: 600, ports: 2, war: 1, tradeMax: 3 },
  hard:   { rings: 99, wallAt: 260, ports: 4, war: 3, tradeMax: 6 }
};
/* --- стены: кольцо вокруг города и его построек; сначала угловые башни, потом ворота на всех сторонах, потом стена --- */
function aiRingFor(S, p, c) {
  const ai = p.ai; ai.walls = ai.walls || {}; if (ai.walls[c.id]) return ai.walls[c.id];
  let x0 = c.x - 1, x1 = c.x + 2, y0 = c.y - 1, y1 = c.y + 2; const cx = c.x + 1, cy = c.y + 1;
  for (const b of S.buildings) if (b.owner === p.id && !STRUCT[b.type] && b.type !== 'moat' && dist(b.x, b.y, cx, cy) <= 6) {
    let own = null, bd = 1e9; for (const q of S.cities) if (q.owner === p.id) { const d = dist(b.x, b.y, q.x + 1, q.y + 1); if (d < bd) { bd = d; own = q; } }
    if (own === c) { x0 = Math.min(x0, b.x); x1 = Math.max(x1, b.x); y0 = Math.min(y0, b.y); y1 = Math.max(y1, b.y); }
  }
  x0 -= 2; y0 -= 2; x1 += 2; y1 += 2;
  while (x1 - x0 < 9) { x0--; x1++; } while (y1 - y0 < 9) { y0--; y1++; }
  x0 = Math.max(1, x0); y0 = Math.max(1, y0); x1 = Math.min(S.W - 2, x1); y1 = Math.min(S.H - 2, y1);
  const mx = Math.round((x0 + x1) / 2), my = Math.round((y0 + y1) / 2), T = [], G = [], Wl = [];
  for (const [x, y] of [[x0, y0], [x1, y0], [x0, y1], [x1, y1]]) T.push(['tower', x, y]);
  for (const [x, y] of [[mx, y0], [mx, y1], [x0, my], [x1, my]]) G.push(['gate', x, y]);
  for (let x = x0 + 1; x < x1; x++) for (const y of [y0, y1]) if (x !== mx) Wl.push(['wall', x, y]);
  for (let y = y0 + 1; y < y1; y++) for (const x of [x0, x1]) if (y !== my) Wl.push(['wall', x, y]);
  // начинаем со стороны, откуда вероятнее враг
  let ex = cx, ey = cy, ed = 1e9; for (const q of S.cities) if (q.owner !== p.id) { const d = dist(cx, cy, q.x + 1, q.y + 1); if (d < ed) { ed = d; ex = q.x + 1; ey = q.y + 1; } }
  Wl.sort((a, b) => dist(a[1], a[2], ex, ey) - dist(b[1], b[2], ex, ey)); G.sort((a, b) => dist(a[1], a[2], ex, ey) - dist(b[1], b[2], ex, ey));
  return (ai.walls[c.id] = { t: T.concat(G, Wl), i: 0, g: 0, gt: G.length, done: false });
}
function aiWalls(S, p, mine, lv) {
  if (S.time < lv.wallAt || !lv.rings) return 'none'; const ai = p.ai;
  if (aiCount(S, p.id, 'mine') < 1) return 'none';
  const started = Object.keys(ai.walls || {}).length;
  const cities = mine.filter(c => c.level >= 1).sort((a, b) => (b === mine[0]) - (a === mine[0]) || b.level - a.level);
  for (const c of cities) {
    let ring = ai.walls && ai.walls[c.id]; if (ring && ring.done) continue;
    if (!ring) { if (started >= lv.rings) continue; ring = aiRingFor(S, p, c); }
    let placed = 0, guard = 0;
    while (ring.i < ring.t.length && placed < 3 && guard++ < 40) {
      const [type, x, y] = ring.t[ring.i];
      if (type === 'wall' && ring.g < Math.min(2, ring.gt)) { ring.done = true; break; }   // не удалось поставить ворота — не запираем сами себя
      const cost = BD[type].cost; if (!canAfford(p, cost) || p.stock.gold < cost.gold + 25) return placed ? 'built' : 'wait';
      const e = doBuild(S, p.id, type, x, y);
      if (e === 'Не хватает ресурсов') return placed ? 'built' : 'wait';
      ring.i++; if (!e) { placed++; if (type === 'gate') ring.g++; }
    }
    if (ring.i >= ring.t.length) ring.done = true;
    return placed ? 'built' : (ring.done ? 'none' : 'wait');   // за один «ход» занимаемся одним городом
  }
  return 'none';
}
/* --- порты --- */
function aiPorts(S, p, lv) {
  if (p.autoPort === false) return 'none';
  const np = aiCount(S, p.id, 'port'); if (np >= lv.ports || (p.ai.fails.port || 0) > 6 || S.time < (p.diff === 'hard' ? 150 : 300)) return 'none';
  if (!canAfford(p, BD.port.cost) || p.stock.gold < BD.port.cost.gold + 40) return 'wait';
  const site = aiFindSite(S, p, 'port'); if (!site) { p.ai.fails.port = (p.ai.fails.port || 0) + 1; return 'none'; }
  return doBuild(S, p.id, 'port', site.x, site.y) ? 'none' : 'built';
}
/* --- высадка: берег рядом с чужим городом --- */
function aiLandingSpot(S, c) {
  let best = null, bd = 1e9; const cx = c.x + 1, cy = c.y + 1;
  for (let y = Math.max(1, cy - 7); y <= Math.min(S.H - 2, cy + 7); y++) for (let x = Math.max(1, cx - 7); x <= Math.min(S.W - 2, cx + 7); x++) {
    const t = S.ter[y * S.W + x]; if (isWater(t) || t === TR.MOUNT || S.occ[y * S.W + x] >= 0 || !nearWater(S, x, y)) continue;
    const d = dist(x, y, cx, cy); if (d < bd) { bd = d; best = { x, y }; }
  }
  return best;
}
function aiSeaTarget(S, p, main) {
  const comp = S.comp[Math.floor(main.y) * S.W + Math.floor(main.x)], bad = p.ai.badSea || {}; let best = null, bs = 1e9;
  for (const c of S.cities) {
    if (c.owner === p.id || (bad[c.id] || 0) > S.time) continue; if (c.owner >= 0 && !atWar(S, p.id, c.owner)) continue;
    if (S.comp[c.y * S.W + c.x] === comp) continue;
    const lp = aiLandingSpot(S, c); if (!lp) continue;
    let def = 0; for (const a of S.armies) if (a.owner === c.owner && c.owner >= 0 && dist(a.x, a.y, c.x + 1, c.y + 1) < 6) def += units(a);
    if (def > units(main) * 1.2) continue;
    const sc = dist(main.x, main.y, c.x, c.y) + def * 0.5 + (c.owner < 0 ? -8 : 0); if (sc < bs) { bs = sc; best = { c, lp }; }
  }
  return best;
}
/* --- главная армия грузится в порту на военный корабль --- */
function aiSeaOp(S, p, main) {
  const lv = AI_LV[p.diff] || AI_LV.normal; if (!lv.war || main.st !== 'idle' || main.sq.length < 3 || main.ship) return false;
  const tgt = aiSeaTarget(S, p, main); if (!tgt) return false;
  const comp = S.comp[Math.floor(main.y) * S.W + Math.floor(main.x)]; let port = null, pd = 1e9;
  for (const b of S.buildings) if (b.owner === p.id && b.type === 'port' && !(b.cons > 0) && S.comp[b.y * S.W + b.x] === comp) { const d = dist(b.x, b.y, main.x, main.y); if (d < pd) { pd = d; port = b; } }
  if (!port) return false;
  const sh = S.ships.find(s => s.owner === p.id && s.kind === 'war' && !shipLoad(S, s) && s.st === 'dock' && dist(s.x, s.y, port.x + 0.5, port.y + 0.5) < 4);
  if (!sh) { p.ai.wantWar = true; return false; }
  p.ai.seaTgt = tgt.c.id; return !orderMove(S, main, port.x + 0.5, port.y + 0.5);
}
/* --- корабли: торговля, военные перевозки --- */
function aiNavy(S, p, mine, lv) {
  const ports = S.buildings.filter(b => b.owner === p.id && b.type === 'port' && !(b.cons > 0)); if (!ports.length) return;
  const ships = S.ships.filter(s => s.owner === p.id), trade = ships.filter(s => s.kind === 'trade'), war = ships.filter(s => s.kind === 'war'), g = p.stock.gold;
  // торговые: плывём, если у кого-то из партнёров по торговле есть порт на нашем море
  let partner = false;
  for (const b of S.buildings) if (b.type === 'port' && !(b.cons > 0) && b.owner >= 0 && b.owner !== p.id && rel(S, p.id, b.owner).trade) { const w = nearestTile(S, b.x, b.y, true, 3); if (w && ports.some(o => { const w2 = nearestTile(S, o.x, o.y, true, 3); return w2 && S.comp[w2.y * S.W + w2.x] === S.comp[w.y * S.W + w.x]; })) { partner = true; break; } }
  if (p.autoTrade !== false && partner && trade.length < Math.min(lv.tradeMax, ports.length * 2) && g > 140) buildShip(S, ports[trade.length % ports.length], 'trade');
  // военные: нужны для десанта; сложные боты держат хотя бы один заранее
  const wantWar = !p.peaceful && lv.war > 0 && (p.ai.wantWar || (p.diff === 'hard' && S.time > 420) || S.players.some(q => q.id !== p.id && q.alive && rel(S, p.id, q.id).st === 'war'));
  if (wantWar && war.length < Math.min(lv.war, ports.length * 2) && g > 250 && p.stock.iron >= 30 && p.stock.wood >= 130) { if (!buildShip(S, ports[war.length % ports.length], 'war')) p.ai.wantWar = false; }
  for (const sh of war) aiShip(S, p, sh, ports);
}
function aiShip(S, p, sh, ports) {
  if (sh.path.length || sh.st === 'sail') return;
  const home = bidx(S, sh.home) || ports[0]; if (!home) return;
  if (shipLoad(S, sh)) {   // на борту армия: плывём к берегу у цели; высадка происходит сама по прибытии
    if (sh.landing) { if (unloadShip(S, sh)) { sh.wait = (sh.wait || 0) + 1; if (sh.wait > 3) { sh.landing = null; sh.wait = 0; } } return; }   // не удалось высадиться — повторяем, потом домой
    const c = p.ai.seaTgt != null ? S.cities.find(q => q.id === p.ai.seaTgt) : null, lp = c ? aiLandingSpot(S, c) : null;
    if (lp && !sh.sailed) { const e = orderShip(S, sh, lp.x + 0.5, lp.y + 0.5); if (e) { (p.ai.badSea = p.ai.badSea || {})[c.id] = S.time + 400; p.ai.seaTgt = null; sh.sailed = false; } else sh.sailed = true; return; }
    orderShip(S, sh, home.x + 0.5, home.y + 0.5); sh.sailed = false; return;   // нет цели — возвращаемся и высаживаемся дома
  }
  sh.sailed = false;
  if (dist(sh.x, sh.y, home.x, home.y) > 5) orderShip(S, sh, home.x + 0.5, home.y + 0.5);
}
/* --- оборона: если враг у наших городов, главная армия возвращается --- */
function aiDefend(S, p, main) {
  if (main.siege != null) return false; let best = null, bp = 0;
  for (const c of S.cities) {
    if (c.owner !== p.id || (c.level < 1 && c !== S.cities.find(q => q.owner === p.id))) continue; const cx = c.x + 1, cy = c.y + 1; let pw = 0;
    for (const a of S.armies) if (!a.ship && a.owner !== p.id && a.owner >= 0 && atWar(S, p.id, a.owner) && dist(a.x, a.y, cx, cy) < 9) pw += units(a);
    if (pw > bp) { bp = pw; best = c; }
  }
  if (!best || bp <= 0) return false; const cx = best.x + 1, cy = best.y + 1;
  if (dist(main.x, main.y, cx, cy) > 5 && (main.st !== 'move' || !main.dest || dist(main.dest.x, main.dest.y, cx, cy) > 6)) orderMove(S, main, cx, cy + 2);
  return true;
}
