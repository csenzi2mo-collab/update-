/* ----- pemerintahan: petugas, markas, guild, dan prajurit khusus (untuk pemain dan AI) -----
   Semua fungsi menerima pid (pemilik). Teks mengikuti bahasa aplikasi. */
const gxIsEn = () => typeof I18N !== 'undefined' && I18N.lang === 'en';
const gxl = (en, id) => (gxIsEn() ? en : id);
const GX_LBL = {
  'PEJABAT': ['OFFICIALS', 'PEJABAT'], 'GUILD': ['GUILDS', 'GUILD'], 'PRAJURIT': ['TROOPS', 'PRAJURIT'],
  'PEMADAM': ['FIRE', 'PEMADAM'], 'DOKTER': ['DOCTORS', 'DOKTER'], 'PEMERINTAH': ['GOVERNMENT', 'PEMERINTAH'],
  'POS DAMKAR': ['FIRE STN.', 'POS DAMKAR'], 'SUKSESI': ['SUCCESSION', 'SUKSESI']
};
const gxLabel = s => (GX_LBL[s] ? (gxIsEn() ? GX_LBL[s][0] : GX_LBL[s][1]) : s);

const GX_GUILDS = [
  { id: 'pedagang', n: ['Merchant Guild', 'Guild Pedagang'], d: ['City merchants. Each level adds gold income.', 'Saudagar kota. Tiap level menambah pendapatan emas.'] },
  { id: 'sekte', n: ['Temple Sect', 'Sekte Kuil'], d: ['Sect followers. Each level lowers city unrest every year.', 'Pengikut sekte. Tiap level menurunkan kerusuhan kota setiap tahun.'] },
  { id: 'pengrajin', n: ['Craftsmen Guild', 'Guild Pengrajin'], d: ['Smiths and artisans. Each level adds iron.', 'Tukang dan pandai besi. Tiap level menambah besi.'] },
  { id: 'tani', n: ['Farmers Union', 'Serikat Tani'], d: ['Village farmers. Each level adds food.', 'Petani desa. Tiap level menambah pangan.'] }
];
const GX_UNITS = [
  { id: 'hukum', n: ['Law Enforcers', 'Penegak Hukum'], d: ['Guard cities and villages. Reduce unrest and theft.', 'Menjaga kota dan desa. Mengurangi kerusuhan dan pencurian.'], cost: 4 },
  { id: 'istana', n: ['Palace Guards', 'Penjaga Istana'], d: ['Protect the palace. Raise the ruler\'s loyalty every year.', 'Melindungi istana. Menambah loyalitas raja/ratu tiap tahun.'], cost: 5 },
  { id: 'kafilah', n: ['Caravan Escorts', 'Pengawal Kafilah'], d: ['Escort trade caravans. Add gold income.', 'Mengawal kafilah dagang. Menambah pendapatan emas.'], cost: 4 }
];
const GX_SERVICES = [
  { id: 'damkar', n: ['Firefighters', 'Pemadam Kebakaran'], d: ['Put out fires in cities quickly. Needs a Fire Station (max 3 per station).', 'Memadamkan kebakaran di kota dengan cepat. Perlu Pos Pemadam (maks 3 per pos).'], cost: 6 },
  { id: 'dokter', n: ['Doctors', 'Dokter'], d: ['Speed up hospital care and lower death risk. Needs a Hospital (max 3 per hospital).', 'Mempercepat perawatan dan menurunkan risiko kematian. Perlu Rumah Sakit (maks 3 per rumah sakit).'], cost: 5 }
];
const GX_TITLE = {
  dokter: ['Doctor', 'Dokter'], damkar: ['Firefighter', 'Pemadam'],
  hukum: ['Law Enforcer', 'Penegak Hukum'], istana: ['Palace Guard', 'Penjaga Istana'], kafilah: ['Caravan Escort', 'Pengawal Kafilah']
};
const GX_MAX = 20;
const NM_ONSET = ['Ar', 'Bel', 'Cas', 'Dor', 'El', 'Fen', 'Gal', 'Hel', 'Ir', 'Jal', 'Kor', 'Lys', 'Mor', 'Nor', 'Oth', 'Pel', 'Quin', 'Ren', 'Sol', 'Tyr', 'Ul', 'Vel', 'Wyn', 'Xer', 'Yar', 'Zed', 'Bran', 'Cor', 'Dun', 'Esk', 'Fal', 'Gor', 'Hal', 'Isk', 'Jor', 'Kal', 'Lor', 'Mar', 'Nev', 'Ost', 'Pyr', 'Rav', 'Syl', 'Tor', 'Ulf', 'Var', 'Wen', 'Yul', 'Zal', 'Bryn', 'Cael', 'Dara', 'Eyl', 'Fae', 'Hyl', 'Iva', 'Kyr', 'Lio', 'Mira', 'Oren', 'Sable', 'Thal', 'Uma', 'Vey'];
const NM_MID = ['a', 'e', 'i', 'o', 'u', 'an', 'en', 'in', 'ar', 'el', 'or', 'ith', 'ael', 'ion', 'ara', 'ynn', 'eth', 'orn', 'al', 'is', 'ov', 'yr'];
const NM_END_L = ['ric', 'dus', 'mir', 'van', 'ran', 'ard', 'eon', 'ik', 'iel', 'ros', 'tan', 'vor', 'wen', 'del', 'zar', 'lin', 'on', 'us', 'ek', 'ton', 'drik', 'gar', 'mund', 'ald'];
const NM_END_P = ['a', 'ia', 'ine', 'ella', 'ina', 'ys', 'wen', 'ara', 'elle', 'ith', 'ne', 'ra', 'ola', 'is', 'ea', 'een', 'lyn', 'dra', 'sa', 'ell'];

/* ----- nama acak yang tidak berulang ----- */
function genName(S, jk) {
  const r = R(S), used = new Set(NM_P.concat(NM_L));
  for (const c of Object.values(r.chars).concat(Object.values(r.people))) if (c && c.name) used.add(c.name);
  const pick = a => a[(S.rnd() * a.length) | 0], end = jk === 'P' ? NM_END_P : NM_END_L;
  let n = '';
  for (let i = 0; i < 300; i++) { n = pick(NM_ONSET) + (S.rnd() < 0.5 ? pick(NM_MID) : '') + pick(end); if (!used.has(n)) return n; }
  for (let k = 2; ; k++) if (!used.has(n + ' ' + k)) return n + ' ' + k;
}

/* ----- data per pemilik ----- */
function gxOf(S, pid) {
  S.gx = S.gx || {};
  return S.gx[pid] || (S.gx[pid] = { guild: { pedagang: 0, sekte: 0, pengrajin: 0, tani: 0 }, unit: { hukum: 0, istana: 0, kafilah: 0 }, svc: { damkar: 0, dokter: 0 }, staff: {}, paid: true });
}
function gxBuildings(S, pid, type) { return S.buildings.filter(b => b.owner === pid && b.type === type && !(b.cons > 0)).length; }
function gxCount(S, pid, type) { return S.buildings.filter(b => b.owner === pid && b.type === type).length; }
function gxCap(S, pid, id) { return id === 'dokter' ? 3 * gxBuildings(S, pid, 'hospital') : id === 'damkar' ? 3 * gxBuildings(S, pid, 'firehouse') : GX_MAX; }
function gxStaffKeys(S, pid, id) {
  const g = gxOf(S, pid), r = R(S); g.staff = g.staff || {};
  g.staff[id] = (g.staff[id] || []).filter(k => r.people[k] && !r.people[k].dead);
  return g.staff[id];
}
function gxSync(S, pid) {
  const g = gxOf(S, pid);
  for (const id of ['hukum', 'istana', 'kafilah']) g.unit[id] = gxStaffKeys(S, pid, id).length;
  for (const id of ['dokter', 'damkar']) g.svc[id] = gxStaffKeys(S, pid, id).length;
}

/* ----- markas: lahan dan bangun otomatis ----- */
function gxSite(S, pid, type) {
  const cands = [];
  for (const c of S.cities) if (c.owner === pid) {
    const cx = c.x + 1, cy = c.y + 1, r = Math.floor(c.radius) + 1;
    for (let y = Math.max(0, cy - r); y <= Math.min(S.H - 1, cy + r); y++) for (let x = Math.max(0, cx - r); x <= Math.min(S.W - 1, cx + r); x++) {
      const d = dist(x, y, cx, cy); if (d < 2) continue;
      if (siteOk(S, pid, type, x, y)) continue; cands.push({ x, y, d });
    }
  }
  if (!cands.length) return null;
  cands.sort((a, b) => a.d - b.d);
  return cands[(S.rnd() * Math.min(cands.length, 6)) | 0];
}
function gxAutoBuild(S, pid, type) {
  const site = gxSite(S, pid, type);
  if (!site) return gxl('No free land near your cities.', 'Tidak ada lahan kosong dekat kota.');
  const err = doBuild(S, pid, type, site.x, site.y); if (err) return err;
  if (pid === VP) note(S, { pid, lvl: 'info', type: 'econ', title: gxl('Built automatically: ', 'Dibangun otomatis: ') + BD[type].n, who: gxl('Your government', 'Pemerintah kerajaan'), what: gxl('started building a ' + BD[type].n, 'mulai membangun ' + BD[type].n), where: gxl('near your city', 'dekat kota'), impact: gxl('staff can be hired once it is finished', 'petugas bisa direkrut setelah selesai') });
  return null;
}

/* ----- petugas sebagai NPC sungguhan ----- */
function gxHire(S, pid, id) {
  const r = R(S), g = gxOf(S, pid), en = GX_TITLE[id], title = gxl(en[0], en[1]);
  const key = pid + '|petugas|' + (r.n++);
  const c = newChar(S, key, { store: 'people', t: 'Petugas', gelar: title, owner: pid, umur: 20 + Math.floor(S.rnd() * 30), loyal: 60 + Math.floor(S.rnd() * 30), nsifat: 2 });
  g.staff = g.staff || {}; (g.staff[id] = g.staff[id] || []).push(key);
  if (pid === VP) note(S, { pid, lvl: 'rutin', type: 'pol', key: 'hire' + key, title: gxl('New staff: ', 'Petugas baru: ') + title, who: cname(c) + ' (' + c.umur + ' ' + gxl('yrs', 'th') + ')', what: gxl('recruited as ' + title, 'direkrut sebagai ' + title), where: gxl('Capital ', 'Ibu kota ') + S.players[pid].name, impact: gxl('staff is on duty', 'bertugas sekarang') });
  return c;
}
function gxFire(S, pid, id) { const keys = gxStaffKeys(S, pid, id); if (!keys.length) return; delete R(S).people[keys.pop()]; }
// petugas tidak boleh melebihi markas; kelebihan diberhentikan (misal markas hancur)
function gxPrune(S, pid) {
  for (const id of ['dokter', 'damkar']) while (gxStaffKeys(S, pid, id).length > gxCap(S, pid, id)) gxFire(S, pid, id);
  gxSync(S, pid);
}
// tombol + / − (pemain)
function govAdjust(S, pid, kind, id, d) {
  gxSync(S, pid);
  if (d < 0) { for (let i = 0; i < -d; i++) gxFire(S, pid, id); gxSync(S, pid); return null; }
  const type = id === 'dokter' ? 'hospital' : 'firehouse';
  for (let i = 0; i < d; i++) {
    if (kind === 'svc') {
      const n = gxStaffKeys(S, pid, id).length, done = gxBuildings(S, pid, type), all = gxCount(S, pid, type);
      if (n >= 3 * done) {
        if (all * 3 > n) return gxl('Building is under construction. Wait until it finishes.', 'Bangunan sedang dibangun. Tunggu sampai selesai.');
        const err = gxAutoBuild(S, pid, type); if (err) return err;
        return gxl('Built a ' + BD[type].n + ' automatically. Staff can be hired when it is done.', 'Membangun ' + BD[type].n + ' otomatis. Petugas bisa direkrut setelah selesai.');
      }
    }
    if (gxStaffKeys(S, pid, id).length >= GX_MAX) return gxl('Maximum reached.', 'Batas maksimal tercapai.');
    gxHire(S, pid, id);
  }
  gxSync(S, pid); return null;
}

/* ----- efek ekonomi dan keamanan ----- */
function govRate(S) {
  for (const p of S.players) {
    const g = S.gx && S.gx[p.id]; if (!g || !g.paid || !p.alive) continue; const r = p.rate;
    r.gold += 0.05 * g.guild.pedagang + 0.1 * g.unit.kafilah;
    r.iron += 0.05 * g.guild.pengrajin;
    r.food += 0.05 * g.guild.tani;
  }
}
function govDeathMult(S, pid) {
  const g = S.gx && S.gx[pid]; if (!g || !g.paid) return 1; return 1 - Math.min(0.5, 0.05 * g.svc.dokter);
}
function gxDocBoost(S, pid) { const g = S.gx && S.gx[pid]; if (!g || !g.paid) return 1; return 1 + Math.min(1.5, 0.1 * g.svc.dokter); }
function gxLaw(S, pid) { const g = S.gx && S.gx[pid]; if (!g || !g.paid) return 0; return Math.min(0.4, 0.04 * g.unit.hukum); }

/* AI: membangun markas dan merekrut petugas sendiri */
function gxAi(S, pid) {
  const p = S.players[pid], own = S.cities.filter(c => c.owner === pid), gold = p.stock.gold || 0;
  if (!own.length) return;
  if (!gxCount(S, pid, 'hospital') && gold >= 200) gxAutoBuild(S, pid, 'hospital');
  if (!gxCount(S, pid, 'firehouse') && gold >= 200) gxAutoBuild(S, pid, 'firehouse');
  const tgt = { dokter: 2 * gxBuildings(S, pid, 'hospital'), damkar: 2 * gxBuildings(S, pid, 'firehouse'), hukum: Math.min(GX_MAX, own.length) };
  for (const id of ['dokter', 'damkar', 'hukum']) {
    let n = 0;
    while (gxStaffKeys(S, pid, id).length < Math.min(tgt[id], gxCap(S, pid, id)) && n < 2) { gxHire(S, pid, id); n++; }
  }
  gxSync(S, pid);
}

/* dipanggil sekali per tahun untuk setiap pemilik */
function govTick(S, pid) {
  const p = S.players[pid]; if (!p || !p.alive) return;
  const g = gxOf(S, pid), own = S.cities.filter(c => c.owner === pid), ru = R(S).chars[pid + '|raja'];
  if (own.length) for (const k of GX_GUILDS) g.guild[k.id] = Math.min(5, g.guild[k.id] + 1);
  gxPrune(S, pid);
  if (pid !== VP) gxAi(S, pid);
  else if (own.length >= 2 && (p.stock.gold || 0) >= 300) {   // pemain: markas dibangun otomatis bila belum ada
    if (!gxCount(S, pid, 'hospital')) gxAutoBuild(S, pid, 'hospital');
    if (!gxCount(S, pid, 'firehouse')) gxAutoBuild(S, pid, 'firehouse');
  }
  let upkeep = 0; for (const u of GX_UNITS) upkeep += g.unit[u.id] * u.cost; for (const s of GX_SERVICES) upkeep += g.svc[s.id] * s.cost;
  if (upkeep > 0 && (p.stock.gold || 0) < upkeep) {
    g.paid = false;
    if (pid === VP) note(S, { pid, lvl: 'peringatan', type: 'sec', title: gxl('Wages unpaid', 'Gaji tertunggak'), who: gxl('Troops and services', 'Prajurit dan layanan'), what: gxl('did not receive pay', 'tidak menerima gaji'), where: gxl('whole kingdom', 'seluruh kerajaan'), impact: gxl('need ' + upkeep + ' gold; effects stop until funds are enough', 'butuh ' + upkeep + ' emas; efek berhenti sampai kas cukup') });
    return;
  }
  p.stock.gold -= upkeep; g.paid = true;
  for (const c of own) {
    c.unrest = cl((c.unrest === undefined ? 25 : c.unrest) - Math.min(6, g.unit.hukum) - g.guild.sekte, 0, 100);
    if (S.rnd() < 0.04) {
      if (g.svc.damkar > 0) { if (pid === VP) note(S, { pid, lvl: 'rutin', type: 'sec', title: gxl('Fire in ', 'Kebakaran di ') + c.name, who: gxl('Firefighters', 'Pemadam kebakaran'), what: gxl('put the fire out quickly', 'memadamkan api dengan cepat'), where: c.name, impact: gxl('minor damage', 'kerugian kecil') }); }
      else { p.stock.gold = Math.max(0, p.stock.gold - 30); c.unrest = cl((c.unrest === undefined ? 25 : c.unrest) + 5, 0, 100); if (pid === VP) note(S, { pid, lvl: 'peringatan', type: 'sec', title: gxl('Fire in ', 'Kebakaran di ') + c.name, who: gxl('Townsfolk', 'Warga kota'), what: gxl('fire burned houses with no firefighters', 'api membakar rumah tanpa pemadam'), where: c.name, impact: gxl('gold -30, unrest +5; train firefighters at a Fire Station', 'kas -30 emas, kerusuhan +5; latih pemadam di Pos Pemadam') }); }
    }
  }
  if (ru && g.unit.istana > 0) ru.loyal = cl((ru.loyal === undefined ? 50 : ru.loyal) + Math.min(5, g.unit.istana), 0, 100);
}

/* ----- pandangan pemain: daftar petugas dan markas ----- */
function gxBuildingsBanner(S, what) {
  if (what === 'damkar' && !gxBuildings(S, VP, 'firehouse')) return '<div class="bad">' + gxl('Needs a Fire Station. Build one first.', 'Perlu Pos Pemadam. Bangun dulu.') + '</div>';
  if (what === 'dokter' && !gxBuildings(S, VP, 'hospital')) return '<div class="bad">' + gxl('Needs a Hospital. Build one first.', 'Perlu Rumah Sakit. Bangun dulu.') + '</div>';
  return '';
}
function gxStaffHtml(S, ids) {
  const r = R(S), rows = [];
  for (const id of ids) for (const k of gxStaffKeys(S, VP, id)) {
    const c = r.people[k]; if (!c) continue;
    rows.push(`<div class="it"><div class="g"><b>${cname(c)}</b> · ${c.umur} ${gxl('yrs', 'th')}</div>${btn('profil:' + k, gxl('Profile', 'Profil'))}</div>`);
  }
  return rows.length ? '<div class="gl" style="margin-top:6px">' + gxl('Staff on duty', 'Petugas bertugas') + '</div><div class="list">' + rows.join('') + '</div>' : '';
}
function govxView(S, what) {
  const g = gxOf(S, VP);
  if (what === 'guild') {
    return { title: gxl('Guilds', 'Guild Rakyat'), html: '<div class="dim">' + gxl('Guilds grow 1 level each year (max 5) while the kingdom has a city.', 'Guild tumbuh 1 level tiap tahun (maks 5) selama kerajaan memiliki kota.') + '</div><div class="list">' +
      GX_GUILDS.map(k => `<div class="it"><div class="g"><b>${gxl(k.n[0], k.n[1])}</b> · ${gxl('level', 'level')} ${g.guild[k.id]}<div class="dim">${gxl(k.d[0], k.d[1])}</div></div></div>`).join('') + '</div>' };
  }
  const title = what === 'khusus' ? gxl('Special Troops', 'Prajurit Khusus') : what === 'damkar' ? gxl('Firefighters', 'Pemadam Kebakaran') : gxl('Doctors', 'Dokter');
  const items = what === 'khusus' ? GX_UNITS.map(u => ['unit', u]) : what === 'damkar' ? GX_SERVICES.filter(s => s.id === 'damkar').map(s => ['svc', s]) : GX_SERVICES.filter(s => s.id === 'dokter').map(s => ['svc', s]);
  const unpaid = g.paid ? '' : '<div class="bad">' + gxl('Not enough gold for wages. Effects stop until gold is enough.', 'Kas tidak cukup untuk gaji. Efek berhenti sampai emas cukup.') + '</div>';
  const staffIds = what === 'khusus' ? ['hukum', 'istana', 'kafilah'] : what === 'damkar' ? ['damkar'] : ['dokter'];
  return { title, html: unpaid + gxBuildingsBanner(S, what) + '<div class="list">' + items.map(([kind, x]) => {
    const cost = gxl(`Cost ${x.cost} gold/year each.`, `Biaya ${x.cost} emas/tahun per orang.`), cap = kind === 'svc' ? ` / ${gxCap(S, VP, x.id)}` : '';
    const cnt = kind === 'unit' ? g.unit[x.id] : g.svc[x.id];
    return `<div class="it"><div class="g"><b>${gxl(x.n[0], x.n[1])}</b> · ${cnt}${cap} ${gxl('people', 'orang')}<div class="dim">${gxl(x.d[0], x.d[1])} ${cost}</div></div>${btn('govx:' + kind + ':' + x.id + ':-1', '−')}${btn('govx:' + kind + ':' + x.id + ':1', '+')}</div>`;
  }).join('') + '</div>' + gxStaffHtml(S, staffIds) };
}
