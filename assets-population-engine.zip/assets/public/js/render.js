'use strict';
/* ===== Отрисовка карты ===== */
const RN = { cv: null, ctx: null, dpr: 1, w: 0, h: 0, cam: { x: 0, y: 0, z: 3 }, terrain: null, terrCv: null, cloud: null, cache: {}, S: null, sel: null, place: null, minimap: null, showTerr: true, mmDraw: 0 };
const hash = (x, y, k) => { let h = (Math.imul(x, 73856093) ^ Math.imul(y, 19349663) ^ Math.imul(k, 83492791)) >>> 0; h = Math.imul(h ^ h >>> 13, 1274126177) >>> 0; return ((h ^ h >>> 16) >>> 0) / 4294967296; };
const TCOL = ['#1d4b8c', '#2f8dbd', '#ebd9a3', '#66b04a', '#b5c45a', '#66b04a', '#85984c', '#6b7283'];
function shade(hex, f) { const n = parseInt(hex.slice(1), 16); let r = n >> 16 & 255, g = n >> 8 & 255, b = n & 255; r = Math.max(0, Math.min(255, r * f)) | 0; g = Math.max(0, Math.min(255, g * f)) | 0; b = Math.max(0, Math.min(255, b * f)) | 0; return `rgb(${r},${g},${b})`; }
function newCv(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }

function treeShape(c, cx, yt, w, h, l, d) { for (let j = 0; j < h; j++) { const ww = Math.max(2, Math.round(w * (0.28 + 0.72 * (j + 1) / h))); R_(c, cx - Math.floor(ww / 2), yt + j, Math.ceil(ww / 2), 1, l); R_(c, cx, yt + j, Math.floor(ww / 2), 1, d); } }
function drawPine(c, x, y, v) {
  c.save(); c.translate(x, y); c.scale(0.5, 0.5); const L = ['#3f9a34', '#379030', '#4aa83c'][v], D = ['#1f5a1c', '#1a521a', '#256a20'][v];
  R_(c, -6, -1, 13, 2, 'rgba(0,0,0,0.28)'); R_(c, -1, -5, 2, 5, '#4a2e14'); treeShape(c, 0, -12, 12, 7, L, D); treeShape(c, 0, -16, 9, 6, L, D); treeShape(c, 0, -20, 6, 6, L, D); treeShape(c, 0, -24, 3, 4, L, D);
  R_(c, -1, -23, 1, 1, '#9aee80'); R_(c, -2, -16, 1, 1, '#8ade70'); R_(c, -4, -10, 1, 1, '#8ade70'); R_(c, 2, -9, 2, 1, '#14400f'); R_(c, 1, -14, 2, 1, '#14400f'); c.restore();
}
function drawOak(c, x, y, v) {
  c.save(); c.translate(x, y); c.scale(0.5, 0.5); const g = ['#2b7a2a', '#2a742a', '#33852d'][v];
  R_(c, -7, -1, 15, 2, 'rgba(0,0,0,0.28)'); R_(c, -1, -7, 3, 7, '#5a3a1a'); R_(c, -1, -7, 1, 7, '#7a5a30');
  rrect(c, -8, -16, 16, 10, g, 4); rrect(c, -7, -19, 14, 10, '#3a9a35', 4); rrect(c, -5, -21, 9, 7, '#4cb040', 3); R_(c, -4, -20, 3, 2, '#86e068'); R_(c, 3, -14, 3, 2, g); R_(c, -6, -12, 2, 2, '#1f5a1c'); R_(c, 1, -10, 3, 1, '#1f5a1c'); c.restore();
}
function drawBush(c, x, y) { c.save(); c.translate(x, y); c.scale(0.5, 0.5); R_(c, -5, -1, 11, 2, 'rgba(0,0,0,0.25)'); rrect(c, -4, -6, 9, 6, '#2f7a2a', 2); R_(c, -2, -6, 4, 1, '#4aa83a'); R_(c, 2, -3, 1, 1, '#e84a5a'); R_(c, -3, -2, 1, 1, '#e84a5a'); c.restore(); }

/* ===== Деревья: текстуры 64x64, покачивание на ветру ===== */
const TREE_SC = { pine: 0.215, oak: 0.2 }, TREE_VAR = [0.92, 1, 1.08];
function treeImgs() {
  if (typeof Image === 'undefined' || typeof TREEPNG === 'undefined') return null;
  if (!RN.timg) { RN.timg = {}; for (const k in TREEPNG) { const im = new Image(); im.src = TREEPNG[k]; RN.timg[k] = im; } }
  const a = RN.timg; return (a.pine.complete && a.pine.naturalWidth && a.oak.complete && a.oak.naturalWidth) ? a : null;
}
function treeSize(t) { return 64 * (t.o ? TREE_SC.oak : TREE_SC.pine) * TREE_VAR[t.v]; }
function updateTreeHide(S, sig) { // деревья не должны торчать из зданий, городов и руды
  RN.hideSig = sig; const W = S.W, H = S.H, blk = new Uint8Array(W * H), ore = new Uint8Array(W * H); RN.frontTrees = [];
  for (let i = 0; i < W * H; i++) { if (S.occ && S.occ[i] >= 0) blk[i] = 1; if (S.res[i]) ore[i] = 1; }
  for (const ct of S.cities) for (let dy = -1; dy <= 6; dy++) for (let dx = -1; dx <= 6; dx++) { const X = ct.x + dx, Y = ct.y + dy; if (X >= 0 && Y >= 0 && X < W && Y < H) blk[Y * W + X] = 1; }
  const hit = (m, x0, x1, y0, y1) => { for (let y = Math.max(0, y0); y <= y1 && y < H; y++) for (let x = Math.max(0, x0); x <= x1 && x < W; x++) if (m[y * W + x]) return true; return false; };
  for (const row of RN.treeRows) for (const t of row) {
    const w = treeSize(t), x0 = Math.floor((t.x - w * 0.35) / TS), x1 = Math.floor((t.x + w * 0.35) / TS), y0 = Math.floor((t.y - w * 0.95) / TS), y1 = Math.floor((t.y - 0.5) / TS);
    const fx = Math.floor(t.x / TS), fy = Math.floor((t.y - 0.5) / TS);
    t.hid = false; t.front = false;
    if (hit(ore, x0, x1, y0, y1)) { t.hid = true; continue; }               // руда — как раньше
    if (fx >= 0 && fy >= 0 && fx < W && fy < H && blk[fy * W + fx]) { t.hid = true; continue; }  // корень дерева под зданием — убираем только такие
    if (hit(blk, x0, x1, y0, y1)) { t.front = true; RN.frontTrees.push(t); }   // дерево стоит перед зданием — остаётся и рисуется поверх него
  }
  RN.treeDirty = true;
}
function bakeTreeLayer(S) {
  const im = treeImgs(); if (!im) return null;
  const cv = newCv(S.W * TS, S.H * TS), c = cv.getContext('2d'); c.imageSmoothingEnabled = true; if ('imageSmoothingQuality' in c) c.imageSmoothingQuality = 'high';
  for (const row of RN.treeRows) for (const t of row) {
    if (t.hid || t.front || S.ter[t.ti] !== TR.FOREST) continue; const w = treeSize(t);
    R_(c, t.x - w * 0.32, t.y - 0.7, w * 0.64, 1.4, 'rgba(0,0,0,0.25)'); c.drawImage(t.o ? im.oak : im.pine, t.x - w / 2, t.y - w, w, w);
  }
  RN.treeLayer = cv; RN.treeDirty = false; return cv;
}
function drawTrees(c, S, tm, vx0, vy0, vx1, vy1) {
  const rows = RN.treeRows; if (!rows) return; const im = treeImgs(); if (!im) return; const cam = RN.cam;
  { const sig = S.buildings.length + ':' + S.cities.length + ':' + S.cities.reduce((a, q) => a + q.level, 0); if (RN.hideSig !== sig) updateTreeHide(S, sig); }
  if (cam.z < 1.1) { const L = (RN.treeLayer && !RN.treeDirty) ? RN.treeLayer : bakeTreeLayer(S); if (L) { c.imageSmoothingEnabled = true; c.drawImage(L, 0, 0); c.imageSmoothingEnabled = false; } return; }
  const z = cam.z * RN.dpr, xa = cam.x - 24, xb = cam.x + RN.w / cam.z + 24, y0 = Math.max(0, vy0 - 1), y1 = Math.min(S.H, vy1 + 1);
  for (let y = y0; y < y1; y++) {
    const row = rows[y];
    for (let i = 0; i < row.length; i++) {
      const t = row[i]; if (t.hid || t.front || t.x < xa || t.x > xb || S.ter[t.ti] !== TR.FOREST) continue;
      const w = treeSize(t), gust = 0.65 + 0.35 * Math.sin(tm * 0.37 + t.x * 0.012 + t.y * 0.008),
        sk = (Math.sin(tm * 1.5 + t.x * 0.05 + t.y * 0.02) * 0.05 + Math.sin(tm * 3.1 + t.ph) * 0.012) * gust * (t.o ? 1.3 : 1);
      R_(c, t.x - w * 0.32, t.y - 0.7, w * 0.64, 1.4, 'rgba(0,0,0,0.25)');
      c.imageSmoothingEnabled = z * (w / 64) < 1.2;
      c.save(); c.translate(t.x, t.y); c.transform(1, 0, sk, 1, 0, 0); c.drawImage(t.o ? im.oak : im.pine, -w / 2, -w, w, w); c.restore();
    }
  }
  c.imageSmoothingEnabled = false;
}
function drawFrontTrees(c, S, tm) { // деревья перед зданиями рисуются поверх них
  const L = RN.frontTrees; if (!L || !L.length) return; const im = treeImgs(); if (!im) return; const z = RN.cam.z * RN.dpr;
  for (const t of L) {
    if (S.ter[t.ti] !== TR.FOREST) continue; const w = treeSize(t), gust = 0.65 + 0.35 * Math.sin(tm * 0.37 + t.x * 0.012 + t.y * 0.008),
      sk = RN.cam.z < 1.1 ? 0 : (Math.sin(tm * 1.5 + t.x * 0.05 + t.y * 0.02) * 0.05 + Math.sin(tm * 3.1 + t.ph) * 0.012) * gust * (t.o ? 1.3 : 1);
    R_(c, t.x - w * 0.32, t.y - 0.7, w * 0.64, 1.4, 'rgba(0,0,0,0.25)'); c.imageSmoothingEnabled = z * (w / 64) < 1.2;
    c.save(); c.translate(t.x, t.y); c.transform(1, 0, sk, 1, 0, 0); c.drawImage(t.o ? im.oak : im.pine, -w / 2, -w, w, w); c.restore();
  }
  c.imageSmoothingEnabled = false;
}

/* ===== Руда: текстуры 64x64 ===== */
function oreImgs() {
  if (typeof Image === 'undefined' || typeof OREPNG === 'undefined') return null;
  if (!RN.oimg) { RN.oimg = {}; for (const k in OREPNG) { const im = new Image(); im.src = OREPNG[k]; RN.oimg[k] = im; } }
  const a = RN.oimg; return (a.gold.complete && a.gold.naturalWidth && a.iron.complete && a.iron.naturalWidth) ? a : null;
}
function drawOres(c, vx0, vy0, vx1, vy1) {
  const L = RN.ores; if (!L || !L.length) return; const im = oreImgs(); if (!im) return; const SZ = 20, s = RN.cam.z * RN.dpr * SZ / 64;
  c.imageSmoothingEnabled = s < 1.2;
  for (const o of L) { if (o.x < vx0 - 1 || o.x > vx1 || o.y < vy0 - 1 || o.y > vy1) continue; c.drawImage(o.g ? im.gold : im.iron, o.x * TS + 8 - SZ / 2, o.y * TS - 2, SZ, SZ); }
  c.imageSmoothingEnabled = false;
}
function buildTerrain(S) {
  const W = S.W, H = S.H, cv = newCv(W * TS, H * TS), c = cv.getContext('2d');
  const T = (x, y) => (x < 0 || y < 0 || x >= W || y >= H) ? 0 : S.ter[y * W + x];
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const t = S.ter[y * W + x], px = x * TS, py = y * TS, base = TCOL[t];
    R_(c, px, py, TS, TS, base);
    for (let k = 0; k < 7; k++) { const sx = (hash(x, y, k) * 15) | 0, sy = (hash(x, y, k + 20) * 15) | 0, f = hash(x, y, k + 40) > 0.5 ? 1.09 : 0.92; R_(c, px + sx, py + sy, 2, 1, shade(base, f)); }
    if (t === TR.SHALLOW) { for (let k = 0; k < 3; k++) R_(c, px + ((hash(x, y, k + 60) * 12) | 0), py + ((hash(x, y, k + 70) * 14) | 0), 3, 1, '#8fd6ea'); }
    if (t === TR.FOREST) { /* подошва леса — как трава, без выделения */
    } else if (t === TR.GRASS && hash(x, y, 9) > 0.8) { R_(c, px + 6, py + 6, 1, 1, '#fff2a6'); R_(c, px + 11, py + 10, 1, 1, '#f4a6c8'); }
    // береговая пена
    if (isWater(t)) {
      const land = (dx, dy) => !isWater(T(x + dx, y + dy));
      if (land(0, -1)) R_(c, px, py, TS, 2, '#e2f6ff'); if (land(0, 1)) R_(c, px, py + 14, TS, 2, '#e2f6ff'); if (land(-1, 0)) R_(c, px, py, 2, TS, '#e2f6ff'); if (land(1, 0)) R_(c, px + 14, py, 2, TS, '#e2f6ff');
    } else if (t === TR.SAND) { /* ok */ }
    // руда
    const r = S.res[y * W + x];
    
  }
  // горы и холмы: чёткая «пиксельарт»-лепка (ступенчатая высота, свет сверху-слева, снег, страты)
  {
    const mv = (x, y) => (x < 0 || y < 0 || x >= W || y >= H) ? 0 : (S.ter[y * W + x] === TR.MOUNT ? 1 : S.ter[y * W + x] === TR.HILL ? 0.42 : 0);
    const nz = makeNoise(S.seed + 555), N = TS + 2, hg = new Float32Array(N * N);
    const ROCK = ['#43474f', '#5f646e', '#7e838d', '#a0a5af'], SNOW = ['#8da0c4', '#b9c8e4', '#e2eaf7', '#ffffff'], SCREE = ['#5c5b52', '#7a786c', '#999585', '#b4af9c'], SLOPE = ['#4f6a2c', '#68803a', '#809a48', '#9ab45e'];
    for (let ty = 0; ty < H; ty++) for (let tx = 0; tx < W; tx++) {
      let any = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) any = Math.max(any, mv(tx + dx, ty + dy)); if (!any) continue;
      if (isWater(S.ter[ty * W + tx])) continue;
      let mx = 0; for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
        const wx = tx * TS + i - 1, wy = ty * TS + j - 1, u = wx / TS - 0.5, w = wy / TS - 0.5, x0 = Math.floor(u), y0 = Math.floor(w), fx = u - x0, fy = w - y0;
        let v = mv(x0, y0) * (1 - fx) * (1 - fy) + mv(x0 + 1, y0) * fx * (1 - fy) + mv(x0, y0 + 1) * (1 - fx) * fy + mv(x0 + 1, y0 + 1) * fx * fy;
        v = v > 0.02 ? v + (nz(wx / 10 + 40, wy / 10 + 40, 3) - 0.5) * (v > 0.5 ? 0.62 : 0.3) : 0; hg[j * N + i] = v; if (v > mx) mx = v;
      }
      if (mx < 0.1) continue;
      for (let j = 0; j < TS; j++) for (let i = 0; i < TS; i++) {
        const k = (j + 1) * N + i + 1, h = hg[k]; if (h < 0.12) continue; const wx = tx * TS + i, wy = ty * TS + j;
        const lit = (hg[k + 1] - hg[k - 1]) + (hg[k + N] - hg[k - N]); // вправо/вниз выше -> склон освещён
        const tone = lit > 0.13 ? 3 : lit > 0.03 ? 2 : lit > -0.08 ? 1 : 0;
        let pal, edge = false;
        if (h > 1.04) pal = SNOW; else if (h > 0.62) pal = ROCK; else if (h > 0.42) pal = SCREE; else pal = SLOPE;
        const band = h * (pal === ROCK ? 12 : 8), fr = band - Math.floor(band); // контуры-страты
        let t2 = tone; if (fr < 0.11 && h > 0.3) t2 = Math.max(0, tone - 1);
        if (h < 0.2) { if (((wx + wy) & 1) || h < 0.15) continue; t2 = 0; pal = SLOPE; }
        if (pal === ROCK && h < 0.7) t2 = Math.max(0, t2 - 1);
        R_(c, wx, wy, 1, 1, pal[t2]);
      }
    }
  }
  // руда: рисуется отдельно текстурами (см. drawOres)
  RN.ores = []; for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const q = S.res[y * W + x]; if (q) RN.ores.push({ x, y, g: q === 2 }); }
  // деревья: сортировка по глубине, разные породы и плотность
  {
    const trees = [], isF = (x, y) => x >= 0 && y >= 0 && x < W && y < H && S.ter[y * W + x] === TR.FOREST, SL = [[4, 5], [12, 4], [7, 11], [14, 12]];
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      if (!isF(x, y)) continue; let fn = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if ((dx || dy) && isF(x + dx, y + dy)) fn++;
      const n = fn >= 7 ? 4 : fn >= 5 ? 3 : fn >= 3 ? 2 : 2;
      for (let k = 0; k < n; k++) { const sl = SL[(k + (hash(x, y, 300) * 4 | 0)) % 4], q = hash(x, y, 310 + k); trees.push({ x: x * TS + sl[0] + (hash(x, y, 320 + k) - 0.5) * 3, y: y * TS + sl[1] + 4 + (hash(x, y, 330 + k) - 0.5) * 2, o: q > (fn >= 6 ? 0.72 : 0.45), v: (hash(x, y, 340 + k) * 3) | 0, ti: y * W + x, ty: y, ph: hash(x, y, 360 + k) * 6.28 }); }
      if (fn < 4 && hash(x, y, 350) > 0.5) trees.push({ x: x * TS + 3 + hash(x, y, 351) * 10, y: y * TS + 14, bush: true, v: 0 });
    }
    trees.sort((a, b) => a.y - b.y);
    // кусты остаются в земле, деревья рисуются отдельно (покачиваются на ветру)
    RN.treeRows = []; for (let y = 0; y < H; y++) RN.treeRows.push([]); RN.treeLayer = null; RN.treeDirty = true; RN.hideSig = null;
    for (const t of trees) { if (t.bush) drawBush(c, t.x, t.y); else RN.treeRows[t.ty].push(t); }
  }
  { const fm = newCv(W, H), fc = fm.getContext('2d'); fc.fillStyle = '#34803a'; for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (S.ter[y * W + x] === TR.FOREST) fc.fillRect(x, y, 1, 1); RN.forestMini = fm; }
  RN.terrain = cv;
  // облака
  const cw = W * 4, ch = H * 4, cc = newCv(cw, ch), cx = cc.getContext('2d'), nz = makeNoise(S.seed + 4242);
  for (let y = 0; y < ch; y++) for (let x = 0; x < cw; x++) { const v = nz(x / 28, y / 28, 3); if (v > 0.6) { cx.fillStyle = v > 0.66 ? 'rgba(255,255,255,0.30)' : 'rgba(255,255,255,0.16)'; cx.fillRect(x, y, 1, 1); } }
  RN.cloud = cc; RN.terrCv = newCv(W * 8, H * 8); S.dirtyT = true; RN.cache = {};
}
function drawTerr(S) {
  const W = S.W, H = S.H, c = RN.terrCv.getContext('2d'); c.clearRect(0, 0, W * 8, H * 8);
  const own = (x, y) => (x < 0 || y < 0 || x >= W || y >= H) ? -3 : S.terr[y * W + x];
  const col = o => o === -1 ? '#bbbbbb' : S.players[o].col;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const o = S.terr[y * W + x]; if (o === -2) continue; const px = x * 8, py = y * 8, cl = col(o);
    c.globalAlpha = o === -1 ? 0.10 : 0.20; R_(c, px, py, 8, 8, cl); c.globalAlpha = 1;
    const e = (dx, dy) => own(x + dx, y + dy) !== o;
    c.fillStyle = cl;
    if (e(0, -1)) for (let i = 0; i < 8; i += 2) c.fillRect(px + i, py, 1, 1), c.fillRect(px + i + 1, py + 1, 1, 1);
    if (e(0, 1)) for (let i = 0; i < 8; i += 2) c.fillRect(px + i, py + 7, 1, 1), c.fillRect(px + i + 1, py + 6, 1, 1);
    if (e(-1, 0)) for (let i = 0; i < 8; i += 2) c.fillRect(px, py + i, 1, 1), c.fillRect(px + 1, py + i + 1, 1, 1);
    if (e(1, 0)) for (let i = 0; i < 8; i += 2) c.fillRect(px + 7, py + i, 1, 1), c.fillRect(px + 6, py + i + 1, 1, 1);
  }
  S.dirtyT = false;
}
function sprite(key, w, h, fn) { let s = RN.cache[key]; if (!s) { s = newCv(w, h); fn(s.getContext('2d')); RN.cache[key] = s; } return s; }
function volSprite(key, w, h, depth, fn) { // спрайт с объёмом: боковая грань, тень
  return sprite(key, w + depth + 2, h + 3, out => {
    const b = newCv(w, h); fn(b.getContext('2d'));
    const tint = col => { const t = newCv(w, h), x = t.getContext('2d'); x.drawImage(b, 0, 0); x.globalCompositeOperation = 'source-atop'; x.fillStyle = col; x.fillRect(0, 0, w, h); return t; };
    const sh = tint('rgba(0,0,0,0.5)'), sd = tint('rgba(12,10,40,0.45)');
    out.globalAlpha = 0.45; out.drawImage(sh, depth + 1, 2); out.globalAlpha = 1;
    for (let k = depth; k >= 1; k--) out.drawImage(sd, k, 0);
    out.drawImage(b, 0, 0);
  });
}
function bldSprite(b, col, mask) { const st = b.type === 'wall', dp = STRUCT[b.type] && (mask & 2) ? 0 : 3; return volSprite('b' + b.type + (st ? '' : col) + b.res + (mask || 0), 32, 32, dp, c => DRAW[b.type](c, 0, 0, col, b.res, mask)); }
function structMask(S, b) {
  const t = b.type, nb = (dx, dy) => { const x = b.x + dx, y = b.y + dy; if (x < 0 || y < 0 || x >= S.W || y >= S.H) return false; if (t === 'moat') { if (isWater(S.ter[y * S.W + x])) return true; const o = S.occ[y * S.W + x], mb = o >= 0 && o < 1000000 ? S.bmap.get(o) : null; return !!(mb && mb.type === 'moat'); } const sb = structAtTile(S, x, y); return !!sb; };
  return (nb(0, -1) ? 1 : 0) | (nb(1, 0) ? 2 : 0) | (nb(0, 1) ? 4 : 0) | (nb(-1, 0) ? 8 : 0);
}
function moatSprite(mask, wet) { return sprite('m' + mask + wet, 32, 32, c => drawMoat(c, 0, 0, mask, wet)); }
function lineTiles(x0, y0, x1, y1) { const l = []; let dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, er = dx + dy, x = x0, y = y0; for (let n = 0; n < 400; n++) { l.push({ x, y }); if (x === x1 && y === y1) break; const e2 = 2 * er; if (e2 >= dy) { er += dy; x += sx; } if (e2 <= dx) { er += dx; y += sy; } } return l; }
function citySprite(ct, col) { return volSprite('c' + col + ct.level + ct.isCap + (ct.level === 0 ? 'v' + (ct.vs | 0) : '') + (ct.level ? 'h' + (ct.hx | 0) : '') + (treeImgs() ? 'T' : ''), 128, 128 + CITY_PAD, 4, c => drawCitySprite(c, 0, CITY_PAD, col, ct.level, ct.isCap, ct.vs | 0, ct.hx | 0)); }
function footColor(S, ct) { // средний цвет местности под поселением — земля города подстраивается под место, где он стоит
  let r = 0, g = 0, b = 0, n = 0; for (let dy = -1; dy < 3; dy++) for (let dx = -1; dx < 3; dx++) { const x = ct.x + dx, y = ct.y + dy; if (x < 0 || y < 0 || x >= S.W || y >= S.H) continue; let t = S.ter[y * S.W + x]; if (isWater(t)) continue; if (t === TR.FOREST || t === TR.MOUNT) t = TR.GRASS; const h = parseInt(TCOL[t].slice(1), 16); r += h >> 16 & 255; g += h >> 8 & 255; b += h & 255; n++; }
  if (!n) return TCOL[TR.GRASS]; const q = v => ('0' + (Math.round(v / n / 8) * 8).toString(16)).slice(-2); return '#' + q(r) + q(g) + q(b);
}
function groundSprite(S, ct) { const base = footColor(S, ct); return sprite('cg' + (ct.level === 0 ? 'v' + (ct.vs | 0) : 't' + ct.level + (ct.isCap ? 'c' : '')) + base, 128, 128, c => ct.level === 0 ? drawVillageGround(c, ct.vs | 0, base) : drawTownGround(c, base, ct.level, ct.isCap)); }
const cityOX = ct => (ct.x - 1) * TS, cityOY = ct => (ct.y - 1) * TS;   // левый верхний угол поселения 4x4 в мире
const drawSpr = (c, spr, x, y) => c.drawImage(spr, x, y, spr.width * 0.5, spr.height * 0.5);
/* здание в стройке: бледный силуэт, растущая готовая часть, строительные леса, стук и пыль */
function drawConstruction(c, spr, x, y, p, tm, id, thin) {
  const w = spr.width * 0.5, h = spr.height * 0.5; p = Math.max(0.04, Math.min(1, p));
  c.save(); c.globalAlpha = 0.25; c.drawImage(spr, x, y, w, h); c.globalAlpha = 1;
  const sy = spr.height * (1 - p), dh = h * p; c.drawImage(spr, 0, sy, spr.width, spr.height - sy, x, y + h - dh, w, dh);
  if (!thin) {
    const top = y + h * (1 - Math.min(1, p + 0.18)); R_(c, x - 0.6, top, 0.8, y + h - top, '#8a5a2b'); R_(c, x + w - 0.2, top, 0.8, y + h - top, '#8a5a2b'); R_(c, x - 0.6, top, 0.3, y + h - top, '#b27a3a');
    for (let k = 0; k < 4; k++) { const yy = y + h - (k + 1) * (y + h - top) / 4.2; R_(c, x - 0.6, yy, w + 1.4, 0.55, '#5a3a1a'); }
    R_(c, x - 0.6, top, w + 1.4, 0.5, '#b27a3a');
    const ph = Math.floor(tm * 5 + id) % 2, wx = x + 1 + ((tm * 2.2 + id * 1.3) % 1) * (w - 3); R_(c, wx, y + h - 3.2, 0.9, 2.1, '#e8c49a'); R_(c, wx - 0.2, y + h - 3.6, 1.3, 0.7, '#c9a064'); R_(c, wx + (ph ? 0.9 : 0.5), y + h - 3.2, ph ? 1.2 : 0.5, 0.5, '#a8743a');   // строитель с молотком
    c.globalAlpha = 0.35 + 0.25 * Math.sin(tm * 6 + id); R_(c, x + 1 + (id % 5), y + h - 0.8, 1.6, 0.8, '#d8d0b8'); R_(c, x + w - 3 - (id % 3), y + h - 1.0, 1.2, 0.8, '#d8d0b8');   // пыль
  } else { c.globalAlpha = 0.5; R_(c, x, y + h - dh - 0.4, w, 0.5, '#d8c9a0'); }
  c.restore();
}
/* ----- анимации ----- */
function smoke(c, wx, wy, tm, seed, sc) { for (let k = 0; k < 4; k++) { const ph = (tm * 0.42 + k / 4 + seed * 0.37) % 1, a = (1 - ph) * 0.6, sz = (0.7 + ph * 1.5) * (sc || 1); c.globalAlpha = a; R_(c, wx + Math.sin(ph * 7 + k + seed) * 0.7 + ph * 1.3 - sz / 2, wy - ph * 7 - sz / 2, sz, sz, k % 2 ? '#e0e0e8' : '#b4b4c0'); } c.globalAlpha = 1; }
function waveFlag(c, wx, wy, col, tm, seed) { for (let i = 0; i < 6; i++) { const yo = Math.sin(tm * 5 + i * 0.9 + seed) * 0.45 * (i / 5 + 0.15); R_(c, wx + i * 0.5, wy + yo, 0.5, 2, col); R_(c, wx + i * 0.5, wy + yo, 0.5, 0.4, shadeC(col, 1.4)); R_(c, wx + i * 0.5, wy + yo + 1.6, 0.5, 0.4, shadeC(col, 0.62)); } }
function animBuilding(c, type, ox, oy, col, tm, seed, res, bb) {
  const H = 0.5;
  switch (type) {
    case 'forge': { smoke(c, ox + 23 * H, oy + 1, tm, seed); const f = Math.floor(tm * 9 + seed) % 3; R_(c, ox + (8 + f) * H, oy + (19 + f % 2) * H, 4 * H, 3 * H, f === 1 ? '#fff4b0' : '#ffb840'); if (f === 2) R_(c, ox + 3 * H, oy + (20 - (tm * 8 % 3)) * H, 0.5, 0.5, '#ffd860'); break; }
    case 'sawmill': { smoke(c, ox + 19.5 * H, oy + 3 * H, tm, seed, 0.8); const a = tm * 7 + seed; for (let k = 0; k < 3; k++) { const an = a + k * 2.09; R_(c, ox + (25 + Math.cos(an) * 3.6) * H, oy + (24 + Math.sin(an) * 3.6) * H, 0.7, 0.7, '#fff'); } break; }
    case 'hospital': { if (bb && bb.treated > 0) for (let k = 0; k < 3; k++) { const ph = (tm * 0.8 + k / 3 + seed * 0.2) % 1, px = ox + (6 + k * 9) * H + Math.sin(ph * 6 + k) * 0.6, py = oy + 4 - ph * 7; c.globalAlpha = 1 - ph; R_(c, px - 0.3, py - 1, 0.6, 2, '#7dff7d'); R_(c, px - 1, py - 0.3, 2, 0.6, '#7dff7d'); c.globalAlpha = 1; } R_(c, ox + 14.5 * H, oy + 14.5 * H, 0.0, 0.0, '#fff'); break; }
    case 'workshop': smoke(c, ox + 22 * H, oy + 1 * H, tm, seed, 0.7); break;
    case 'barracks': waveFlag(c, ox + 16 * H, oy + 2 * H, col, tm, seed); break;
    case 'market': waveFlag(c, ox + 16 * H, oy + 0, col, tm, seed); break;
    case 'port': waveFlag(c, ox + 29 * H, oy + 12 * H, col, tm, seed); break;
    case 'mine': { waveFlag(c, ox + 28 * H, oy + 1 * H, col, tm, seed); const f = Math.floor(tm * 6 + seed) % 3; R_(c, ox + 15 * H, oy + 17 * H, 2 * H, 2 * H, f === 0 ? '#ffe890' : '#f8c850'); if (Math.floor(tm * 2 + seed) % 4 === 0) R_(c, ox + 4 * H, oy + 21 * H, 0.5, 0.5, '#fff'); if (Math.floor(tm * 2 + seed) % 4 === 2) R_(c, ox + 27 * H, oy + 19 * H, 0.5, 0.5, '#fff'); break; }
    case 'farm': { for (let j = 0; j < 5; j++) { const px = (tm * 5 + j * 3 + seed) % 22; if (px < 18) R_(c, ox + (1 + px) * H, oy + (2 + j * 4) * H, 0.5, 0.5, '#d8ff98'); } break; }
  }
}
function ownerCol(S, o) { return o < 0 ? '#9a9a9a' : S.players[o].col; }

function resize() {
  const cv = RN.cv; RN.dpr = Math.min(2, window.devicePixelRatio || 1); RN.w = window.innerWidth; RN.h = window.innerHeight;
  cv.width = RN.w * RN.dpr; cv.height = RN.h * RN.dpr; cv.style.width = RN.w + 'px'; cv.style.height = RN.h + 'px';
}
function clampCam() {
  const S = RN.S; if (!S) return; const cam = RN.cam, vw = RN.w / cam.z, vh = RN.h / cam.z, mw = S.W * TS, mh = S.H * TS;
  cam.x = Math.max(-vw * 0.3, Math.min(mw - vw * 0.7, cam.x)); cam.y = Math.max(-vh * 0.3, Math.min(mh - vh * 0.7, cam.y));
}
function centerOn(tx, ty) { RN.cam.x = tx * TS - RN.w / RN.cam.z / 2; RN.cam.y = ty * TS - RN.h / RN.cam.z / 2; clampCam(); }

function frame(S, now) {
  const c = RN.ctx, cam = RN.cam, z = cam.z * RN.dpr; c.setTransform(1, 0, 0, 1, 0, 0); c.imageSmoothingEnabled = false;
  c.fillStyle = '#10222f'; c.fillRect(0, 0, RN.cv.width, RN.cv.height);
  if (!S || !RN.terrain) return;
  // время отрисовки идёт плавно между тиками симуляции (тик — раз в 0.25 с): стрелы, удары и позы бойцов не «шагают»
  if (S.time !== RN.lt) { RN.lt = S.time; RN.lw = now; }
  { const U_ = typeof UI !== 'undefined' ? UI : null, spd = U_ ? (U_.paused ? 0 : (U_.speed || 1)) : 1; RN.rt = S.time + Math.min(0.25, Math.max(0, now - RN.lw) / 1000 * spd); RN.tickMs = Math.max(60, 250 / (spd || 1)); }
  RN.fdt = Math.min(0.1, Math.max(0.001, (now - (RN.ln || now)) / 1000)); RN.ln = now;
  if (S.dirtyT) drawTerr(S);
  if (S.patches && S.patches.length) { const tc = RN.terrain.getContext('2d'); for (const p of S.patches) { const tx = p.x, ty = p.y, px = tx * TS, py = ty * TS; R_(tc, px, py, TS, TS, TCOL[TR.GRASS]); for (let k = 0; k < 7; k++) R_(tc, px + ((hash(tx, ty, k) * 15) | 0), py + ((hash(tx, ty, k + 20) * 15) | 0), 2, 1, hash(tx, ty, k + 40) > 0.5 ? shade(TCOL[3], 1.09) : shade(TCOL[3], 0.92)); } if (RN.forestMini) { const fc = RN.forestMini.getContext('2d'); for (const p of S.patches) fc.clearRect(p.x, p.y, 1, 1); } S.patches = []; RN.treeDirty = true; }
  c.setTransform(z, 0, 0, z, -cam.x * z, -cam.y * z); c.imageSmoothingEnabled = false;
  const vx0 = Math.max(0, Math.floor(cam.x / TS) - 1), vy0 = Math.max(0, Math.floor(cam.y / TS) - 1), vx1 = Math.min(S.W, Math.ceil((cam.x + RN.w / cam.z) / TS) + 1), vy1 = Math.min(S.H, Math.ceil((cam.y + RN.h / cam.z) / TS) + 1);
  c.drawImage(RN.terrain, 0, 0);
  // искры воды
  const tm = now / 1000;
  drawTrees(c, S, tm, vx0, vy0, vx1, vy1);
  drawOres(c, vx0, vy0, vx1, vy1);
  { if (!RN.spk || RN.spk.ter !== S.ter) { const L = []; for (let k = 0; k < 7; k++) { const a = []; for (let y = 0; y < S.H; y++) for (let x = 0; x < S.W; x++) if (S.ter[y * S.W + x] <= 1 && hash(x, y, k) > 0.93) a.push(x, y, x * TS + ((hash(x, y, 3) * 12) | 0), y * TS + ((hash(x, y, 4) * 12) | 0)); L.push(a); } RN.spk = { ter: S.ter, L }; }
    const a = RN.spk.L[Math.floor(tm * 1.2) % 7]; c.fillStyle = 'rgba(255,255,255,0.55)'; for (let i = 0; i < a.length; i += 4) { const x = a[i], y = a[i + 1]; if (x >= vx0 && x < vx1 && y >= vy0 && y < vy1) c.fillRect(a[i + 2], a[i + 3], 3, 1); } }
  if (RN.showTerr) c.drawImage(RN.terrCv, 0, 0, S.W * TS, S.H * TS);
  // подсветка допустимых мест
  const pl = RN.place;
  if (pl && pl.type !== 'village') {
    c.globalAlpha = 0.35;
    for (let y = vy0; y < vy1; y++) for (let x = vx0; x < vx1; x++) if (S.terr[y * S.W + x] === 0 && !siteOk(S, VP, pl.type, x, y)) R_(c, x * TS, y * TS, TS, TS, '#7dff7d');
    c.globalAlpha = 1;
  }
  // здания
  for (const b of S.buildings) { if (b.type !== 'moat' || b.x < vx0 - 1 || b.x > vx1 || b.y < vy0 - 1 || b.y > vy1) continue; if (b.cons > 0) c.globalAlpha = 0.35; c.drawImage(moatSprite(structMask(S, b), b.wet ? 1 : 0), b.x * TS, b.y * TS, TS, TS); c.globalAlpha = 1; if (b.wet) { const k = Math.floor(tm * 1.5 + b.id) % 5; if (k < 2) R_(c, b.x * TS + 3 + hash(b.x, b.y, k) * 8, b.y * TS + 3 + hash(b.x, b.y, k + 9) * 8, 2, 0.5, 'rgba(255,255,255,0.5)'); } }
  const vis = []; for (const b of S.buildings) { if (b.type === 'moat' || b.x < vx0 - 1 || b.x > vx1 || b.y < vy0 - 1 || b.y > vy1) continue; vis.push(b); } vis.sort((p, q) => p.y - q.y || p.x - q.x);
  for (const b of vis) {
    const st = STRUCT[b.type];
    const bsp = bldSprite(b, ownerCol(S, b.owner), st ? structMask(S, b) : 0);
    if (b.cons > 0) drawConstruction(c, bsp, b.x * TS, b.y * TS, 1 - b.cons / b.cons0, now / 1000, b.id, b.type === 'wall' || b.type === 'gate');
    else { drawSpr(c, bsp, b.x * TS, b.y * TS);
    if (b.owner >= -1) animBuilding(c, b.type, b.x * TS, b.y * TS, ownerCol(S, b.owner), now / 1000, b.id, b.res, b); }
    if (st && b.hp < b.mhp) { const f = Math.max(0, b.hp / b.mhp); if (f < 0.6) for (let k = 0; k < 3; k++) R_(c, b.x * TS + 3 + hash(b.x, b.y, k) * 9, b.y * TS + 3 + hash(b.x, b.y, k + 5) * 9, 0.5, 2.2 + k, '#2a2420'); R_(c, b.x * TS + 2, b.y * TS - 1.4, 12, 1.3, '#14100c'); R_(c, b.x * TS + 2.3, b.y * TS - 1.1, 11.4 * f, 0.7, f > 0.5 ? '#7dff7d' : f > 0.25 ? '#ffd24a' : '#ff6a4a'); }
    if (b.type === 'tower' && b.gar && b.gar.s.length) { const col = ownerCol(S, b.owner), n = Math.min(3, b.gar.s.length); for (let k = 0; k < n; k++) { const sh = b.gar.s[k], bob = rtOf(S) - (sh.atk || -9) < 0.3 ? -0.3 : 0; drawFig(c, 'archer', col, b.x * TS + 4.2 + k * 3.8, b.y * TS + 4.6 + bob, 1); } }
  }
  // города
  for (const ct of S.cities) {
    drawSpr(c, groundSprite(S, ct), cityOX(ct), cityOY(ct)); drawSpr(c, citySprite(ct, ownerCol(S, ct.owner)), cityOX(ct), cityOY(ct) - CITY_PAD * 0.5); animCity(c, ct, ownerCol(S, ct.owner), now / 1000); if (cam.z >= 1.4 && !ct.cap && ct.owner !== -2 && 255 - todTint(todHours(S))[1] < 90) drawVillagers(c, ct, now / 1000);
    if (ct.cap) { const col = ownerCol(S, ct.cap.by), total = 64, filled = Math.floor(ct.cap.p * total); for (let i = 0; i < total; i++) { const gx = cityOX(ct) + (i % 8) * 8, gy = cityOY(ct) + ((i / 8) | 0) * 8; c.globalAlpha = i < filled ? 0.5 : 0.12; R_(c, gx, gy, 8, 8, col); c.globalAlpha = 0.55; c.strokeStyle = col; c.lineWidth = 0.4; c.strokeRect(gx + 0.2, gy + 0.2, 7.6, 7.6); } c.globalAlpha = 1; }
  }
  drawFrontTrees(c, S, tm);
  // маршруты: стрелка направления с учётом воды, гор и границ
  const sel = RN.sel;
  for (const a of S.armies) { if (a.owner !== 0 || a.ship || !a.path.length) continue; const isSel = sel && sel.k === 'army' && sel.id === a.id; if (isSel || (a.st === 'move')) drawRoute(c, a.x, a.y, a.path, isSel ? 1 : 0.35, tm, '#ffe27a'); }
  if (sel && sel.k === 'ship') { const a = S.ships.find(q => q.id === sel.id); if (a && a.path.length) drawRoute(c, a.x, a.y, a.path, 1, tm, '#bfe8ff'); }
  // корабли
  for (const sh of S.ships) {
    if (!canSee(S, sh)) continue; const col = ownerCol(S, sh.owner), bob = Math.sin(tm * 2 + sh.id) > 0 ? 0 : 0.5, sp = sprite('sh' + sh.kind + col, 36, 24, cc => cc.drawImage(shipSpriteCanvas(sh.kind, col), 0, 0));
    c.save(); c.translate(sh.x * TS, sh.y * TS + bob); c.scale(sh.face || 1, 1); c.drawImage(sp, -6, -5.5, 12, 8); c.restore();
    if (sel && sel.k === 'ship' && sel.id === sh.id) selBox(c, sh.x * TS - 7, sh.y * TS - 6, 14, 11, tm);
    { const ld = shipLoad(S, sh); for (let k = 0; k < ld; k++) R_(c, sh.x * TS - 1.25 * ld + 2.5 * k, sh.y * TS - 7, 2, 1.5, col); }   // по флажку на каждый отряд на борту
  }
  // эффекты боя в двух слоях: пыль, удары, следы — ПОД бойцами (не закрывают их), стрелы и ядра — над ними
  const fxPass = air => {
  for (const f of S.fx) {
    const age = rtOf(S) - f.t; if (age < 0) continue; if ((f.k === 'arr' || f.k === 'rock') !== air) continue;
    if (f.k === 'arr') {
      if (age > f.d + 0.15 || (!visibleAt(S, f.x1, f.y1) && !visibleAt(S, f.x0, f.y0))) continue;
      const p = Math.min(1, age / f.d), dd = Math.hypot(f.x1 - f.x0, f.y1 - f.y0) * TS, ah = Math.min(5, 1 + dd * 0.16), pos = q => [(f.x0 + (f.x1 - f.x0) * q) * TS, (f.y0 + (f.y1 - f.y0) * q) * TS - 2.5 - Math.sin(Math.PI * q) * ah];
      const a1 = pos(p), vx = (f.x1 - f.x0) * TS, vy = (f.y1 - f.y0) * TS - ah * Math.PI * Math.cos(Math.PI * p);   // направление — производная траектории: наконечник всегда смотрит по полёту
      if (p < 1) { const ang = Math.atan2(vy, vx);
        for (let k = 1; k <= 3; k++) { const tp = Math.max(0, p - k * 0.035), tq = pos(tp); c.globalAlpha = 0.16 * (4 - k); R_(c, tq[0] - 0.15, tq[1] - 0.15, 0.3, 0.3, '#fff'); } c.globalAlpha = 1;   // короткий след позади
        c.save(); c.translate(a1[0], a1[1]); c.rotate(ang); R_(c, -1.15, -0.32, 2.5, 0.64, 'rgba(20,12,8,0.7)'); R_(c, -1, -0.12, 1.5, 0.24, '#e8dcc0'); c.fillStyle = '#f4f7fb'; c.beginPath(); c.moveTo(0.5, -0.3); c.lineTo(1.25, 0); c.lineTo(0.5, 0.3); c.fill(); R_(c, -1.05, -0.3, 0.35, 0.25, '#c04a3a'); R_(c, -1.05, 0.05, 0.35, 0.25, '#c04a3a'); c.restore(); }
      else { c.globalAlpha = (1 - (age - f.d) / 0.15) * 0.8; R_(c, a1[0] - 0.25, a1[1] - 0.25, 0.5, 0.5, '#fff'); R_(c, a1[0] - 0.7, a1[1], 0.3, 0.3, '#ffd870'); R_(c, a1[0] + 0.4, a1[1] - 0.5, 0.3, 0.3, '#ffd870'); c.globalAlpha = 1; }
    } else if (f.k === 'rock') {
      if (age > f.d + 0.5 || (!visibleAt(S, f.x1, f.y1) && !visibleAt(S, f.x0, f.y0))) continue; const p = Math.min(1, age / f.d), ah = 9, x = (f.x0 + (f.x1 - f.x0) * p) * TS, gy = (f.y0 + (f.y1 - f.y0) * p) * TS, y = gy - 2 - Math.sin(Math.PI * p) * ah;
      if (p < 1) { R_(c, x - 0.5, gy - 0.2, 1, 0.4, 'rgba(0,0,0,0.3)'); R_(c, x - 0.6, y - 0.6, 1.2, 1.2, '#6a6e78'); R_(c, x - 0.35, y - 0.5, 0.6, 0.6, '#a0a4ac'); }
      else { const q = (age - f.d) / 0.5; c.globalAlpha = (1 - q) * 0.8; for (let k = 0; k < 6; k++) R_(c, x + Math.cos(k * 1.05) * q * 2.4 - 0.3, gy + Math.sin(k * 1.05) * q * 1.2 - q * 1.6, 0.6, 0.6, k % 2 ? '#8a8272' : '#d8cfae'); c.globalAlpha = 1; }
    } else if (f.k === 'bash') {
      if (age < 0.45 && visibleAt(S, f.x, f.y)) { const q = age / 0.45, x = f.x * TS, y = f.y * TS; c.globalAlpha = (1 - q) * 0.8; for (let k = 0; k < 5; k++) R_(c, x + Math.cos(k * 1.3 + f.t * 3) * q * 1.8, y + Math.sin(k * 1.3 + f.t * 3) * q * 1.2 - q * 1.2, 0.45, 0.45, k % 2 ? '#b8b0a0' : '#8a5a2b'); R_(c, x - 0.6, y - 0.6, 1.2, 0.3, '#fff'); c.globalAlpha = 1; }
    } else if (f.k === 'rubble') {
      if (age < 25 && visibleAt(S, f.x, f.y)) { c.globalAlpha = Math.max(0, 1 - age / 25) * 0.9; const x = f.x * TS, y = f.y * TS; for (let k = 0; k < 7; k++) R_(c, x - 6 + hash(Math.floor(f.x), Math.floor(f.y), k) * 12, y - 3 + hash(Math.floor(f.x), Math.floor(f.y), k + 7) * 8, 1.6, 1.2, k % 2 ? '#8a8272' : '#6a6458'); c.globalAlpha = 1; }
    } else if (f.k === 'rip') { if (age < 9 && visibleAt(S, f.x, f.y)) { c.globalAlpha = Math.max(0, 1 - age / 9) * 0.7; const x = f.x * TS, y = f.y * TS; R_(c, x - 1.1, y - 0.3, 2.2, 0.6, '#3a1a1a'); R_(c, x - 0.9, y - 0.5, 1.8, 0.5, '#7a2a2a'); R_(c, x + 0.7, y - 0.7, 0.35, 0.35, '#d8d0c0'); c.globalAlpha = 1; }
    } else if (f.k === 'hit' && age < 0.22 && visibleAt(S, f.x, f.y)) {
      const q = age / 0.22, x = f.x * TS, y = f.y * TS - 2.2; c.globalAlpha = (1 - q) * 0.85; c.strokeStyle = '#fff'; c.lineWidth = 0.3; c.beginPath(); c.moveTo(x - 0.8, y - 0.8); c.lineTo(x + 0.8, y + 0.8); c.moveTo(x + 0.8, y - 0.8); c.lineTo(x - 0.8, y + 0.8); c.stroke();
      for (let k = 0; k < 3; k++) R_(c, x + Math.cos(k * 1.9 + f.t * 7) * q * 1.8, y + Math.sin(k * 1.9 + f.t * 7) * q * 1.3 - q * 0.5, 0.35, 0.35, k % 2 ? '#ffc850' : '#fff'); c.globalAlpha = 1;
    }
  }
  };
  { for (const a of S.armies) if (!a.ship && a.fight && a.ft && canSee(S, a)) { const mx = (a.x + a.ft.x) / 2 * TS, my = (a.y + a.ft.y) / 2 * TS; dust(c, mx, my, tm, a.id); } fxPass(false); }
  // обучение: бойцы выходят из казарм по одному и строятся
  for (const b of S.buildings) {
    if (b.type !== 'barracks' || !b.queue.length || !canSee(S, { owner: b.owner, x: b.x, y: b.y })) continue;
    const q = b.queue[0], T = q.total || SQ[q.t].t, prog = Math.max(0, Math.min(1, 1 - q.left / T)), col = ownerCol(S, b.owner), rp = rallyPos(S, b), cnt = SQ[q.t].cnt || 10, fm = formSlots(cnt), p10 = prog * cnt, doorX = (b.x + 0.5) * TS, doorY = (b.y + 0.95) * TS;
    for (let i = 0; i < cnt && i < fm.f.length; i++) {
      if (p10 < i) continue; const pr = Math.min(1, (p10 - i) / 0.55), e = 1 - (1 - pr) * (1 - pr), tx = rp.x * TS + fm.f[i].ox, ty = rp.y * TS + fm.f[i].oy;
      const fx = doorX + (tx - doorX) * e, fy = doorY + (ty - doorY) * e, walk = pr < 1, by = walk ? -Math.abs(Math.sin(tm * 9 + i * 1.7)) * 0.5 : 0;
      drawFig(c, q.t, col, fx, fy + by, tx >= doorX ? 1 : -1);
    }
  }
  // армии: каждый боец живёт отдельно (в бою — собственные позиции, вне боя — строй)
  for (const a of S.armies) {
    if (a.ship || !canSee(S, a)) continue;
    if (a.x < vx0 - 4 || a.x > vx1 + 4 || a.y < vy0 - 4 || a.y > vy1 + 4) { a._off = true; continue; }   // вне экрана не рисуем
    if (a._off) { a._off = false; for (const q of a.sq) for (const s0 of q.s) { s0._dx = undefined; s0._tx = undefined; } }   // вернулись в кадр: бойцы встают на место без «пролёта» через карту
    const col = ownerCol(S, a.owner), x = a.x * TS, y = a.y * TS, list = armySoldiers(a), fm = formSlots(Math.max(1, list.length)), moving = a.st === 'move' && a.path.length && !a.fight;
    if (sel && sel.k === 'army' && sel.id === a.id) { c.strokeStyle = Math.floor(tm * 3) % 2 ? '#fff' : '#ffe27a'; c.lineWidth = 0.5; c.beginPath(); c.ellipse(x, y, fm.w / 2 + 2.5, fm.h / 2 + 2.2, 0, 0, 6.3); c.stroke(); }
    const draw = [];
    for (let i = 0; i < list.length; i++) {
      const e = list[i], s2 = e.s, sl = fm.f[i], inB = s2.x !== undefined; let dx = inB ? s2.x * TS : x + sl.ox, dy = inB ? s2.y * TS : y + sl.oy;
      if (!inB && S.structs.length && structBlockedAt(S, a.owner, dx / TS, dy / TS)) { for (const f of [0.66, 0.33, 0]) { const tx = x + sl.ox * f, ty = y + sl.oy * f; dx = tx; dy = ty; if (!structBlockedAt(S, a.owner, tx / TS, ty / TS)) break; } }   // между стенами строй сжимается в колонну
      if (a.born != null && a.from) { const ag = rtOf(S) - a.born, du = a.bdur || 0.85; if (ag < du + list.length * 0.09 + 0.1) { const pr = Math.max(0, Math.min(1, (ag - i * 0.09) / du)); if (pr <= 0) continue; const ez = 1 - (1 - pr) * (1 - pr), fx0 = a.from.x * TS, fy0 = a.from.y * TS; s2._dx = fx0 + (dx - fx0) * ez; s2._dy = fy0 + (dy - fy0) * ez; draw.push({ e, s: s2, inB, walk: pr < 1, i }); continue; } }
      if (s2._dx === undefined) { s2._dx = dx; s2._dy = dy; s2._tx = undefined; }
      if (s2._tx === undefined || Math.abs(dx - s2._tx) > 1e-4 || Math.abs(dy - s2._ty) > 1e-4) { s2._ox = s2._dx; s2._oy = s2._dy; s2._tx = dx; s2._ty = dy; s2._tt = now; }   // пришёл новый тик: плывём к новой точке
      const q = Math.min(1, (now - s2._tt) / RN.tickMs); s2._dx = s2._ox + (s2._tx - s2._ox) * q; s2._dy = s2._oy + (s2._ty - s2._oy) * q;
      draw.push({ e, s: s2, inB, walk: moving || (Math.hypot(s2._tx - s2._ox, s2._ty - s2._oy) > 0.3 && now - s2._tt < RN.tickMs * 1.6), i });
    }
    draw.sort((p, q) => p.s._dy - q.s._dy);
    for (const d of draw) {
      const s2 = d.s, face = d.inB ? (s2.face || 1) : (a.face || 1); let fx = s2._dx, fy = s2._dy, by = d.walk ? -Math.abs(Math.sin(tm * 9 + d.i * 1.7)) * 0.45 : 0, an = null;
      if (d.inB) {
        const kd = cfKind(d.e.t, d.e.cls), ts = s2.shot !== undefined ? rtOf(S) - s2.shot : 9, hs = s2.hurt !== undefined ? rtOf(S) - s2.hurt : 9;
        if (kd) an = { pose: cfPose(S, s2, kd), flash: hs < 0.14 ? 1 - hs / 0.14 : 0 }; else if (hs < 0.14) an = { flash: 1 - hs / 0.14 };
        if (kd === 'archer') { if (ts < 0.16) fx -= face * Math.sin(ts / 0.16 * Math.PI) * 0.4; }
        else if (kd && ts < 0.24) { fx += face * Math.sin(ts / 0.24 * Math.PI) * (kd === 'cav' ? 1.5 : 0.9); by -= 0.12; }   // выпад вместе с ударом
        if (hs < 0.16) fx -= face * Math.sin(hs / 0.16 * Math.PI) * 0.45;   // удар отбрасывает назад
      }
      drawFig(c, d.e.t, col, fx, fy + by, face, d.e.cls, an);
      if (d.e.t === 'cmd') { c.save(); c.globalAlpha = 0.5 + 0.25 * Math.sin(tm * 3); c.strokeStyle = '#ffe27a'; c.lineWidth = 0.5; c.beginPath(); c.ellipse(fx, fy + 0.4, 2.8, 1.1, 0, 0, 6.3); c.stroke(); if (sel && sel.k === 'army' && sel.id === a.id) { c.globalAlpha = 0.45; c.setLineDash([2, 2]); c.lineWidth = 0.6; c.beginPath(); c.ellipse(fx, fy, AURA_R * TS, AURA_R * TS * 0.8, 0, 0, 6.3); c.stroke(); } c.restore(); }
      const mh = SQ[d.e.t].hp; if (s2.hp < mh * 0.98) { R_(c, fx - 1.5, fy - 4.6, 3, 0.55, '#14100c'); R_(c, fx - 1.4, fy - 4.5, 2.8 * Math.max(0, s2.hp / mh), 0.35, s2.hp / mh > 0.5 ? '#7dff7d' : s2.hp / mh > 0.25 ? '#ffd24a' : '#ff6a4a'); }
    }
    const bx = x - fm.w / 2 - 1.8; R_(c, bx, y - fm.h / 2 - 3.5, 0.4, 5.5, '#5a3a1a'); c.save(); c.translate(bx + 0.4, y - fm.h / 2 - 3.4); c.scale(0.55, 0.55); waveFlag(c, 0, 0, col, tm, a.id); c.restore();
    const f = Math.max(0.05, units(a) / a.maxU), by2 = y + fm.h / 2 + 1.6; R_(c, x - fm.w / 2 - 0.5, by2, fm.w + 1, 1.1, '#14100c'); R_(c, x - fm.w / 2 - 0.2, by2 + 0.3, (fm.w + 0.4) * f, 0.5, a.owner === VP ? '#7dff7d' : '#ff7d7d');
  }
  fxPass(true);   // летящие стрелы и ядра — поверх войск
  // выбранный город/здание
  if (sel && (sel.k === 'city')) { const ct = S.cities[sel.id]; if (ct) selBox(c, cityOX(ct) - 2, cityOY(ct) - 2, 68, 68, tm); }
  if (sel && sel.k === 'bld') { const b = S.buildings.find(q => q.id === sel.id); if (b) selBox(c, b.x * TS - 1, b.y * TS - 1, 18, 18, tm); }
  // призрак постройки (для стен и рва — линия)
  if (pl && pl.x != null) {
    const col = S.players[VP].col, line = (pl.type === 'wall' || pl.type === 'moat') && pl.x2 != null ? lineTiles(pl.x, pl.y, pl.x2, pl.y2) : [{ x: pl.x, y: pl.y }];
    for (const t of line) {
      const ok = !siteOk(S, VP, pl.type, t.x, t.y); c.globalAlpha = 0.8;
      if (pl.type === 'village') drawSpr(c, groundSprite(S, { x: t.x, y: t.y, level: 0, vs: 0 }), (t.x - 1) * TS, (t.y - 1) * TS), drawSpr(c, citySprite({ level: 0, isCap: false, vs: 0 }, col), (t.x - 1) * TS, (t.y - 1) * TS - CITY_PAD * 0.5);
      else if (pl.type === 'moat') c.drawImage(moatSprite(15, 1), t.x * TS, t.y * TS, TS, TS);
      else drawSpr(c, bldSprite({ type: pl.type, res: S.res[t.y * S.W + t.x] }, col, STRUCT[pl.type] ? (pl.type === 'tower' ? 0 : (line.length > 1 ? (Math.abs(pl.x2 - pl.x) >= Math.abs(pl.y2 - pl.y) ? 10 : 5) : 10)) : 0), t.x * TS, t.y * TS);
      c.globalAlpha = 1; c.strokeStyle = ok ? '#7dff7d' : '#ff5a4a'; c.lineWidth = 0.8; const sz = pl.type === 'village' ? 64 : 16, o0 = pl.type === 'village' ? TS : 0; c.strokeRect(t.x * TS - o0 + 0.5, t.y * TS - o0 + 0.5, sz - 1, sz - 1);
      if (pl.type === 'village') { c.save(); c.globalAlpha = 0.12; c.fillStyle = '#fff'; c.beginPath(); c.ellipse((t.x + 1) * TS, (t.y + 1) * TS, 3.6 * TS, 3.6 * TS, 0, 0, 6.3); c.fill(); c.globalAlpha = 0.9; c.setLineDash([2, 2]); c.strokeStyle = '#fff'; c.lineWidth = 0.7; c.stroke(); c.restore(); }
    }
  }
  // облака
  const cw = S.W * TS, off = (tm * 2.5) % cw; c.drawImage(RN.cloud, off, 0, cw, S.H * TS); c.drawImage(RN.cloud, off - cw, 0, cw, S.H * TS);
  { // смена времени суток (плавно)
    const tn = nightLift(todTint(todHours(S))), dark = Math.max(0, Math.min(1, (255 - tn[1]) / 150));
    RN.tint = [tn[0] * 0.98 / 255, tn[1] * 0.95 / 255, tn[2] * 0.9 / 255];
    if (!RN.glGrade) { // приглушённые, «выцветшие» средневековые краски + тёплый тон + время суток (если работает шейдерный слой, то это делает он: два полноэкранных наложения на 2D-холсте дорогие)
      c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.globalCompositeOperation = 'saturation'; c.globalAlpha = 0.36; c.fillStyle = '#808080'; c.fillRect(0, 0, RN.cv.width, RN.cv.height);
      c.globalAlpha = 1; c.globalCompositeOperation = 'multiply'; c.fillStyle = `rgb(${tn[0] * 0.98 | 0},${tn[1] * 0.95 | 0},${tn[2] * 0.9 | 0})`; c.fillRect(0, 0, RN.cv.width, RN.cv.height); c.restore(); c.imageSmoothingEnabled = false;
    }
    if (dark > 0.12) { c.globalAlpha = Math.min(1, dark * 1.3);
      nightGlowPass(c, S, dark, vx0, vx1, vy0, vy1); c.globalAlpha = Math.min(1, dark * 1.3);
      for (const ct of S.cities) { if (ct.x < vx0 - 4 || ct.x > vx1 + 2 || ct.y < vy0 - 4 || ct.y > vy1 + 2) continue; const ox = cityOX(ct), oy = cityOY(ct), pl2 = townPlan(ct.level, ct.isCap, ct.vs | 0, ct.hx | 0); for (const L of pl2.lights) { R_(c, ox + L[0] * 0.5, oy + L[1] * 0.5, 1, 1, '#ffd870'); R_(c, ox + L[0] * 0.5 + 0.5, oy + L[1] * 0.5, 0.5, 1, '#ffb850'); } }
      for (const b of S.buildings) { if (b.x < vx0 - 1 || b.x > vx1 || b.y < vy0 - 1 || b.y > vy1) continue; if (b.type === 'forge' && !(b.cons > 0)) { c.globalAlpha = dark * 0.35; R_(c, b.x * TS - 2, b.y * TS + 3, 14, 12, '#ff9a3a'); c.globalAlpha = Math.min(1, dark * 1.3); } else if (LIT_BLD[b.type] && !(b.cons > 0)) { R_(c, b.x * TS + 6.5, b.y * TS + 9, 1.5, 2, '#ffd870'); R_(c, b.x * TS + 9, b.y * TS + 9, 1.5, 2, '#ffb850'); } }
      c.globalAlpha = 1; }
  }
  if (typeof MODS_draw === 'function') MODS_draw(c, S, vx0, vx1, vy0, vy1);
  if (typeof gxDrawFigures === 'function') gxDrawFigures(c, S, vx0, vx1, vy0, vy1);   // petugas dan keluarga kerajaan terlihat sebagai sosok
  // значки армий (экранное пространство, постоянный размер)
  c.setTransform(RN.dpr, 0, 0, RN.dpr, 0, 0); c.imageSmoothingEnabled = false;
  for (const g of armyClusters(S)) {
    const m = markerPos(g, cam); if (m.x < -20 || m.tip < -30 || m.x > RN.w + 20 || m.tip > RN.h + 40) continue;
    const col = ownerCol(S, g.owner), selG = sel && sel.k === 'army' && g.list.some(q => q.id === sel.id), fight = g.list.some(q => q.fight), bounce = selG ? Math.abs(Math.sin(tm * 6)) * 3 : 0;
    c.globalAlpha = 0.5; R_(c, m.x - 6, m.tip + 1, 12, 2, '#000'); c.globalAlpha = 1;
    c.drawImage(markerCanvas(fight ? '#ff3a2a' : col), m.x - 11, m.tip - 26 - bounce, 22, 26);
    const cnt = g.list.length > 1 ? 'x' + g.list.length : String(g.sq); const nb = g.list.length > 1 ? String(g.list.length) : String(g.sq);
    c.save(); c.translate(m.x + 5, m.tip - 31 - bounce); c.fillStyle = '#14100c'; c.fillRect(-1, -1, numW(nb) * 2 + 4, 13); c.fillStyle = g.list.length > 1 ? '#f2c230' : '#fff'; c.scale(2, 2); drawNum(c, nb, 0.5, 0, g.list.length > 1 ? '#f2c230' : '#fff'); c.restore();
    if (selG) { c.strokeStyle = '#ffe27a'; c.lineWidth = 2; c.strokeRect(m.x - 12, m.tip - 27 - bounce, 24, 28); }
  }
  // подписи городов (экранное пространство)
  c.setTransform(RN.dpr, 0, 0, RN.dpr, 0, 0); c.font = "16px PixelRU, monospace, 'Noto Sans CJK SC', 'Noto Sans CJK JP', 'Noto Sans', sans-serif"; c.textAlign = 'center'; c.textBaseline = 'middle';
  if (cam.z >= 2) for (const ct of S.cities) {
    const sx = (ct.x * TS + 16 - cam.x) * cam.z, sy = (cityOY(ct) - (ct.level === 0 ? 4 : 12) - cam.y) * cam.z; if (sx < -80 || sy < -30 || sx > RN.w + 80 || sy > RN.h + 30) continue;
    const nm = ct.name + (ct.isCap ? ' ★' : ''); c.lineWidth = 4; c.strokeStyle = '#14100c'; c.strokeText(nm, sx, sy); c.fillStyle = ownerCol(S, ct.owner) === '#9a9a9a' ? '#ddd' : '#fff'; c.fillText(nm, sx, sy);
  }
}
function armyClusters(S) {
  const cl = [], used = new Set();
  for (const a of S.armies) { if (a.ship || used.has(a.id) || !canSee(S, a)) continue; const g = { owner: a.owner, list: [a] }; used.add(a.id);
    for (const b of S.armies) if (!b.ship && !used.has(b.id) && b.owner === a.owner && canSee(S, b) && dist(a.x, a.y, b.x, b.y) < 0.9) { g.list.push(b); used.add(b.id); }
    g.x = g.list.reduce((s2, q) => s2 + q.x, 0) / g.list.length; g.y = g.list.reduce((s2, q) => s2 + q.y, 0) / g.list.length; g.sq = g.list.reduce((s2, q) => s2 + q.sq.length, 0); cl.push(g); }
  return cl;
}
const MK = {};
function markerCanvas(col) {
  if (MK[col]) return MK[col]; const rows = ['.KKKKKKKKK.', 'KtttttttttK', 'KTTTTTTTTTK', 'KTTWTTTWTTK', 'KTTTWTWTTTK', 'KTTTTWTTTTK', 'KTTTWTWTTTK', 'KTTWTTTWTTK', 'KTTTTTTTTTK', '.KTTTTTTTK.', '..KTTTTTK..', '...KTTTK...', '....KKK....'];
  const c = newCv(11, 13), x = c.getContext('2d'); rows.forEach((r, j) => { for (let i = 0; i < 11; i++) { const ch = r[i]; if (ch === '.') continue; x.fillStyle = ch === 'K' ? '#14100c' : ch === 'W' ? '#fff' : ch === 't' ? shadeC(col, 1.4) : col; x.fillRect(i, j, 1, 1); } }); return MK[col] = c;
}
function markerPos(g, cam) { return { x: (g.x * TS - cam.x) * cam.z, tip: (g.y * TS - 7 - cam.y) * cam.z - 2 }; }
function markerHit(S, tx, ty) { // тап по значку армии
  const cam = RN.cam; let best = null, bd = 1e9;
  for (const g of armyClusters(S)) { const m = markerPos(g, cam), cx = m.x, cy = m.tip - 14, px = (tx * TS - cam.x) * cam.z, py = (ty * TS - cam.y) * cam.z, d = Math.max(Math.abs(px - cx), Math.abs(py - cy)); if (d < 17 && d < bd) { bd = d; best = g; } }
  return best;
}
function animCity(c, ct, col, tm) {
  const ox = cityOX(ct), oy = cityOY(ct), H = 0.5, sd = ct.id * 1.7, p = townPlan(ct.level, ct.isCap, ct.vs | 0, ct.hx | 0);
  p.flags.forEach((f, i) => waveFlag(c, ox + (f[0] + 1) * H, oy + f[1] * H, col, tm, sd + i));
  p.smoke.forEach((m, i) => smoke(c, ox + (m[0] + 1) * H, oy + m[1] * H, tm, sd + i * 2.3, 0.7));
}
const FIGC = {};
function figSprite(t, col, cls, nw) { const k = t + col + (cls || '') + (nw ? '~' : ''); return FIGC[k] || (FIGC[k] = makeFig(t, col, cls, nw)); }
/* ===== Анимация боя (v1.29.0): оружие рисуется отдельно от фигуры и двигается =====
   Лучник: натягивает тетиву, выпускает стрелу, тетива дрожит. Меченосец: замах, рубящий удар с дугой, возврат.
   Всадник: опускает копьё и колет. Ополченец: колет вилами. Получивший удар вспыхивает и отшатывается. */
const CF_EASE = q => 1 - (1 - q) * (1 - q), CF_LERP = (a, b, q) => a + (b - a) * q, CF_CL = (q, a, b) => q < a ? a : q > b ? b : q;
// смещение холста спрайта: локальные координаты фигуры -> пиксели спрайта
const CF_OFF = (t, cls) => (t === 'cav' || (t === 'cmd' && cls === 'cav')) ? [6, 17] : t === 'cmd' ? [3, 8] : [3, 3];
function cfKind(t, cls) { const k = t === 'cmd' ? (cls || 'light') : t; return (k === 'light' || k === 'heavy' || k === 'archer' || k === 'cav' || k === 'militia') ? k : null; }
const rtOf = S => RN.rt !== undefined ? RN.rt : S.time;
function cfPose(S, s, kind) {   // фаза боя бойца: pull (0..1 натяжение), ang (угол оружия), trail (дуга), thr (выпад)
  const T_ = rtOf(S), fighting = T_ - (s.atk || -9) < 0.45, ts = s.shot !== undefined ? T_ - s.shot : 9, per = s.per || 0.9, rem = (s.cd || 0) - T_;
  if (kind === 'archer') {
    if (!fighting) return { pull: 0.12, rel: 0 };
    if (ts < 0.16) return { pull: 0, rel: 1 - ts / 0.16 };
    return { pull: CF_EASE(CF_CL((ts - 0.16) / Math.max(0.3, per - 0.2), 0, 1)), rel: 0 };
  }
  const rest = kind === 'cav' ? -1.2 : -1.45, wind = kind === 'cav' ? -1.55 : -2.55, strike = kind === 'cav' || kind === 'militia' ? -0.1 : 0.75;
  if (!fighting) return { ang: rest, trail: 0, thr: 0 };
  if (ts < 0.2) { const q = CF_EASE(ts / 0.2); return { ang: CF_LERP(wind, strike, q), trail: q < 0.95 ? 1 - Math.abs(q - 0.5) * 1.2 : 0.2, thr: Math.sin(q * Math.PI * 0.5) * (kind === 'cav' || kind === 'militia' ? 1 : 0.35), q }; }
  let a = ts < 0.5 ? CF_LERP(strike, rest, (ts - 0.2) / 0.3) : rest;
  if (rem < 0.26) a = CF_LERP(a, wind, CF_EASE(1 - rem / 0.26));
  return { ang: a, trail: 0, thr: 0 };
}
function cfOutlined(c, f) { c.strokeStyle = '#1a120c'; c.lineJoin = 'round'; c.lineCap = 'round'; f(true); f(false); }
function cfSword(c, hx, hy, ang, len, wide, trail, q, a0, a1) {
  if (trail > 0.05) {   // след от удара: светлая дуга за остриём
    c.save(); c.translate(hx, hy); c.globalAlpha = Math.min(0.5, trail * 0.55); c.strokeStyle = '#f4f8ff'; c.lineCap = 'round';
    for (let k = 0; k < 3; k++) { c.lineWidth = 1.0 - k * 0.3; c.globalAlpha = Math.min(0.5, trail * 0.6) * (1 - k * 0.3); c.beginPath(); c.arc(0, 0, len * (0.98 - k * 0.1), Math.max(a0, ang - 0.9 * (q || 1)), ang, false); c.stroke(); }
    c.restore();
  }
  c.save(); c.translate(hx, hy); c.rotate(ang);
  const w = wide ? 2.6 : 2.0;
  c.fillStyle = '#1a120c'; c.fillRect(-3.8, -w / 2 - 1.1, 3.8 + len + 1.4, w + 2.2); c.fillRect(-0.3, -3.5, 2.4, 7);
  c.fillStyle = '#4a2e14'; c.fillRect(-3, -0.7, 3.2, 1.4); c.fillStyle = '#f2c230'; c.fillRect(-3.4, -1, 0.9, 2);                     // рукоять и навершие
  c.fillStyle = '#f2c230'; c.fillRect(0, -2.6, 1.6, 5.2); c.fillStyle = '#fff0a0'; c.fillRect(0, -2.6, 0.7, 5.2);                   // гарда
  c.fillStyle = '#b9c3d1'; c.fillRect(1.6, -w / 2, len - 1.6, w); c.fillStyle = '#e4ebf3'; c.fillRect(1.6, -w / 2, len - 1.6, w * 0.4); c.fillStyle = '#8791a2'; c.fillRect(1.6, w * 0.22, len - 1.6, w * 0.28);   // клинок
  c.fillStyle = '#e4ebf3'; c.beginPath(); c.moveTo(len, -w / 2); c.lineTo(len + 1.6, 0); c.lineTo(len, w / 2); c.fill();
  c.restore();
}
function cfLance(c, hx, hy, ang, thr, col, kind) {
  const len = kind === 'militia' ? 15 : 19, ext = thr * (kind === 'militia' ? 2.2 : 3.2);
  c.save(); c.translate(hx, hy); c.rotate(ang); c.translate(ext, 0);
  c.fillStyle = '#1a120c'; c.fillRect(-7, -1.5, len + 7 + (kind === 'militia' ? 1 : 3.4), 3);
  c.fillStyle = '#a8743a'; c.fillRect(-6.3, -0.8, len + 6.3, 1.6); c.fillStyle = '#c9965a'; c.fillRect(-6.3, -0.8, len + 6.3, 0.6);
  if (kind === 'militia') {
    c.fillStyle = '#1a120c'; c.fillRect(len - 0.6, -3.2, 3.2, 6.4); c.fillStyle = '#c8ced8'; c.fillRect(len, -2.4, 2.2, 0.8); c.fillRect(len, -0.4, 2.8, 0.8); c.fillRect(len, 1.6, 2.2, 0.8); c.fillStyle = '#9aa0aa'; c.fillRect(len - 0.4, -2.4, 0.9, 4.8);
  } else {
    c.fillStyle = '#cfd6e0'; c.beginPath(); c.moveTo(len, -1.1); c.lineTo(len + 3.2, 0); c.lineTo(len, 1.1); c.fill(); c.fillStyle = '#f4f7fb'; c.fillRect(len, -1.1, 1.6, 0.5);
    c.fillStyle = col; c.fillRect(len - 5.2, 0.8, 5, 3 + 0.6 * Math.sin(ang * 5 + len)); c.fillStyle = '#ffffff55'; c.fillRect(len - 5.2, 0.8, 5, 0.7);
  }
  c.restore();
}
function cfBow(c, p, col) {   // координаты — пиксели спрайта; p = { pull, rel }
  const tipx = 20.2 - 0.7 * p.pull, nx = p.rel > 0 ? tipx + Math.sin(p.rel * 14) * 0.7 * p.rel : 20.2 - 4.6 * p.pull, ty = 3.8, by = 21.4, cx = 2 * 22.8 - tipx;
  // левая рука к луку
  c.fillStyle = '#1a120c'; c.fillRect(19, 9.6, 5.2, 3.6); c.fillStyle = '#2f7a28'; c.fillRect(19.2, 9.9, 1.6, 3); c.fillStyle = '#e8c49a'; c.fillRect(20.6, 10.1, 3.2, 2.6); c.fillStyle = '#f6dcb8'; c.fillRect(20.6, 10.1, 3.2, 0.7);
  // дуга
  cfOutlined(c, o => { c.lineWidth = o ? 3.1 : 1.8; if (!o) c.strokeStyle = '#8a5a2b'; c.beginPath(); c.moveTo(tipx, ty); c.quadraticCurveTo(cx, (ty + by) / 2, tipx, by); c.stroke(); });
  c.strokeStyle = '#c4893f'; c.lineWidth = 0.55; c.beginPath(); c.moveTo(tipx + 0.2, ty + 0.4); c.quadraticCurveTo(cx - 0.4, (ty + by) / 2, tipx + 0.2, by - 0.4); c.stroke();
  c.fillStyle = '#3a2412'; c.fillRect(22.1, 10.9, 1.6, 3.4);   // рукоять лука
  // тетива
  c.strokeStyle = '#f0f0f0'; c.lineWidth = 0.42; c.beginPath(); c.moveTo(tipx, ty); c.lineTo(nx, 12.6); c.lineTo(tipx, by); c.stroke();
  // стрела (пока не выпущена) и правая рука
  const hasArrow = p.rel <= 0;
  if (hasArrow) { const tipA = nx + 8.4; c.fillStyle = '#1a120c'; c.fillRect(nx - 0.9, 12.0, 10.3, 1.9); c.fillStyle = '#d2ac6c'; c.fillRect(nx, 12.4, 8.2, 0.9); c.fillStyle = '#cfd6e0'; c.beginPath(); c.moveTo(tipA - 0.3, 11.7); c.lineTo(tipA + 1.5, 12.85); c.lineTo(tipA - 0.3, 14); c.fill(); c.fillStyle = '#c03030'; c.fillRect(nx, 11.8, 1.8, 0.7); c.fillStyle = '#f0f0f0'; c.fillRect(nx, 13.2, 1.8, 0.7); }
  c.fillStyle = '#1a120c'; c.fillRect(12.2, 11.4, Math.max(1, nx - 12.2) + 2.8, 3.4); c.fillStyle = '#37882e'; c.fillRect(12.5, 11.7, Math.max(1, nx - 12.5) + 0.6, 2.2); c.fillStyle = '#4cae40'; c.fillRect(12.5, 11.7, Math.max(1, nx - 12.5) + 0.6, 0.7);
  c.fillStyle = '#e8c49a'; c.fillRect(nx - 0.2, 11.8, 2.2, 2.1); c.fillStyle = '#c79a72'; c.fillRect(nx - 0.2, 13.4, 2.2, 0.5);
}
function drawFig(c, t, col, fx, fy, face, cls, an) {
  const kind = an ? cfKind(t, cls) : null, sp = figSprite(t, col, cls, !!kind), k = sp._k;
  c.save(); c.translate(fx, fy); c.scale(face, 1); c.imageSmoothingEnabled = RN.cam.z * RN.dpr * k < 1.2; c.imageSmoothingQuality = 'high';
  c.translate(-sp.width * k / 2, -sp._feet * k); c.drawImage(sp, 0, 0, sp.width * k, sp.height * k);
  if (an && an.flash > 0) { c.globalCompositeOperation = 'lighter'; c.globalAlpha = Math.min(0.6, an.flash * 0.6); c.drawImage(sp, 0, 0, sp.width * k, sp.height * k); c.globalAlpha = 1; c.globalCompositeOperation = 'source-over'; }
  if (kind) {
    c.scale(k, k); const [ox, oy] = CF_OFF(t, cls), p = an.pose; c.translate(ox, oy);
    if (kind === 'archer') cfBow(c, p, col);
    else if (kind === 'light') cfSword(c, 18.4, 12.4, p.ang, 10.5, false, p.trail, p.q, -2.7, 0.9);
    else if (kind === 'heavy') cfSword(c, 20.4, 13.6, p.ang, 13, true, p.trail, p.q, -2.7, 0.9);
    else if (kind === 'cav') cfLance(c, 21, 8, p.ang, p.thr, col, 'cav');
    else cfLance(c, 19.6, 10.6, p.ang, p.thr, col, 'militia');
  }
  c.restore();
}
function drawRoute(c, x0, y0, path, alpha, tm, col) {
  if (!path.length) return; const pts = [[x0 * TS, y0 * TS]]; for (const p of path) pts.push([(p.x + 0.5) * TS, (p.y + 0.5) * TS]);
  c.save(); c.globalAlpha = alpha; c.lineJoin = 'round'; c.lineCap = 'round';
  c.strokeStyle = 'rgba(0,0,0,0.55)'; c.lineWidth = 2.2; c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.stroke();
  c.strokeStyle = col; c.lineWidth = 1.1; c.setLineDash([3, 2]); c.lineDashOffset = -tm * 8; c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.stroke(); c.setLineDash([]);
  // шевроны вдоль пути и наконечник
  let acc = 0; for (let i = 1; i < pts.length; i++) { const dx = pts[i][0] - pts[i - 1][0], dy = pts[i][1] - pts[i - 1][1], l = Math.hypot(dx, dy); acc += l; if (acc >= 28 && i < pts.length - 1) { acc = 0; arrowHead(c, pts[i][0], pts[i][1], Math.atan2(dy, dx), 2.2, col); } }
  const n = pts.length, e = pts[n - 1], pr = pts[Math.max(0, n - 2)]; arrowHead(c, e[0], e[1], Math.atan2(e[1] - pr[1], e[0] - pr[0]), 4.2, col);
  c.restore();
}
function arrowHead(c, x, y, ang, sz, col) { c.save(); c.translate(x, y); c.rotate(ang); c.fillStyle = 'rgba(0,0,0,0.65)'; c.beginPath(); c.moveTo(sz + 0.9, 0); c.lineTo(-sz * 0.6 - 0.5, -sz * 0.9 - 0.7); c.lineTo(-sz * 0.6 - 0.5, sz * 0.9 + 0.7); c.closePath(); c.fill(); c.fillStyle = col; c.beginPath(); c.moveTo(sz, 0); c.lineTo(-sz * 0.6, -sz * 0.8); c.lineTo(-sz * 0.6, sz * 0.8); c.closePath(); c.fill(); c.restore(); }
function dust(c, mx, my, tm, seed) { for (let k = 0; k < 4; k++) { const ph = (tm * 1.4 + k / 4 + seed * 0.3) % 1, sz = 0.5 + ph * 1.1; c.globalAlpha = (1 - ph) * 0.3; R_(c, mx + Math.cos(k * 1.7 + seed) * ph * 2.4 - sz / 2, my + Math.sin(k * 1.7 + seed) * ph * 1.2 - sz / 2 - ph * 0.5, sz, sz * 0.8, '#d8cfae'); } c.globalAlpha = 1; }
const TOD = [[0, 52, 62, 120], [4, 62, 72, 130], [6, 200, 150, 150], [7.5, 255, 226, 190], [9, 255, 255, 255], [17, 255, 255, 255], [18.5, 255, 205, 150], [20, 150, 120, 150], [21.5, 74, 84, 134], [24, 52, 62, 120]];
function todTint(h) { for (let i = 0; i < TOD.length - 1; i++) { const a = TOD[i], b = TOD[i + 1]; if (h >= a[0] && h <= b[0]) { let t = (h - a[0]) / (b[0] - a[0]); t = t * t * (3 - 2 * t); return [a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, a[3] + (b[3] - a[3]) * t]; } } return [255, 255, 255]; }
function selBox(c, x, y, w, h, tm) { c.strokeStyle = Math.floor(tm * 3) % 2 ? '#fff' : '#ffe27a'; c.lineWidth = 1; const l = 4; c.beginPath(); for (const [px, py, dx, dy] of [[x, y, 1, 1], [x + w, y, -1, 1], [x, y + h, 1, -1], [x + w, y + h, -1, -1]]) { c.moveTo(px, py + dy * l); c.lineTo(px, py); c.lineTo(px + dx * l, py); } c.stroke(); }

/* ===== Миникарта ===== */
function drawMinimap(S) {
  const mm = RN.minimap; if (!mm || !S || !RN.terrain) return; const c = mm.getContext('2d'), sz = mm.width; c.imageSmoothingEnabled = false;
  c.drawImage(RN.terrain, 0, 0, sz, sz); if (RN.forestMini) c.drawImage(RN.forestMini, 0, 0, sz, sz); if (RN.showTerr) c.drawImage(RN.terrCv, 0, 0, sz, sz); const k = sz / S.W;
  for (const ct of S.cities) R_(c, ct.x * k - 1, ct.y * k - 1, 4, 4, ownerCol(S, ct.owner));
  for (const a of S.armies) if (!a.ship && canSee(S, a)) R_(c, a.x * k - 1, a.y * k - 1, 3, 3, ownerCol(S, a.owner));
  c.strokeStyle = '#fff'; c.lineWidth = 1; c.strokeRect(RN.cam.x / TS * k, RN.cam.y / TS * k, RN.w / RN.cam.z / TS * k, RN.h / RN.cam.z / TS * k);
}

/* ===== Ввод ===== */
function initInput() {
  const el = RN.cv, ptrs = new Map(); let down = null, pinch = 0;
  const toWorld = (sx, sy) => ({ x: sx / RN.cam.z + RN.cam.x, y: sy / RN.cam.z + RN.cam.y });
  el.addEventListener('pointerdown', e => { el.setPointerCapture(e.pointerId); ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); if (ptrs.size === 1) down = { x: e.clientX, y: e.clientY, t: performance.now(), moved: 0 }; else { down = null; const [a, b] = [...ptrs.values()]; pinch = Math.hypot(a.x - b.x, a.y - b.y); } });
  el.addEventListener('pointermove', e => {
    const p = ptrs.get(e.pointerId); if (!p) return; const dx = e.clientX - p.x, dy = e.clientY - p.y; p.x = e.clientX; p.y = e.clientY;
    if (ptrs.size === 1) { if (down) { down.moved += Math.abs(dx) + Math.abs(dy); } RN.cam.x -= dx / RN.cam.z; RN.cam.y -= dy / RN.cam.z; clampCam(); }
    else if (ptrs.size === 2) { const [a, b] = [...ptrs.values()], d = Math.hypot(a.x - b.x, a.y - b.y), mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2; if (pinch) zoomAt(mx, my, d / pinch); pinch = d; }
  });
  const up = e => {
    const had = ptrs.has(e.pointerId); ptrs.delete(e.pointerId); if (ptrs.size < 2) pinch = 0;
    if (had && down && ptrs.size === 0 && down.moved < 10 && performance.now() - down.t < 450) { const w = toWorld(e.clientX, e.clientY); UI.mapTap(w.x / TS, w.y / TS); }
    if (ptrs.size === 0) down = null;
  };
  el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
  el.addEventListener('wheel', e => { e.preventDefault(); zoomAt(e.clientX, e.clientY, e.deltaY < 0 ? 1.15 : 0.87); }, { passive: false });
}
function zoomAt(sx, sy, f) { const cam = RN.cam, wx = sx / cam.z + cam.x, wy = sy / cam.z + cam.y; cam.z = Math.max(0.3, Math.min(7, cam.z * f)); cam.x = wx - sx / cam.z; cam.y = wy - sy / cam.z; clampCam(); }
