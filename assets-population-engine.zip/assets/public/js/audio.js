'use strict';
/* ===== Звук: всё синтезируется на лету (WebAudio), файлов и интернета не нужно =====
   Три шины: SFX (стройка, бой, интерфейс), AMB (море, ветер, птицы, сверчки), MUS (музыка меню и лобби). */
const nv = k => { const v = typeof localStorage === 'undefined' ? NaN : parseFloat(localStorage.getItem(k)); return isNaN(v) ? 1 : Math.max(0, Math.min(1, v)); };
const SND = {
  ctx: null, bus: {}, noise: null, amb: null, ok: typeof AudioContext !== 'undefined' || typeof webkitAudioContext !== 'undefined',
  sfx: typeof localStorage === 'undefined' || localStorage.getItem('kc_snd') !== '0', mus: typeof localStorage === 'undefined' || localStorage.getItem('kc_mus') !== '0',
  sv: nv('kc_sv'), mv: nv('kc_mv'), scene: 'menu', seen: null, lastFx: 0, cnt: {}, cntT: 0, bt: new Map(), ac: new Map(), cons: new Map(), nextBird: 0, nextGull: 0, nextCricket: 0, nextOwl: 0, ambT: 0, lv: { sea: 0, forest: 0, grass: 0, dark: 0 }, m: null, mTimer: null,
  rnd: (a, b) => a + Math.random() * (b - a),
  /* ---------- запуск (только после касания пользователя) ---------- */
  init() {
    if (this.ctx || !this.ok) return; const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    try { this.ctx = new AC(); } catch (e) { this.ok = false; return; }
    const c = this.ctx, comp = c.createDynamicsCompressor(); comp.threshold.value = -16; comp.ratio.value = 4; comp.connect(c.destination);
    const master = c.createGain(); master.gain.value = 0.9; master.connect(comp);
    for (const k of ['sfx', 'amb', 'mus']) { const g = c.createGain(); g.gain.value = 0; g.connect(master); this.bus[k] = g; }
    const n = c.sampleRate * 2, b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; this.noise = b;
    this.applyVol(); this.buildAmbience();
  },
  unlock() { this.init(); const c = this.ctx; if (c && c.state === 'suspended') { const p = c.resume(); if (p && p.then) p.then(() => this.syncScene()); } this.syncScene(); },
  poll() { if (this.scene === 'menu' && this.mus && !this.mTimer && this.ctx && this.ctx.state === 'running') this.musicStart(); },
  applyVol() { if (!this.ctx) return; const t = this.ctx.currentTime; this.bus.sfx.gain.setTargetAtTime(this.sfx ? 0.85 * this.sv : 0, t, 0.05); this.bus.amb.gain.setTargetAtTime(this.sfx && this.scene === 'game' ? 0.7 * this.sv : 0, t, 0.3); this.bus.mus.gain.setTargetAtTime(this.mus ? 0.5 * this.mv : 0, t, 0.4); this.labels(); },
  setSfx(v) { this.sfx = v; if (typeof localStorage !== 'undefined') localStorage.setItem('kc_snd', v ? '1' : '0'); this.applyVol(); },
  setVol(k, v) { v = Math.max(0, Math.min(1, v)); if (k === 'sfx') this.sv = v; else this.mv = v; if (typeof localStorage !== 'undefined') localStorage.setItem(k === 'sfx' ? 'kc_sv' : 'kc_mv', String(v)); this.applyVol(); },
  setMus(v) { this.mus = v; if (typeof localStorage !== 'undefined') localStorage.setItem('kc_mus', v ? '1' : '0'); this.applyVol(); this.syncScene(); },
  labels() { if (typeof document === 'undefined') return; const a = document.getElementById('bsfx'), b = document.getElementById('bmus'); if (a) a.textContent = 'ЗВУК: ' + (this.sfx ? 'ВКЛ' : 'ВЫКЛ'); if (b) b.textContent = 'МУЗЫКА: ' + (this.mus ? 'ВКЛ' : 'ВЫКЛ'); },
  /* ---------- строительные кирпичики ---------- */
  src(loop) { const s = this.ctx.createBufferSource(); s.buffer = this.noise; s.loop = !!loop; return s; },
  tone(type, f0, f1, t0, dur, vol, dest, att) {
    const c = this.ctx, o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.setValueAtTime(f0, t0); if (f1) o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0); g.gain.linearRampToValueAtTime(vol, t0 + (att || 0.004)); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur); o.connect(g); g.connect(dest); o.start(t0); o.stop(t0 + dur + 0.05);
  },
  hit(t0, dur, vol, ft, f0, q, dest, f1) {
    const c = this.ctx, s = this.src(false), f = c.createBiquadFilter(), g = c.createGain(); f.type = ft; f.frequency.setValueAtTime(f0, t0); if (f1) f.frequency.exponentialRampToValueAtTime(f1, t0 + dur); f.Q.value = q;
    g.gain.setValueAtTime(vol, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur); s.connect(f); f.connect(g); g.connect(dest); s.start(t0, Math.random() * 1.5, dur + 0.05);
  },
  out(vol, pan) { const c = this.ctx, g = c.createGain(); g.gain.value = vol; if (c.createStereoPanner) { const p = c.createStereoPanner(); p.pan.value = pan; g.connect(p); p.connect(this.bus.sfx); } else g.connect(this.bus.sfx); return g; },
  /* ---------- эффекты ---------- */
  FX: {
    hammer(S, d, t) { const k = (t0, v) => { S.hit(t0, 0.05, 0.55 * v, 'bandpass', S.rnd(1900, 2600), 2.5, d); S.tone('sine', 230, 90, t0, 0.09, 0.6 * v, d); }; k(t, 1); if (Math.random() < 0.6) k(t + S.rnd(0.14, 0.22), 0.75); },
    saw(S, d, t) { for (let i = 0; i < 4; i++) S.hit(t + i * 0.09, 0.08, 0.22, 'bandpass', 1400 + (i % 2) * 500, 1.5, d); },
    done(S, d, t) { [523.25, 659.25, 783.99].forEach((f, i) => { S.tone('triangle', f, null, t + i * 0.09, 0.45, 0.32, d, 0.01); S.tone('sine', f * 2, null, t + i * 0.09, 0.3, 0.1, d, 0.01); }); },
    clang(S, d, t) { S.hit(t, 0.07, 0.5, 'highpass', 3500, 0.7, d); const f = S.rnd(1100, 1500); S.tone('square', f, null, t, 0.17, 0.1, d); S.tone('square', f * 1.5, null, t, 0.12, 0.07, d); },
    thud(S, d, t) { S.tone('sine', 150, 55, t, 0.13, 0.7, d); S.hit(t, 0.08, 0.35, 'lowpass', 700, 0.8, d); },
    bow(S, d, t) { S.hit(t, 0.2, 0.22, 'bandpass', 1200, 1.2, d, 3300); },
    arrowHit(S, d, t) { S.tone('triangle', 320, 120, t, 0.07, 0.3, d); },
    launch(S, d, t) { S.hit(t, 0.45, 0.35, 'bandpass', 300, 3, d, 900); S.tone('sine', 190, 70, t, 0.32, 0.5, d); },
    boom(S, d, t) { S.tone('sine', 95, 28, t, 0.65, 0.9, d); S.hit(t, 0.55, 0.6, 'lowpass', 520, 0.7, d, 120); },
    bash(S, d, t) { S.tone('sine', 115, 45, t, 0.22, 0.8, d); S.hit(t, 0.12, 0.4, 'bandpass', 900, 2, d); },
    crash(S, d, t) { S.hit(t, 0.95, 0.7, 'lowpass', 950, 0.6, d, 150); S.tone('sine', 72, 25, t, 0.8, 0.9, d); for (let i = 0; i < 3; i++) S.hit(t + 0.1 + i * 0.17, 0.07, 0.35, 'bandpass', S.rnd(700, 1400), 2.5, d); },
    death(S, d, t) { S.tone('sine', 270, 105, t, 0.28, 0.28, d); S.hit(t, 0.1, 0.2, 'lowpass', 500, 0.8, d); },
    horn(S, d, t) { const c = S.ctx, f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 760; f.connect(d); for (const [fr, v] of [[174.6, 0.4], [261.6, 0.25], [349.2, 0.12]]) { const o = c.createOscillator(), g = c.createGain(); o.type = 'sawtooth'; o.frequency.setValueAtTime(fr * 0.97, t); o.frequency.linearRampToValueAtTime(fr, t + 0.25); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + 0.18); g.gain.setValueAtTime(v, t + 0.8); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.35); o.connect(g); g.connect(f); o.start(t); o.stop(t + 1.4); } },
    ping(S, d, t) { S.tone('sine', 880, null, t, 0.55, 0.22, d, 0.01); S.tone('sine', 1318, null, t + 0.07, 0.5, 0.14, d, 0.01); },
    click(S, d, t) { S.tone('square', 760, 520, t, 0.04, 0.07, d); },
    coin(S, d, t) { S.tone('triangle', 1318, null, t, 0.12, 0.12, d); S.tone('triangle', 1760, null, t + 0.06, 0.25, 0.12, d); },
  },
  /* позиционный звук: громкость и панорама по положению на экране; ограничение числа голосов */
  play(name, x, y, delay, gain) {
    if (!this.ctx || !this.sfx || this.ctx.state !== 'running') return; const c = this.ctx, now = c.currentTime;
    if (now - this.cntT > 0.25) { this.cnt = {}; this.cntT = now; } const lim = { clang: 3, thud: 3, bow: 3, hammer: 3, death: 2, arrowHit: 3 }[name] || 2; this.cnt[name] = (this.cnt[name] || 0) + 1; if (this.cnt[name] > lim) return;
    let vol = gain || 1, pan = 0;
    if (x !== undefined && x !== null && typeof RN !== 'undefined' && RN.cv) {
      const cam = RN.cam, vw = RN.cv.width / RN.dpr / cam.z, vh = RN.cv.height / RN.dpr / cam.z, cx = cam.x + vw / 2, cy = cam.y + vh / 2, px = x * TS, py = y * TS;
      const dd = Math.hypot((px - cx) / (vw * 0.62), (py - cy) / (vh * 0.62)); if (dd >= 1) return;
      vol *= Math.pow(1 - dd, 1.3) * Math.min(1, cam.z / 1.6) + 0.02; pan = Math.max(-0.9, Math.min(0.9, (px - cx) / (vw / 2)));
    }
    if (vol < 0.015) return; const d = this.out(Math.min(1.2, vol), pan); this.FX[name](this, d, now + 0.005 + (delay || 0));
  },
  ui(name) { if (this.ctx && this.sfx && this.ctx.state === 'running') this.FX[name](this, this.out(0.8, 0), this.ctx.currentTime + 0.002); },
  /* ---------- фон: ветер, море, птицы, сверчки ---------- */
  buildAmbience() {
    const c = this.ctx, A = this.amb = {}, mkLoop = (type, f, q, gain) => { const s = this.src(true), fl = c.createBiquadFilter(), g = c.createGain(); fl.type = type; fl.frequency.value = f; fl.Q.value = q; g.gain.value = gain; s.connect(fl); fl.connect(g); g.connect(this.bus.amb); s.start(0, Math.random() * 1.5); return g; };
    A.wind = mkLoop('lowpass', 480, 0.7, 0.05); const wl = c.createOscillator(), wg = c.createGain(); wl.frequency.value = 0.07; wg.gain.value = 0.03; wl.connect(wg); wg.connect(A.wind.gain); wl.start();
    A.sea = mkLoop('bandpass', 420, 0.45, 0); const sl = c.createOscillator(), sg = c.createGain(); sl.frequency.value = 0.11; sg.gain.value = 0; sl.connect(sg); sg.connect(A.sea.gain); sl.start(); A.seaLfo = sg;
    A.foam = mkLoop('highpass', 2600, 0.5, 0); const fl2 = c.createOscillator(), fg = c.createGain(); fl2.frequency.value = 0.13; fg.gain.value = 0; fl2.connect(fg); fg.connect(A.foam.gain); fl2.start(); A.foamLfo = fg;
    /* ночью раньше работал непрерывный генератор 4300 Гц с рубкой 13 Гц — он и давал назойливый высокий звук; теперь тихие редкие сверчки и ухо филина отдельными звуками (см. updateAmbience) */
  },
  chirp(t, pan) {
    const c = this.ctx, g = c.createGain(); g.gain.value = 0.5; const d = c.createStereoPanner ? (() => { const p = c.createStereoPanner(); p.pan.value = pan; g.connect(p); p.connect(this.bus.amb); return g; })() : (g.connect(this.bus.amb), g);
    const base = this.rnd(2600, 4300), n = 2 + ((Math.random() * 3) | 0); for (let i = 0; i < n; i++) this.tone('sine', base * this.rnd(0.9, 1.15), base * this.rnd(1.1, 1.5), t + i * 0.09, 0.07, 0.12, d, 0.01);
  },
  cricket(t, pan) { // тихая короткая трель вместо непрерывного писка
    const c = this.ctx, g = c.createGain(); g.gain.value = 0.35; const d = c.createStereoPanner ? (() => { const p = c.createStereoPanner(); p.pan.value = pan; g.connect(p); p.connect(this.bus.amb); return g; })() : (g.connect(this.bus.amb), g);
    const base = this.rnd(2300, 2900); for (let i = 0; i < 3; i++) this.tone('sine', base, base * 0.96, t + i * 0.085, 0.05, 0.05, d, 0.01);
  },
  owl(t, pan) { // низкое ухание
    const c = this.ctx, g = c.createGain(); g.gain.value = 0.5; const d = c.createStereoPanner ? (() => { const p = c.createStereoPanner(); p.pan.value = pan; g.connect(p); p.connect(this.bus.amb); return g; })() : (g.connect(this.bus.amb), g);
    this.tone('sine', 420, 360, t, 0.32, 0.07, d, 0.06); this.tone('sine', 400, 330, t + 0.5, 0.5, 0.07, d, 0.08);
  },
  gull(t, pan) {
    const c = this.ctx, g = c.createGain(); g.gain.value = 0.5; const d = c.createStereoPanner ? (() => { const p = c.createStereoPanner(); p.pan.value = pan; g.connect(p); p.connect(this.bus.amb); return g; })() : (g.connect(this.bus.amb), g);
    for (let i = 0; i < 2; i++) { this.tone('triangle', 1250, 2000, t + i * 0.34, 0.16, 0.1, d, 0.02); this.tone('triangle', 2000, 1350, t + i * 0.34 + 0.16, 0.2, 0.09, d, 0.01); }
  },
  /* состав вида на экране: море / лес / луга, время суток */
  sample(S) {
    const cam = RN.cam, vw = RN.cv.width / RN.dpr / cam.z, vh = RN.cv.height / RN.dpr / cam.z; let w = 0, f = 0, g = 0, n = 0;
    for (let j = 0; j < 7; j++) for (let i = 0; i < 10; i++) { const tx = Math.floor((cam.x + vw * (i + 0.5) / 10) / TS), ty = Math.floor((cam.y + vh * (j + 0.5) / 7) / TS); n++; if (tx < 0 || ty < 0 || tx >= S.W || ty >= S.H) { w++; continue; } const t = S.ter[ty * S.W + tx]; if (isWater(t)) w++; else if (t === TR.FOREST) f++; else if (t === TR.GRASS || t === TR.PLAIN) g++; }
    const tn = todTint(todHours(S)), dark = Math.max(0, Math.min(1, (255 - tn[1]) / 150)), zf = Math.max(0.15, Math.min(1, cam.z / 1.2)); return { sea: w / n * zf, forest: f / n, grass: g / n, dark, zf };
  },
  updateAmbience(S, dt) {
    this.ambT -= dt; if (this.ambT > 0) return; this.ambT = 0.4; const c = this.ctx, t = c.currentTime, L = this.sample(S), A = this.amb, nowT0 = t;
    A.sea.gain.setTargetAtTime(L.sea * 0.5, t, 0.8); A.seaLfo.gain.setTargetAtTime(L.sea * 0.35, t, 0.8); A.foam.gain.setTargetAtTime(L.sea * 0.05, t, 0.8); A.foamLfo.gain.setTargetAtTime(L.sea * 0.04, t, 0.8);
    A.wind.gain.setTargetAtTime(0.045 + 0.05 * (1 - L.zf), t, 1.2);
    if (L.dark > 0.5 && L.forest + L.grass > 0.08) { if (nowT0 > this.nextCricket) { this.nextCricket = nowT0 + this.rnd(2.5, 7) / Math.max(0.35, L.forest + L.grass); this.cricket(nowT0 + 0.02, this.rnd(-0.7, 0.7)); } if (L.forest > 0.1 && nowT0 > this.nextOwl) { this.nextOwl = nowT0 + this.rnd(16, 34); this.owl(nowT0 + 0.05, this.rnd(-0.6, 0.6)); } }
    const nowT = t; if (L.dark < 0.45 && L.forest + L.grass * 0.6 > 0.06 && nowT > this.nextBird) { this.nextBird = nowT + this.rnd(1.2, 4.5) / Math.max(0.3, L.forest + L.grass * 0.5) * 0.35; this.chirp(nowT + 0.02, this.rnd(-0.8, 0.8)); }
    if (L.sea > 0.06 && nowT > this.nextGull) { this.nextGull = nowT + this.rnd(7, 16); if (Math.random() < 0.8) this.gull(nowT + 0.02, this.rnd(-0.8, 0.8)); }
  },
  /* ---------- события игры ---------- */
  inView(x, y) { if (typeof RN === 'undefined' || !RN.cv) return false; const cam = RN.cam, vw = RN.cv.width / RN.dpr / cam.z, vh = RN.cv.height / RN.dpr / cam.z, px = x * TS, py = y * TS; return px > cam.x - 20 && py > cam.y - 20 && px < cam.x + vw + 20 && py < cam.y + vh + 20; },
  frame(S, now) {
    if (!this.ctx || this.ctx.state !== 'running' || !S) return; const dt = Math.min(0.2, (now - (this.lastNow || now)) / 1000); this.lastNow = now;
    if (this.seen !== S) { this.seen = S; this.lastFx = S.time; this.bt.clear(); this.ac.clear(); this.cons.clear(); if (S.snd) S.snd.length = 0; }
    this.updateAmbience(S, dt);
    // события симуляции
    if (S.snd && S.snd.length) { for (const [k, x, y, o] of S.snd) { if (k === 'done') { if (o === VP || (this.inView(x, y) && visibleAt(S, x, y))) this.play('done', x, y, 0, 1); } else if (k === 'horn') { if (o === VP) this.play('horn', null, null, 0, 0.9); } else if (k === 'msg') { if (o === VP) this.play('ping', null, null, 0, 0.9); } } S.snd.length = 0; }
    // эффекты боя из визуальных событий
    for (const f of S.fx) { if (f.t <= this.lastFx || f.t > S.time + 0.01) continue; const vx = f.x !== undefined ? f.x : f.x0, vy = f.y !== undefined ? f.y : f.y0; if (!this.inView(vx, vy) || !visibleAt(S, vx, vy)) continue;
      if (f.k === 'arr') { this.play('bow', f.x0, f.y0, 0, 0.8); this.play('arrowHit', f.x1, f.y1, f.d || 0.3, 0.7); } else if (f.k === 'rock') { this.play('launch', f.x0, f.y0, 0, 1); this.play('boom', f.x1, f.y1, f.d || 0.9, 1); } else if (f.k === 'bash') this.play('bash', f.x, f.y, 0, 1); else if (f.k === 'rubble') this.play('crash', f.x, f.y, 0, 1); }
    this.lastFx = S.time;
    // рукопашная и потери в армиях, стук молотков на стройках
    for (const a of S.armies) {
      if (a.ship) continue; let n = 0; for (const q of a.sq) n += q.s.length; const prev = this.ac.get(a.id); this.ac.set(a.id, n);
      if (!this.inView(a.x, a.y) || !visibleAt(S, a.x, a.y)) continue;
      if (prev !== undefined && n < prev) this.play('death', a.x, a.y, 0, 0.9);
      if (a.bat) { let t = this.bt.get(a.id) || 0; t -= dt; if (t <= 0) { t = this.rnd(0.22, 0.55); const melee = a.sq.some(q => q.t !== 'archer' && q.t !== 'cat' && q.t !== 'ram'); if (melee) this.play(Math.random() < 0.62 ? 'clang' : 'thud', a.x, a.y, 0, Math.min(1, 0.45 + n / 25)); } this.bt.set(a.id, t); }
    }
    for (const b of S.buildings) if (b.cons > 0 && this.inView(b.x, b.y) && visibleAt(S, b.x, b.y)) { let t = this.cons.get(b.id); if (t === undefined) t = this.rnd(0, 0.8); t -= dt; if (t <= 0) { t = this.rnd(0.7, 1.6); this.play(Math.random() < 0.8 ? 'hammer' : 'saw', b.x + 0.5, b.y + 0.5, 0, 0.9); } this.cons.set(b.id, t); }
    if (this.bt.size > 200) this.bt.clear(); if (this.ac.size > 600) this.ac.clear();
  },
  /* ---------- музыка меню и лобби ---------- */
  syncScene() { const want = this.scene === 'menu' && this.mus; if (want) this.musicStart(); else this.musicStop(); },
  setScene(s) { if (s === this.scene) return; this.scene = s; this.syncScene(); if (this.ctx && this.amb) { const t = this.ctx.currentTime; this.bus.amb.gain.setTargetAtTime(s === 'game' && this.sfx ? 0.7 : 0, t, 0.5); } },
  musicStart() {
    if (!this.ctx || this.mTimer || this.ctx.state !== 'running') return; const c = this.ctx; this.m = { t: c.currentTime + 0.15, i: 0, drone: [] };
    for (const f of [73.42, 110]) { const o = c.createOscillator(), g = c.createGain(), fl = c.createBiquadFilter(); o.type = 'sawtooth'; o.frequency.value = f; fl.type = 'lowpass'; fl.frequency.value = 260; g.gain.setValueAtTime(0.0001, c.currentTime); g.gain.linearRampToValueAtTime(0.05, c.currentTime + 3); o.connect(fl); fl.connect(g); g.connect(this.bus.mus); o.start(); this.m.drone.push([o, g]); }
    this.bus.mus.gain.setTargetAtTime(this.mus ? 0.5 : 0, c.currentTime, 0.4); this.mTimer = setInterval(() => this.musicTick(), 120);
  },
  musicStop() { if (!this.mTimer) return; clearInterval(this.mTimer); this.mTimer = null; const c = this.ctx, m = this.m; this.m = null; if (c && m) for (const [o, g] of m.drone) { try { g.gain.cancelScheduledValues(c.currentTime); g.gain.setTargetAtTime(0, c.currentTime, 0.4); o.stop(c.currentTime + 1.5); } catch (e) {} } },
  musicTick() {
    const c = this.ctx, m = this.m; if (!c || !m) return; if (c.state !== 'running') { m.t = c.currentTime + 0.1; return; }
    const SP = 60 / 92 / 2, D4 = 293.66, nf = s => D4 * Math.pow(2, s / 12), SC = [0, 2, 3, 5, 7, 9, 10, 12];
    const MEL = [[4, -1, 3, 4, 5, -1, 4, 3], [2, -1, 3, 2, 1, -1, 0, -1], [0, 1, 2, -1, 3, 4, 5, -1], [4, 3, 2, 1, 0, -1, -1, -1], [7, -1, 5, 7, 6, -1, 5, 4], [5, -1, 4, 3, 4, -1, 2, -1], [2, 3, 4, -1, 5, 4, 3, 2], [1, 2, 0, -1, 0, -1, -1, -1]];
    const ROOT = [0, 0, -2, 0, 0, 5, -2, 0], THIRD = [3, 3, 4, 3, 3, 4, 4, 3];
    while (m.t < c.currentTime + 0.7) {
      const step = m.i % 64, bar = (step / 8) | 0, k = step % 8, t = m.t, r = ROOT[bar], bus = this.bus.mus;
      const mel = MEL[bar][k]; if (mel >= 0) { let len = 1; while (len < 3 && MEL[bar][(k + len) % 8] === -1 && k + len < 8) len++; this.flute(nf(SC[mel] + ((m.i % 128) >= 64 && Math.random() < 0.0 ? 12 : 0)), t, SP * len * 0.95, 0.2, bus); }
      if (k === 0) this.lute(nf(r - 24), t, 0.34, bus); if (k === 2 || k === 6) this.lute(nf(r - 12 + 7), t, 0.16, bus); if (k === 4) this.lute(nf(r - 12 + THIRD[bar]), t, 0.17, bus); if (k === 3 || k === 7) this.lute(nf(r + (k === 3 ? 0 : 7)), t, 0.1, bus);
      if (k === 0) this.drum(t, 0.4, bus); else if (k === 4) this.drum(t, 0.22, bus); else if (k === 2 || k === 6) this.tick(t, 0.07, bus);
      m.t += SP; m.i++;
    }
  },
  lute(f, t, vol, dest) { const c = this.ctx, o = c.createOscillator(), o2 = c.createOscillator(), g = c.createGain(), fl = c.createBiquadFilter(); o.type = 'triangle'; o2.type = 'sawtooth'; o.frequency.value = f; o2.frequency.value = f; const g2 = c.createGain(); g2.gain.value = 0.28; fl.type = 'lowpass'; fl.frequency.setValueAtTime(Math.min(5000, f * 7), t); fl.frequency.exponentialRampToValueAtTime(Math.max(200, f * 1.6), t + 0.7); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.1); o.connect(g); o2.connect(g2); g2.connect(g); g.connect(fl); fl.connect(dest); o.start(t); o2.start(t); o.stop(t + 1.2); o2.stop(t + 1.2); },
  flute(f, t, dur, vol, dest) { const c = this.ctx, o = c.createOscillator(), g = c.createGain(), lf = c.createOscillator(), lg = c.createGain(); o.type = 'sine'; o.frequency.value = f * 2; lf.frequency.value = 5.2; lg.gain.value = f * 0.012; lf.connect(lg); lg.connect(o.frequency); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + 0.07); g.gain.setValueAtTime(vol * 0.85, t + Math.max(0.08, dur - 0.12)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.12); o.connect(g); g.connect(dest); o.start(t); lf.start(t); o.stop(t + dur + 0.2); lf.stop(t + dur + 0.2); this.hit(t, 0.12, 0.03, 'highpass', 4000, 0.5, dest); },
  drum(t, vol, dest) { this.tone('sine', 120, 55, t, 0.22, vol, dest); this.hit(t, 0.1, vol * 0.25, 'lowpass', 400, 0.7, dest); },
  tick(t, vol, dest) { this.hit(t, 0.03, vol, 'bandpass', 3200, 2, dest); },
};
/* кнопки «Звук» и «Музыка» и звук нажатий; поведение при сворачивании */
if (typeof document !== 'undefined') {
  const un = () => SND.unlock(); for (const ev of ['pointerdown', 'touchstart', 'keydown']) document.addEventListener(ev, un, { passive: true });
  document.addEventListener('click', e => { if (e.target && e.target.closest && e.target.closest('button,[data-act]')) SND.ui('click'); }, true);
  document.addEventListener('visibilitychange', () => { const c = SND.ctx; if (!c) return; if (document.hidden) c.suspend(); else c.resume().then(() => SND.syncScene()); });
  Object.assign(ACT, {
    sfxtoggle() { SND.setSfx(!SND.sfx); if ($('modal') && !$('modal').classList.contains('hidden') && UI.S) showMenuModal(); },
    mustoggle() { SND.setMus(!SND.mus); if ($('modal') && !$('modal').classList.contains('hidden') && UI.S) showMenuModal(); },
  });
  SND.labels();
}
