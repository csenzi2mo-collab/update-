'use strict';
/* ===== Обучение: король Эдвард ведёт игрока по заданиям =====
   Отдельная учебная партия (малая карта, соперник не действует). Каждый шаг — текст короля, подсветка нужной кнопки или
   стрелка на карте и условие выполнения, которое проверяется по состоянию игры (флаги игрока, выбранная панель, камера).
   Шаг можно пропустить, всё обучение — тоже. Повтор: «Как играть» → «Пройти обучение». */

/* ----- учебная партия ----- */
function tutMakeGame() {
  const S = newGame({ type: 'continent', size: 's', bots: 1, diff: 'easy', win: 'score', target: 30000, nation: 0, sandbox: false });
  S.tut = true; const p = S.players[0]; Object.assign(p.stock, { gold: 900, wood: 600, food: 500, iron: 300, bow: 20 });
  if (S.rel[0] && S.rel[0][1]) S.rel[0][1].op = 40;
  const c0 = S.cities.find(c => c.owner === 0), W = S.W, H = S.H, ok = (x, y) => { if (!citySpot(S, x, y)) return false; for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) { const t = S.ter[(y + dy) * W + x + dx]; if (t !== TR.GRASS && t !== TR.PLAIN) return false; } return true; };
  let best = null, bd = 1e9; // вольный город для задания «захват»: 9–14 клеток от столицы, подальше от соперника
  const c1 = S.cities.find(c => c.owner === 1);
  for (let y = 3; y < H - 4; y++) for (let x = 3; x < W - 4; x++) { const d = Math.hypot(x - c0.x, y - c0.y); if (d < 9 || d > 14 || !ok(x, y)) continue; const e = c1 ? Math.hypot(x - c1.x, y - c1.y) : 99, score = d - Math.min(e, 30) * 0.3; if (score < bd) { bd = score; best = { x, y }; } }
  if (best) { clearForest(S, best.x, best.y); const fc = addCity(S, best.x, best.y, -1, 'Вольный город', false, 1); fc.radius = 4; }
  recomputeTerr(S); calcVision(S);
  return S;
}

/* ----- помощники для шагов ----- */
const tutMy = S => S.cities.find(c => c.owner === VP);
const tutOwn = (S, f) => S.buildings.filter(b => b.owner === VP && f(b));
const tutSite = (S, type) => { // ближайшее к столице подходящее место (для стрелки)
  const c = tutMy(S); if (!c) return null; let best = null, bd = 1e9;
  for (let y = Math.max(0, c.y - 14); y < Math.min(S.H, c.y + 16); y++) for (let x = Math.max(0, c.x - 14); x < Math.min(S.W, c.x + 16); x++) { const d = Math.hypot(x - c.x, y - c.y); if (d < bd && !siteOk(S, VP, type, x, y)) { bd = d; best = { x: x + 0.5, y: y + 0.5 }; } }
  return best;
};
const tutHlBuild = (type, tab) => () => UI.tab !== tab ? '#tabs [data-act="tab:' + tab + '"]' : '#bar [data-act="place:' + type + '"]';
const tutCityPt = S => { const c = tutMy(S); return c ? { x: c.x + 1, y: c.y + 1 } : null; };
const tutBldPt = type => S => { const b = tutOwn(S, b => b.type === type)[0]; return b ? { x: b.x + 0.5, y: b.y + 0.5 } : null; };
const tutArmy = S => S.armies.find(a => a.owner === VP && !a.ship);

const TSTEPS = [
  { info: 1, t: 'Приветствую, правитель! Я — король Эдвард. Я научу тебя управлять королевством: выполняй мои задания. Обучение можно пропустить в любой момент.' },
  { t: 'Задание: потяни карту пальцем, чтобы осмотреться.', enter() { const c = RN.cam; TUT.m = { x: c.x, y: c.y, z: c.z }; }, done() { const c = RN.cam, m = TUT.m; return Math.hypot(c.x - m.x, c.y - m.y) * c.z > 60; } },
  { t: 'Задание: разведи два пальца на экране — карта приблизится. Сведи — отдалится.', enter() { TUT.m = { z: RN.cam.z }; }, done() { return Math.abs(RN.cam.z - TUT.m.z) > 0.35; } },
  { info: 1, t: 'Вверху — ресурсы: золото, дерево, еда и железо, рядом — прирост в секунду. Справа — очки, пауза и скорость. Без еды армия слабеет!', hl: () => '#resbar' },
  { t: 'Задание: нажми на свой город — он с флагом твоего цвета. Откроется панель со сведениями.', at: S => tutCityPt(S), done: () => UI.sheet && UI.sheet.k === 'city' },
  { info: 1, t: 'Город приносит золото и расширяет твои границы. Строить можно только внутри границ. Позже город можно улучшить, а новые земли — занять деревнями.' },
  { t: 'Задание: открой вкладку ГРАЖД. внизу экрана — там хозяйственные здания.', hl: () => '#tabs [data-act="tab:build"]', done: () => UI.tab === 'build' },
  { t: 'Задание: выбери ФЕРМУ, нажми на луг рядом с городом и подтверди кнопкой «Построить». Ферма даёт еду.', hl: tutHlBuild('farm', 'build'), at: S => tutSite(S, 'farm'), done: (S, p) => p.flags.b_farm },
  { t: 'Задание: построй ЛЕСОПИЛКУ в лесу — она даёт дерево. Чем гуще лес, тем больше добыча.', hl: tutHlBuild('sawmill', 'build'), at: S => tutSite(S, 'sawmill'), done: (S, p) => p.flags.b_sawmill },
  { t: 'Задание: построй РУДНИК на залежи руды в горах — он даёт золото или железо.', hl: tutHlBuild('mine', 'build'), at: S => tutSite(S, 'mine'), done: (S, p) => p.flags.b_mine },
  { t: 'Здания строятся не сразу. Нажми кнопку скорости вверху — время пойдёт быстрее (x2, x4).', hl: () => '#ctl [data-act="speed"]', done: () => UI.speed > 1 },
  { t: 'Подожди, пока достроится ферма. Нажми на здание на карте — увидишь ход стройки.', at: tutBldPt('farm'), done: S => tutOwn(S, b => b.type === 'farm' && !(b.cons > 0)).length > 0 },
  { t: 'Задание: открой вкладку ВОЕН. и построй КАЗАРМЫ — здесь обучают отряды по 10 воинов.', hl: tutHlBuild('barracks', 'mil'), at: S => tutSite(S, 'barracks'), done: (S, p) => p.flags.b_barracks },
  { t: 'Задание: построй МАСТЕРСКУЮ (вкладка ВОЕН.) — она делает луки для лучников.', hl: tutHlBuild('workshop', 'mil'), at: S => tutSite(S, 'workshop'), done: (S, p) => p.flags.b_workshop },
  { t: 'Задание: нажми на мастерскую на карте — в её панели выбирают, что делать: ЛУКИ.', at: tutBldPt('workshop'), done: S => UI.sheet && UI.sheet.k === 'bld' && (S.bmap.get(UI.sheet.id) || {}).type === 'workshop' },
  { info: 1, t: 'Кузня куёт мечи и доспехи, конюшня выращивает коней. Из оружия получаются отряды: лучники (луки), рыцари (мечи и доспехи), конница (кони). Построишь их позже.' },
  { t: 'Задание: вкладка АРМИЯ → КАЗАРМЫ → нажми казармы и обучи отряд ЛУЧНИКОВ.', hl: () => UI.tab !== 'army' ? '#tabs [data-act="tab:army"]' : '#bar [data-act="barr"]', at: tutBldPt('barracks'), done: (S, p) => p.flags.squad || tutOwn(S, b => b.type === 'barracks' && b.queue && b.queue.length).length > 0 },
  { t: 'Отряд обучается. Если ждать долго, ускорь время кнопкой скорости.', hl: () => '#ctl [data-act="speed"]', at: tutBldPt('barracks'), done: (S, p) => p.flags.squad },
  { t: 'Задание: нажми на значок отряда с флажком у казарм — это твоя армия.', at: S => { const a = tutArmy(S); return a && { x: a.x, y: a.y - 0.6 }; }, done: () => UI.sheet && UI.sheet.k === 'army' },
  { t: 'Задание: теперь нажми на карту — армия пойдёт туда. Путь показывает линия.', enter(S) { const a = tutArmy(S); TUT.m = a ? { id: a.id, x: a.x, y: a.y } : null; }, done: S => { const m = TUT.m; if (!m) return true; const a = S.armies.find(q => q.id === m.id); return !a || Math.hypot(a.x - m.x, a.y - m.y) > 1.5; } },
  { info: 1, t: 'Рядом стоящие отряды можно объединить (ОБЪЕД.) и разделить (РАЗДЕЛ.). Конница бьёт лучников, тяжёлые рыцари — конницу, лучники — лёгких рыцарей.' },
  { t: 'Задание: захвати вольный город (отмечен стрелкой): подведи армию и жди, пока заполнится сетка. Вольный город можно взять без войны.', at: S => { const c = S.cities.find(q => q.owner < 0); return c && { x: c.x + 1, y: c.y + 1 }; }, done: (S, p) => p.flags.capture },
  { t: 'Задание: ГОРОДА → УЛУЧШ. — улучши свой город. Он станет богаче и расширит границы.', hl: () => UI.tab !== 'city' ? '#tabs [data-act="tab:city"]' : '#bar [data-act="upg"]', at: S => tutCityPt(S), done: (S, p) => p.flags.upg },
  { info: 1, t: 'Новые города строить нельзя: ГОРОДА → ДЕРЕВНЯ — поставь деревню на свободной земле у своих границ, потом улучши её до города: вырастут доход и территория.' },
  { info: 1, t: 'У берега строят ПОРТ (вкладка ГРАЖД.): в нём делают торговые и военные корабли. Военный корабль возит армию: выбери армию, нажми на порт, затем укажи берег.' },
  { info: 1, t: 'Укрепления: стены, башни, ворота и рвы (вкладка ВОЕН.). В башню ставят лучников. Осадная мастерская делает катапульты и тараны.' },
  { info: 1, t: 'Королевская академия обучает полководца: рядом с ним войска сильнее. Госпиталь лечит армии и возвращает раненых в строй.' },
  { t: 'Задание: открой вкладку ПОЛИТ. и нажми ДИПЛОМАТ. — там твои соперники.', hl: () => UI.tab !== 'pol' ? '#tabs [data-act="tab:pol"]' : '#bar [data-act="dip"]', done: () => UI.sheet && UI.sheet.k === 'list' && UI.sheet.what === 'dip' },
  { t: 'Задание: ПОЛИТ. → ТОРГОВЛЯ — предложи торговое соглашение. Оно приносит золото обеим сторонам.', hl: () => UI.tab !== 'pol' ? '#tabs [data-act="tab:pol"]' : '#bar [data-act="trade"]', done: (S, p) => p.flags.trade },
  { info: 1, t: 'Чтобы напасть на соперника, предъяви претензию: через 3 дня можно объявить войну. Предложения приходят во ВХОДЯЩИЕ — значок письма.', hl: () => '#inboxBtn' },
  { info: 1, t: 'Победа: набери нужное число очков или захвати все столицы. Очки даются за хозяйство и войну; рейтинг — на вкладке КАРТА → РЕЙТИНГ.' },
  { info: 1, t: 'В МЕНЮ — сохранение и настройки: язык, звук, графика. Обучение можно пройти ещё раз: КАК ИГРАТЬ.', hl: () => UI.tab !== 'map' ? '#tabs [data-act="tab:map"]' : '#bar [data-act="menu"]' },
  { info: 1, last: 1, t: 'Ты готов, правитель! Развивай королевство, строй армию и побеждай. Удачи!' },
];
const TPRAISE = ['Отлично!', 'Славно!', 'Так держать!', 'Хорошая работа!'];

/* ----- король: пиксель-арт 32×40, рисуется кодом и оживает ----- */
function drawKing(c, t, o) {
  o = o || {}; const R = (x, y, w, h, col) => { c.fillStyle = col; c.fillRect(x, y, w, h); }, SK = '#f2c9a0', BD = '#eeeef4', RD = '#c8333a', GD = '#f0b94a', OL = '#2e1a0e';
  c.clearRect(0, 0, 32, 40);
  const cheer = o.cheer || 0, hop = cheer ? Math.round(Math.abs(Math.sin(t * 11)) * 2) : 0, oy = (Math.sin(t * 2.4) > 0.3 ? 1 : 0) - hop;
  const blink = (t % 3.6) > 3.45, wave = o.wave || cheer, wv = Math.sin(t * 10) > 0 ? 1 : 0, mouth = o.talk && Math.sin(t * 16) > -0.2;
  R(7, 38, 18, 2, 'rgba(0,0,0,.35)');                                                          // тень
  R(10, 35, 5, 4, OL); R(17, 35, 5, 4, OL); R(11, 36, 3, 2, '#5a3820'); R(18, 36, 3, 2, '#5a3820'); // сапоги
  R(6, 19 + oy, 20, 17 - oy, OL); R(7, 20 + oy, 18, 15 - oy, RD); R(7, 20 + oy, 4, 15 - oy, '#e24b52'); R(21, 20 + oy, 4, 15 - oy, '#9c242b'); // мантия
  R(15, 21 + oy, 2, 14 - oy, GD); R(7, 29 + oy, 18, 2, GD); R(15, 29 + oy, 2, 2, '#fff2a6');  // золотая кайма и пояс
  R(7, 19 + oy, 18, 4, '#f6f6fa'); for (const [x, y] of [[9, 20], [13, 21], [18, 20], [22, 21]]) R(x, y + oy, 1, 1, '#2a2a33'); // горностаевый воротник
  const hy = 7 + oy;
  R(9, hy + 1, 14, 13, OL); R(10, hy, 12, 13, OL); R(11, hy + 1, 10, 9, SK);                    // голова
  R(9, hy + 2, 2, 7, BD); R(21, hy + 2, 2, 7, BD);                                              // седые виски
  for (const [x, w, y] of [[10, 12, 7], [10, 12, 8], [11, 10, 9], [12, 8, 10], [13, 6, 11], [14, 4, 12]]) R(x, hy + y, w, 1, BD); // борода
  R(10, hy + 7, 1, 2, OL); R(21, hy + 7, 1, 2, OL);
  R(12, hy + 6, 8, 2, BD); R(15, hy + 5, 2, 2, '#d9a273');                                     // усы и нос
  R(12, hy + 2, 3, 1, '#d8d8e0'); R(17, hy + 2, 3, 1, '#d8d8e0');                              // брови
  R(13, hy + 3, 2, blink ? 1 : 2, '#1c1410'); R(18, hy + 3, 2, blink ? 1 : 2, '#1c1410');       // глаза
  R(12, hy + 5, 1, 1, '#e8a08a'); R(19, hy + 5, 1, 1, '#e8a08a');                              // румянец
  R(14, hy + 8, 4, mouth ? 3 : 1, '#7a1f2a');                                                   // рот
  R(10, hy - 1, 12, 3, '#7a5410'); R(11, hy, 10, 2, GD); R(10, hy - 4, 3, 3, GD); R(15, hy - 5, 2, 4, GD); R(19, hy - 4, 3, 3, GD); // корона
  R(15, hy, 2, 2, '#e0314b'); R(12, hy, 1, 1, '#3fa7ff'); R(19, hy, 1, 1, '#3fa7ff'); R(10, hy - 4, 1, 1, '#fff2a6'); R(21, hy - 4, 1, 1, '#fff2a6');
  if ((t * 1.6) % 3 < 0.25) { R(22, hy - 7, 1, 3, '#fff'); R(21, hy - 6, 3, 1, '#fff'); }       // блеск короны
  R(2, 6 + oy, 3, 33 - oy, '#7a5410'); R(3, 7 + oy, 1, 31 - oy, GD); R(0, 3 + oy, 7, 6, OL); R(1, 4 + oy, 5, 4, GD); R(2, 5 + oy, 3, 2, '#e0314b'); // скипетр
  R(4, 22 + oy, 4, 6, RD); R(4, 24 + oy, 4, 3, SK);                                             // рука со скипетром
  if (wave) { R(24, 14 + oy - wv, 4, 8, RD); R(24, 11 + oy - wv, 4, 4, SK); R(25, 10 + oy - wv, 2, 1, SK); } // поднятая рука
  else { R(24, 21 + oy, 4, 9, RD); R(24, 29 + oy, 4, 3, SK); }
  if (cheer) for (let i = 0; i < 4; i++) { const a = t * 6 + i * 1.57, x = 16 + Math.cos(a) * 14, y = 14 + Math.sin(a) * 11; R(Math.round(x), Math.round(y), 2, 2, i % 2 ? '#fff2a6' : '#ffd24a'); } // звёздочки радости
}
const kingImgUrl = () => { if (typeof document === 'undefined') return ''; const cv = document.createElement('canvas'); cv.width = 32; cv.height = 40; drawKing(cv.getContext('2d'), 0, { wave: 1 }); return cv.toDataURL(); };

/* ----- ход обучения ----- */
const TUT = {
  on: false, i: 0, S: null, full: '', shown: 0, cele: 0, min: false, m: null, hlSel: null, raf: 0, last: 0, at: null,
  start() {
    const S = tutMakeGame(); this.S = S; this.on = true; this.i = 0; this.cele = 0; this.min = false;
    startGame(S, 0); document.body.classList.add('tut'); $('king').classList.remove('hidden'); this.enter(); this.last = performance.now(); cancelAnimationFrame(this.raf); this.raf = requestAnimationFrame(t => this.loop(t));
  },
  st() { return TSTEPS[this.i]; },
  enter() { const st = this.st(); this.cele = 0; this.at = null; this.m = null; if (st.enter) st.enter(this.S); this.say(st.t); this.html(); this.hl(); },
  say(txt) { this.full = typeof tr === 'function' ? tr(txt) : txt; this.shown = 0; },
  relang() { if (this.on) { const st = this.st(); this.full = tr(this.cele ? this.praise : st.t); this.shown = this.full.length; this.html(); } },
  html() {
    const st = this.st(), n = TSTEPS.length, b = $('kbub');
    const btns = this.cele ? '' : (st.info ? btn('tutnext', st.last ? 'Завершить' : 'Далее', 'gold') : '') + (st.last ? '' : (st.info ? '' : btn('tutstep', 'Пропустить шаг')) + '<button class="skip" data-act="tutskip">Пропустить обучение</button>');
    b.innerHTML = `<div class="kn"><span>Король Эдвард</span><span>${this.i + 1}/${n}</span></div><div class="kt" id="ktext"></div><div class="kb">${btns}</div>`;
    $('king').classList.toggle('min', this.min); this.type(true);
  },
  type(force) { const e = $('ktext'); if (!e) return; const k = Math.floor(this.shown); if (force || e.dataset.k !== String(k)) { e.dataset.k = String(k); e.textContent = this.full.slice(0, k); } },
  complete() { const st = this.st(); this.cele = 1.3; this.praise = TPRAISE[(Math.random() * TPRAISE.length) | 0]; this.say(this.praise); this.html(); this.hl(); if (typeof SND !== 'undefined' && SND.ctx) SND.ui('ping'); },
  next() { if (this.i >= TSTEPS.length - 1) return this.finish('done'); this.i++; this.enter(); },
  tick() { // раз в 250 мс из updateHud: проверка условия, подсветки, положение над панелью
    if (!this.on) return; const S = UI.S; if (S !== this.S) return; const st = this.st(), p = S.players[VP];
    if (!this.cele && !st.info) { let ok = false; try { ok = st.done(S, p); } catch (e) {} if (ok) this.complete(); }
    this.hl(); const sh = $('sheet'); document.documentElement.style.setProperty('--kl', (!sh.classList.contains('hidden') ? sh.offsetHeight + 6 : 0) + 'px');
    if (st.at && !this.cele) { try { this.at = st.at(S); } catch (e) { this.at = null; } } else this.at = null;
  },
  hl() { // подсветка кнопки: класс ставим заново, потому что панели перерисовываются
    const st = this.st(); let sel = null; if (!this.cele && st.hl) { try { sel = st.hl(this.S); } catch (e) {} }
    for (const e of document.querySelectorAll('.tutHl')) e.classList.remove('tutHl');
    if (sel) { const e = document.querySelector(sel); if (e) e.classList.add('tutHl'); }
  },
  loop(now) {
    if (!this.on) return; this.raf = requestAnimationFrame(t => this.loop(t));
    if (UI.S !== this.S) return this.stopUi();                       // вышли в меню — тихо закрываем обучение
    const dt = Math.min(0.1, (now - this.last) / 1000); this.last = now; const tm = now / 1000;
    if (this.shown < this.full.length) { this.shown = Math.min(this.full.length, this.shown + dt * 55); this.type(); }
    if (this.cele > 0) { this.cele -= dt; if (this.cele <= 0) { this.cele = 0; this.next(); } }
    const cv = $('kingCv'); if (cv && !this.min) drawKing(cv.getContext('2d'), tm, { talk: this.shown < this.full.length, cheer: this.cele > 0 ? 1 : 0, wave: this.i === 0 && this.shown < this.full.length });
    else if (cv) drawKing(cv.getContext('2d'), tm, { talk: false });
    this.arrow();
  },
  arrow() { // стрелка к цели на карте; если цель за экраном — у края и указывает в её сторону
    const a = $('tutArrow'), p = this.at; if (!p) { a.classList.add('hidden'); return; }
    const cam = RN.cam, sx = (p.x * TS - cam.x) * cam.z, sy = (p.y * TS - cam.y) * cam.z, W = RN.w, H = RN.h, top = 130, bot = H - 340;
    const inside = sx > 10 && sx < W - 10 && sy > top && sy < bot; let x = sx, y = sy - 46, rot = 0;
    if (!inside) { x = Math.max(24, Math.min(W - 24, sx)); y = Math.max(top + 20, Math.min(bot - 20, sy)); rot = Math.atan2(sy - y, sx - x) - Math.PI / 2; }
    a.classList.remove('hidden'); a.style.transform = `translate(${x - 16}px, ${y - 16}px) rotate(${rot}rad)`;
  },
  stopUi() { this.on = false; cancelAnimationFrame(this.raf); document.body.classList.remove('tut'); $('king').classList.add('hidden'); $('tutArrow').classList.add('hidden'); for (const e of document.querySelectorAll('.tutHl')) e.classList.remove('tutHl'); document.documentElement.style.setProperty('--kl', '0px'); },
  finish(kind) {
    const S = this.S; this.stopUi(); try { localStorage.setItem('kc_tut', kind); } catch (e) {}
    if (!S || !S.tut || UI.S !== S) return;
    const done = kind === 'done'; showModal(done ? 'Обучение завершено' : 'Обучение пропущено', `<div class="row"><img src="${kingImgUrl()}" style="width:64px;height:80px;image-rendering:pixelated"><div>${done ? 'Ты прошёл обучение! Можешь продолжить эту партию — соперник теперь начнёт действовать — или вернуться в главное меню.' : 'Хорошо, правитель. Можешь продолжить эту партию — соперник теперь начнёт действовать — или вернуться в главное меню.'}</div></div>`, btn('tutkeep', 'Продолжить игру', 'gold') + btn('tomenu', 'В главное меню'));
  },
  offer() { // первый запуск
    showModal('Добро пожаловать!', `<div class="row"><img src="${kingImgUrl()}" style="width:64px;height:80px;image-rendering:pixelated"><div>Я — король Эдвард. Хочешь пройти короткое обучение? Я покажу всё: от стройки до войны. Позже его можно повторить: КАК ИГРАТЬ.</div></div>`, btn('tutgo', 'Начать обучение', 'gold') + btn('tutno', 'Пропустить'));
  },
  boot() { try { if (localStorage.getItem('kc_tut')) return; } catch (e) { return; } setTimeout(() => { if (!UI.S && $('modal').classList.contains('hidden')) this.offer(); }, 900); },
};

Object.assign(ACT, {
  tutstart() { if (NET.active) return showModal('Обучение', 'В сетевой игре обучение недоступно.'); if (UI.S && !UI.S.tut) showModal('Обучение', 'Текущая партия будет сохранена, а вы перейдёте в учебную игру.', btn('tutgo', 'Начать', 'gold') + btn('closemodal', 'Отмена')); else ACT.tutgo(); },
  tutgo() { if (UI.S && !UI.S.tut && !NET.active) saveGame(UI.S); $('modal').classList.add('hidden'); UI.paused = false; TUT.start(); },
  tutno() { try { localStorage.setItem('kc_tut', 'skip'); } catch (e) {} ACT.closemodal(); },
  tutnext() { if (TUT.on && !TUT.cele) TUT.next(); },
  tutstep() { if (TUT.on && !TUT.cele) TUT.next(); },
  tutskip() { if (TUT.on) TUT.finish('skip'); },
  tutkeep() { if (UI.S) UI.S.tut = false; ACT.closemodal(); },
  tutking() { TUT.min = !TUT.min; $('king').classList.toggle('min', TUT.min); },
});
if (typeof document !== 'undefined' && document.getElementById) {
  const _uh = updateHud; updateHud = function () { _uh(); TUT.tick(); };
  const _rt = renderTabs; renderTabs = function () { _rt(); if (TUT.on) TUT.hl(); };
  TUT.boot();
}
