'use strict';
/* ===== Язык интерфейса и экран «Настройки» =====
   Исходные тексты игры написаны по-русски. Переводы (lang-en.js и lang-xx.js) подставляются только при показе:
   в innerHTML/textContent, подписях на карте (canvas) и атрибутах. Состояние игры и сеть от языка не зависят,
   поэтому игроки с разными языками могут играть вместе. */
const CYR = /[А-Яа-яЁё]/;
/* Языки интерфейса: ru — исходный язык текстов игры, en — EN_DICT (lang-en.js), остальные — массивы LANG_PACKS[код]
   (lang-xx.js): строка №i перевода соответствует i-му ключу EN_DICT (порядок Object.keys(EN_DICT)). */
const LANGS = [
  { c: 'ru', n: 'Русский' }, { c: 'en', n: 'English' }, { c: 'id', n: 'Bahasa Indonesia' }, { c: 'es', n: 'Español' },
  { c: 'vi', n: 'Tiếng Việt' }, { c: 'de', n: 'Deutsch' }, { c: 'fr', n: 'Français' }, { c: 'it', n: 'Italiano' },
  { c: 'zh', n: '中文' }, { c: 'ja', n: '日本語' },
];
const isLang = c => LANGS.some(l => l.c === c);
const I18N = {
  lang: 'ru', cache: new Map(), re: null, exact: null, lower: null, statics: [], compiled: {},
  /* язык устройства (первый из списка предпочтений браузера/Android WebView); неподдерживаемый -> английский */
  detect() {
    let tag = '';
    try { const nv = typeof navigator !== 'undefined' ? navigator : null; tag = String(nv ? ((nv.languages && nv.languages[0]) || nv.language || nv.userLanguage || '') : ''); } catch (e) { tag = ''; }
    let p = tag.toLowerCase().replace(/_/g, '-').split('-')[0];
    if (p === 'in') p = 'id';
    return isLang(p) ? p : 'en';
  },
  /* словарь выбранного языка: русский фрагмент -> перевод */
  dictFor(lang) {
    const en = typeof EN_DICT === 'undefined' ? {} : EN_DICT;
    if (lang === 'en') return Object.assign({}, typeof IDSRC_EN === 'undefined' ? {} : IDSRC_EN, en);   // teks Bahasa Indonesia di kode -> Inggris
    const pack = typeof LANG_PACKS === 'undefined' ? null : LANG_PACKS[lang];
    if (!pack) return en;
    const out = {}, keys = Object.keys(en);
    for (let i = 0; i < keys.length; i++) if (typeof pack[i] === 'string' && pack[i] !== '') out[keys[i]] = pack[i];
    return out;
  },
  compile(lang) {
    if (this.compiled[lang]) return this.compiled[lang];
    const dict = this.dictFor(lang), exact = new Map(), lower = new Map(), keys = [];
    for (const k in dict) {
      exact.set(k, dict[k]); const l = k.toLowerCase(), caps = k.length > 1 && k === k.toUpperCase() && k !== l, prev = lower.get(l);
      // запасной вариант для другого регистра: лучше брать запись не из ЗАГЛАВНЫХ букв
      if (!prev) { lower.set(l, { tr: caps ? dict[k].toLowerCase() : dict[k], up: !caps && k[0] !== k[0].toLowerCase(), caps }); keys.push(l); }
      else if (prev.caps && !caps) lower.set(l, { tr: dict[k], up: k[0] !== k[0].toLowerCase(), caps: false });
    }
    keys.sort((a, b) => b.length - a.length);
    const esc = s => s.replace(/[.*+?^${}()|[\]\\\/]/g, '\\$&'), L = 'А-Яа-яЁё';
    const alt = keys.map(k => (CYR.test(k[0]) ? `(?<![${L}])` : '') + esc(k) + (CYR.test(k[k.length - 1]) ? `(?![${L}])` : ''));
    return (this.compiled[lang] = { exact, lower, re: alt.length ? new RegExp(alt.join('|'), 'giu') : null });
  },
  use(lang) { const c = this.compile(lang); this.exact = c.exact; this.lower = c.lower; this.re = c.re; },
  init() {
    let saved = null;
    try { saved = typeof localStorage !== 'undefined' ? localStorage.getItem('kc_lang') : null; } catch (e) { saved = null; }
    // сохранён явный выбор игрока — берём его; иначе язык системы (не поддерживается — английский)
    this.lang = saved && isLang(saved) ? saved : this.detect();
    this.cache.clear(); if (this.lang !== 'ru') this.use(this.lang);
  },
  /* перевод одной строки (текста или HTML): заменяет известные русские фрагменты, остальное не трогает */
  tr(s) {
    if (this.lang === 'ru' || typeof s !== 'string' || !this.re || !CYR.test(s)) return s;
    let r = this.cache.get(s); if (r !== undefined) return r;
    r = s.replace(this.re, m => {
      const e = this.exact.get(m); if (e !== undefined) return e;
      const q = this.lower.get(m.toLowerCase()); if (!q) return m;
      if (m.length > 1 && m === m.toUpperCase()) return q.tr.toUpperCase();
      const first = m[0], mUp = first !== first.toLowerCase();
      if (mUp && !q.up) return q.tr[0].toUpperCase() + q.tr.slice(1);
      if (!mUp && q.up) return q.tr[0].toLowerCase() + q.tr.slice(1);
      return q.tr;
    });
    if (this.cache.size > 3000) this.cache.clear(); this.cache.set(s, r); return r;
  },
  /* неизменяемые тексты страницы (главное меню) запоминаем по-русски, чтобы переводить туда и обратно */
  scan() {
    if (typeof document === 'undefined' || !document.createTreeWalker) return;
    const w = document.createTreeWalker(document.body, 4); let n; this.statics = [];
    while ((n = w.nextNode())) if (CYR.test(n.nodeValue)) this.statics.push({ n, ru: n.nodeValue });
  },
  applyStatic() { for (const s of this.statics) s.n.nodeValue = this.tr(s.ru); if (typeof document !== 'undefined' && document.documentElement) document.documentElement.lang = this.lang; },
  set(l) {
    this.lang = isLang(l) ? l : 'en'; this.cache.clear();
    if (this.lang !== 'ru') this.use(this.lang);
    try { localStorage.setItem('kc_lang', this.lang); } catch (e) {}
    this.applyStatic(); if (typeof TUT !== 'undefined') TUT.relang();
    if (typeof UI !== 'undefined' && UI.S) { UI.lastHtml = ''; for (const id of ['resbar', 'toasts']) { const e = $(id); if (e) e.dataset.h = ''; } try { renderTabs(); updateHud(); renderSheet(true); } catch (e) {} }
  },
  /* перехват записи текста на странице и надписей на карте */
  install() {
    if (typeof Element === 'undefined') return; const self = this;
    const wrapSetter = (proto, prop) => { const d = Object.getOwnPropertyDescriptor(proto, prop); if (!d || !d.set) return; Object.defineProperty(proto, prop, { configurable: true, enumerable: d.enumerable, get: d.get, set(v) { d.set.call(this, typeof v === 'string' ? self.tr(v) : v); } }); };
    wrapSetter(Element.prototype, 'innerHTML'); wrapSetter(Node.prototype, 'textContent');
    const sa = Element.prototype.setAttribute; Element.prototype.setAttribute = function (k, v) { return sa.call(this, k, (k === 'placeholder' || k === 'title') ? self.tr(v) : v); };
    if (typeof HTMLInputElement !== 'undefined') wrapSetter(HTMLInputElement.prototype, 'placeholder'), wrapSetter(HTMLTextAreaElement.prototype, 'placeholder');
    if (typeof CanvasRenderingContext2D !== 'undefined') for (const m of ['fillText', 'strokeText', 'measureText']) { const o = CanvasRenderingContext2D.prototype[m]; CanvasRenderingContext2D.prototype[m] = function (t, ...a) { return o.call(this, self.tr(String(t)), ...a); }; }
  },
};
I18N.init();
const tr = s => I18N.tr(s);

/* ----- экран «Настройки» ----- */
function settingsHtml() {
  const row = (lbl, on, tog, k, v) => `<div class="grp"><div class="lb">${lbl}</div><div class="seg">${btn(tog, on ? 'ВКЛ' : 'ВЫКЛ', on ? 'gold' : '')}<input type="range" min="0" max="100" step="5" value="${Math.round(v * 100)}" data-vol="${k}" class="rng"><b class="pct" id="pct_${k}">${Math.round(v * 100)}%</b></div></div>`;
  return `<div class="grp"><div class="lb">Язык</div><div class="seg langs">${LANGS.map(g => btn('setlang:' + g.c, g.n, I18N.lang === g.c ? 'gold' : '')).join('')}</div></div>`
    + row('Звуки', SND.sfx, 'sfxtoggle', 'sfx', SND.sv) + row('Музыка', SND.mus, 'mustoggle', 'mus', SND.mv)
    + (typeof FX === 'undefined' ? '' : `<div class="grp"><div class="lb">Графика</div><div class="seg">${[['off', 'Выкл'], ['low', 'Низкое'], ['med', 'Среднее'], ['high', 'Высокое']].map(g => btn('setgfx:' + g[0], g[1], FX.q === g[0] ? 'gold' : '')).join('')}</div></div>`);
}
function showSettings() { showModal('Настройки', settingsHtml(), btn('closemodal', 'Готово', 'gold')); UI.setOpen = true; }
Object.assign(ACT, {
  settings() { showSettings(); },
  setlang(l) { I18N.set(l); showSettings(); },
  setgfx(q) { if (typeof FX !== 'undefined') FX.setQ(q); showSettings(); },
  sfxtoggle() { SND.setSfx(!SND.sfx); if (UI.setOpen) showSettings(); },
  mustoggle() { SND.setMus(!SND.mus); if (UI.setOpen) showSettings(); },
});
if (typeof document !== 'undefined' && document.addEventListener) {
  document.addEventListener('input', e => { const t = e.target, k = t && t.dataset && t.dataset.vol; if (!k) return; const v = +t.value / 100; SND.setVol(k, v); const p = document.getElementById('pct_' + k); if (p) p.textContent = Math.round(v * 100) + '%'; });
  document.addEventListener('change', e => { const t = e.target; if (t && t.dataset && t.dataset.vol) { SND.unlock(); SND.ui('click'); } });
  I18N.install(); I18N.scan(); I18N.applyStatic();
}
