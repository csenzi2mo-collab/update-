'use strict';
/* ===== Загрузочный экран =====
   До входа в меню заранее рисуем всё, что игра иначе делала бы «на лету» и подтормаживала: спрайты зданий всех цветов,
   города, войска, укрепления, маркеры, живую карту фона, шейдеры. Прогресс виден на полосе, а название игры и студия — на экране. */
const LOADER = {
  MIN_MS: 2200, MAX_MS: 15000, t0: 0, total: 1, doneN: 0, raf: 0,
  /* список работ: [текст, функция]; много мелких, чтобы кадры не замирали */
  jobs() {
    const J = [], cols = PCOL.slice(), types = Object.keys(BD).filter(t => t !== 'wall' && t !== 'tower' && t !== 'gate' && t !== 'moat');
    J.push(['Загружаем шрифт…', () => document.fonts && document.fonts.load ? Promise.race([document.fonts.load('16px PixelRU'), new Promise(r => setTimeout(r, 2500))]) : null]);
    for (const col of cols) J.push(['Строим здания…', () => { for (const t of types) { bldSprite({ type: t, res: 0 }, col, 0); if (t === 'mine') { bldSprite({ type: t, res: 1 }, col, 0); bldSprite({ type: t, res: 2 }, col, 0); } } }]);
    for (const col of cols) J.push(['Возводим города…', () => { for (let lv = 0; lv <= 5; lv++) for (const cap of [0, 1]) if (lv > 0 || !cap) for (let vs = 0; vs < (lv ? 1 : 4); vs++) citySprite({ level: lv, isCap: cap, vs }, col); }]);
    J.push(['Куём укрепления…', () => { for (let m = 0; m < 16; m++) { bldSprite({ type: 'wall', res: 0 }, cols[0], m); moatSprite(m, 0); moatSprite(m, 1); } }]);
    for (const col of cols) J.push(['Куём укрепления…', () => { for (let m = 0; m < 16; m++) { bldSprite({ type: 'tower', res: 0 }, col, m); bldSprite({ type: 'gate', res: 0 }, col, m); } }]);
    const figs = Object.keys(SQ), cls = Object.keys(FIG).concat(['cav']);
    for (const col of cols) J.push(['Собираем войска…', () => { for (const t of figs) { figSprite(t, col); if (t === 'cmd') for (const c of cls) figSprite(t, col, c); } markerCanvas(col); }]);
    J.push(['Собираем войска…', () => { markerCanvas('#ff3a2a'); }]);
    J.push(['Рисуем карту…', () => initDemo()]);
    J.push(['Готовим шейдеры…', () => { if (typeof FX !== 'undefined' && FX.q !== 'off' && FX.init()) FX.prog(FX.N[FX.q]); }]);
    J.push(['Прогреваем анимации…', () => { if (DEMO.S) { demoScene(DEMO.S); for (let i = 0; i < 4; i++) frame(DEMO.S, performance.now() + i * 250); } }]);
    return J;
  },
  setP(p, msg) { const f = document.getElementById('lfill'), m = document.getElementById('lmsg'); if (f) f.style.width = Math.round(p * 100) + '%'; if (m && msg && m.dataset.m !== msg) { m.dataset.m = msg; m.textContent = msg; } },
  run(onDone) {
    const L = document.getElementById('loader'); if (!L) { onDone(); return; }
    this.t0 = performance.now(); const jobs = this.jobs(), n = jobs.length; let i = 0, finished = false, kc = 0;
    const king = document.getElementById('loadKing'), kx = king && king.getContext('2d');
    const anim = t => { if (finished && !L.isConnected) return; if (kx) drawKing(kx, t / 1000, { wave: 1 }); this.raf = requestAnimationFrame(anim); };
    this.raf = requestAnimationFrame(anim);
    const finish = () => {
      if (finished) return; finished = true; this.setP(1, 'Готово!');
      const wait = Math.max(0, this.MIN_MS - (performance.now() - this.t0));
      setTimeout(() => { L.classList.add('off'); onDone(); setTimeout(() => { cancelAnimationFrame(this.raf); L.remove(); }, 800); }, wait);
    };
    const step = async () => {
      if (finished) return; const start = performance.now();
      while (i < n && performance.now() - start < 14) { const [msg, fn] = jobs[i++]; this.setP(i / n, msg); try { const r = fn(); if (r && r.then) await r; } catch (e) { console.warn('loader:', msg, e); } }
      if (i < n) setTimeout(step, 0); else finish();
    };
    setTimeout(step, 30); setTimeout(finish, this.MAX_MS);   // страховка: не зависнуть на загрузке
  },
};
