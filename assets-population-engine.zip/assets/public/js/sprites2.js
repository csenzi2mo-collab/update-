'use strict';
/* ===== Войска в двойном разрешении =====
   Пиксель фигуры = 0.125 мира (раньше 0.25): размер на экране тот же, деталей и аккуратности больше.
   Рисуем плоскими областями, затем автоматически: свет сверху, тень снизу, ровный тёмный контур. */
const FK = 0.125, OUTC = [26, 18, 12];
const SKN = '#e8c49a', SKN_D = '#c79a72', SKN_L = '#f6dcb8', STL = '#b9c3d1', STL_L = '#e4ebf3', STL_D = '#8791a2', STL_DD = '#5a6272', LTH = '#7a4e26', LTH_D = '#4a2e14', GLD = '#f2c230', GLD_D = '#b88a14';
const lit = (hex, f) => shadeC(hex, f);
function finishFig(cv) {   // свет/тень по краям силуэта + контур
  const w = cv.width, h = cv.height, cx = cv.getContext('2d'); cx.setTransform(1, 0, 0, 1, 0, 0); const im = cx.getImageData(0, 0, w, h), d = im.data, o = new Uint8ClampedArray(d);
  const A = (x, y) => (x < 0 || y < 0 || x >= w || y >= h) ? 0 : o[(y * w + x) * 4 + 3];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = (y * w + x) * 4;
    if (o[i + 3] > 0) {
      let f = 1; if (!A(x, y - 1)) f = 1.2; else if (!A(x, y + 1)) f = 0.72; else if (!A(x - 1, y) && A(x + 1, y)) f = 1.08;
      if (f !== 1) { d[i] = Math.min(255, d[i] * f); d[i + 1] = Math.min(255, d[i + 1] * f); d[i + 2] = Math.min(255, d[i + 2] * f); }
    } else if (A(x - 1, y) || A(x + 1, y) || A(x, y - 1) || A(x, y + 1)) { d[i] = OUTC[0]; d[i + 1] = OUTC[1]; d[i + 2] = OUTC[2]; d[i + 3] = 255; }
  }
  cx.putImageData(im, 0, 0); return cv;
}
function mk(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function line2(c, x0, y0, x1, y1, col) { const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)); for (let i = 0; i <= n; i++) R_(c, Math.round(x0 + (x1 - x0) * i / (n || 1)), Math.round(y0 + (y1 - y0) * i / (n || 1)), 1, 1, col); }
/* общие части (локальные координаты, фигура 24x26, лицом вправо) */
function legs(c, hose, hoseL, boot, bootL, mail) {
  R_(c, 8, 17, 4, 7, hose); R_(c, 12, 17, 4, 7, hoseL); R_(c, 8, 17, 1, 7, lit(hose, 0.8)); R_(c, 15, 17, 1, 7, lit(hoseL, 0.85));
  if (mail) for (let y = 18; y < 22; y += 2) for (let x = 9 + (y % 4 ? 1 : 0); x < 16; x += 2) R_(c, x, y, 1, 1, lit(hoseL, 1.15));
  R_(c, 12, 17, 1, 6, lit(hoseL, 0.7));                   // щель между ногами
  R_(c, 8, 22, 4, 3, boot); R_(c, 12, 22, 5, 3, bootL); R_(c, 8, 22, 4, 1, lit(boot, 1.5)); R_(c, 12, 22, 5, 1, lit(bootL, 1.5)); R_(c, 8, 25, 4, 1, '#120c08'); R_(c, 12, 25, 5, 1, '#120c08');
}
function headFace(c, x, y, eye) {  // лицо 6x6, смотрит вправо
  R_(c, x, y, 6, 6, SKN); R_(c, x, y, 1, 6, SKN_D); R_(c, x + 5, y + 2, 1, 2, SKN_L); R_(c, x + 1, y + 5, 5, 1, SKN_D);
  R_(c, x + 4, y + 2, 1, 1, eye || '#1a120c'); R_(c, x + 3, y + 1, 2, 1, SKN_D); R_(c, x + 3, y + 4, 2, 1, '#a8725a'); R_(c, x + 5, y + 4, 1, 1, SKN_D);
}
let _NW = false;   // true — рисуем фигуру БЕЗ оружия (его потом рисует анимация боя в render.js)
const FIG = {
  militia(c, col) {   // восставший крестьянин с вилами
    R_(c, 9, 7, 8, 12, '#8a6a3a'); R_(c, 9, 7, 8, 1, '#b08a4a'); R_(c, 9, 7, 1, 12, '#6a4a28'); R_(c, 9, 13, 8, 1, '#3a2a18'); R_(c, 11, 13, 2, 1, col);
    R_(c, 10, 19, 3, 6, '#5a4a30'); R_(c, 14, 19, 3, 6, '#4a3a24'); R_(c, 10, 24, 3, 2, '#2a1c10'); R_(c, 14, 24, 3, 2, '#2a1c10');
    R_(c, 10, 2, 6, 5, SKN); R_(c, 10, 2, 6, 1, SKN_L); R_(c, 14, 4, 1, 1, '#14100c'); R_(c, 8, 1, 10, 2, '#d8b858'); R_(c, 10, -1, 6, 2, '#c8a848'); R_(c, 10, 1, 6, 1, '#a88838');
    R_(c, 17, 9, 3, 3, SKN); R_(c, 6, 8, 3, 6, '#7a5a30');
    if (!_NW) { R_(c, 21, -1, 1, 26, '#8a5a2b'); R_(c, 19, -3, 1, 4, '#c8ced8'); R_(c, 21, -3, 1, 5, '#e8ecf4'); R_(c, 23, -3, 1, 4, '#c8ced8'); R_(c, 19, 0, 5, 1, '#9aa0aa'); }
  },
  archer(c, col) {
    // колчан за спиной
    R_(c, 4, 7, 4, 10, LTH); R_(c, 4, 7, 1, 10, LTH_D); R_(c, 7, 7, 1, 10, lit(LTH, 1.25)); R_(c, 4, 6, 4, 1, '#c9a064'); line2(c, 4, 5, 5, 2, '#d8d8d8'); line2(c, 6, 5, 7, 2, '#d8d8d8'); R_(c, 4, 1, 2, 2, '#c03030'); R_(c, 7, 1, 2, 2, '#f0f0f0');
    legs(c, '#5a3d22', '#6e4a2a', '#3a2412', '#4a2e14');
    // туника
    R_(c, 7, 9, 11, 10, '#3f9a34'); R_(c, 7, 9, 2, 10, '#2f7a28'); R_(c, 16, 9, 2, 10, '#4cae40'); R_(c, 7, 9, 11, 1, '#5cbf4c'); R_(c, 6, 17, 13, 2, '#37882e'); R_(c, 6, 18, 13, 1, '#245c1e');
    for (let i = 0; i < 4; i++) R_(c, 8 + i * 3, 12, 1, 4, '#37882e');           // складки
    R_(c, 7, 15, 11, 2, '#5a3a1a'); R_(c, 7, 15, 11, 1, '#7a4e26'); R_(c, 12, 15, 2, 2, GLD); R_(c, 12, 15, 2, 1, '#fff0a0');
    line2(c, 8, 9, 15, 14, LTH_D); line2(c, 9, 9, 16, 14, LTH);                // лямка колчана
    // капюшон и лицо
    R_(c, 8, 0, 8, 4, '#2f7a28'); R_(c, 9, 0, 6, 1, '#4cae40'); R_(c, 7, 2, 3, 8, '#2f7a28'); R_(c, 7, 4, 1, 5, '#245c1e'); R_(c, 10, 8, 5, 2, SKN_D);
    headFace(c, 10, 3); R_(c, 10, 3, 6, 1, '#2f7a28'); R_(c, 15, 3, 1, 1, '#2f7a28');
    // руки, лук и стрела
    R_(c, 13, 10, 5, 3, '#2f7a28'); R_(c, 13, 10, 5, 1, '#4cae40'); R_(c, 18, 10, 2, 3, SKN); R_(c, 18, 10, 2, 1, SKN_L);
    R_(c, 12, 12, 6, 2, '#37882e'); if (!_NW) { R_(c, 17, 13, 2, 2, SKN); R_(c, 18, 14, 1, 1, SKN_D); }
    if (!_NW) { R_(c, 21, 6, 2, 14, '#8a5a2b'); R_(c, 21, 6, 1, 14, '#b27a3a'); R_(c, 22, 9, 1, 8, '#6a4220'); R_(c, 21, 11, 2, 4, '#3a2412'); R_(c, 20, 4, 1, 3, '#8a5a2b'); R_(c, 19, 3, 1, 2, '#8a5a2b'); R_(c, 20, 19, 1, 3, '#8a5a2b'); R_(c, 19, 21, 1, 2, '#8a5a2b'); }
    if (!_NW) { R_(c, 19, 4, 1, 18, '#ebebeb'); R_(c, 18, 12, 1, 3, '#ebebeb'); }             // тетива
    if (!_NW) { R_(c, 13, 14, 10, 1, '#d2ac6c'); R_(c, 22, 13, 2, 3, '#cfd6e0'); R_(c, 13, 13, 2, 1, '#c03030'); R_(c, 13, 15, 2, 1, '#f0f0f0'); }
  },
  light(c, col) {
    R_(c, 2, 8, 7, 12, col); R_(c, 3, 9, 5, 10, lit(col, 1.18)); R_(c, 2, 8, 7, 1, STL_L); R_(c, 2, 19, 7, 1, STL_D); R_(c, 2, 8, 1, 12, STL); R_(c, 8, 8, 1, 12, STL_D);   // щит
    R_(c, 4, 12, 3, 3, GLD); R_(c, 4, 12, 3, 1, '#fff0a0'); R_(c, 5, 10, 1, 8, GLD_D); R_(c, 3, 13, 5, 1, GLD_D);
    legs(c, '#6a707c', '#7c8492', '#2e2418', '#3c2e1e', true);
    R_(c, 7, 9, 11, 11, STL); for (let y = 10; y < 19; y += 2) for (let x = 7 + ((y / 2) % 2); x < 18; x += 2) R_(c, x, y, 1, 1, STL_D);   // кольчуга
    R_(c, 7, 9, 11, 1, STL_L); R_(c, 6, 18, 13, 2, STL_D); R_(c, 6, 19, 13, 1, STL_DD); R_(c, 7, 9, 2, 10, STL_D);
    R_(c, 10, 9, 6, 11, col); R_(c, 10, 9, 1, 11, lit(col, 0.7)); R_(c, 15, 9, 1, 11, lit(col, 0.75)); R_(c, 11, 9, 4, 1, lit(col, 1.35)); R_(c, 12, 12, 2, 3, GLD); R_(c, 12, 12, 2, 1, '#fff0a0'); R_(c, 10, 16, 6, 1, LTH_D); R_(c, 10, 17, 6, 1, LTH); R_(c, 12, 16, 2, 2, GLD);
    R_(c, 9, 7, 8, 3, STL_D); R_(c, 9, 7, 8, 1, STL);                                  // воротник-койф
    headFace(c, 10, 3); R_(c, 9, 0, 8, 3, STL); R_(c, 10, 0, 6, 1, STL_L); R_(c, 8, 3, 9, 1, STL_D); R_(c, 8, 2, 2, 5, STL_D); R_(c, 9, 1, 1, 4, STL_D); R_(c, 15, 3, 1, 3, STL);   // шлем-котелок, наносник
    R_(c, 12, 0, 2, 1, col);
    R_(c, 14, 10, 4, 3, STL_D); R_(c, 14, 10, 4, 1, STL); R_(c, 17, 11, 2, 3, SKN); R_(c, 17, 11, 2, 1, SKN_L);
    if (!_NW) { R_(c, 20, 0, 2, 15, STL_L); R_(c, 21, 0, 1, 15, STL); R_(c, 22, 1, 1, 13, STL_D); R_(c, 20, 0, 1, 1, '#fff'); R_(c, 18, 14, 6, 2, GLD); R_(c, 18, 14, 6, 1, '#fff0a0'); R_(c, 20, 16, 2, 4, LTH_D); R_(c, 20, 20, 2, 1, GLD_D); }
  },
  heavy(c, col, nocrest) {
    R_(c, 0, 8, 9, 16, col); R_(c, 1, 9, 7, 14, lit(col, 1.15)); R_(c, 0, 8, 9, 1, STL_L); R_(c, 0, 8, 1, 16, STL); R_(c, 8, 8, 1, 16, STL_DD); R_(c, 0, 23, 9, 1, STL_DD); R_(c, 2, 22, 5, 1, STL_DD);   // башенный щит
    R_(c, 3, 13, 3, 3, GLD); R_(c, 3, 13, 3, 1, '#fff0a0'); R_(c, 4, 10, 1, 11, STL_L); R_(c, 2, 14, 5, 1, STL_L); for (let y = 10; y < 22; y += 4) { R_(c, 1, y, 1, 1, STL_L); R_(c, 7, y, 1, 1, STL_L); }
    R_(c, 8, 17, 4, 8, STL_DD); R_(c, 12, 17, 5, 8, STL_D); R_(c, 8, 17, 1, 8, STL_DD); R_(c, 12, 17, 1, 8, '#3a4050'); R_(c, 8, 21, 4, 1, STL); R_(c, 12, 21, 5, 1, STL_L);   // наколенники/поножи
    R_(c, 8, 23, 4, 3, '#14100c'); R_(c, 12, 23, 5, 3, '#14100c'); R_(c, 8, 23, 4, 1, STL_D); R_(c, 12, 23, 5, 1, STL);
    R_(c, 7, 9, 11, 10, STL_D); R_(c, 8, 9, 9, 8, STL); R_(c, 8, 9, 9, 1, STL_L); R_(c, 8, 9, 2, 8, STL_L); R_(c, 15, 9, 2, 8, STL_D); R_(c, 11, 10, 3, 7, col); R_(c, 11, 10, 1, 7, lit(col, 0.7)); R_(c, 10, 12, 5, 2, col); R_(c, 10, 12, 5, 1, lit(col, 1.3));   // кираса с крестом
    R_(c, 7, 17, 11, 3, STL_DD); for (let x = 7; x < 18; x += 3) R_(c, x, 17, 1, 3, '#3a4050'); R_(c, 7, 17, 11, 1, STL_D); R_(c, 7, 16, 11, 1, LTH_D);   // набедренные пластины
    R_(c, 5, 8, 5, 5, STL); R_(c, 5, 8, 5, 1, STL_L); R_(c, 5, 12, 5, 1, STL_D); R_(c, 15, 8, 5, 5, STL); R_(c, 15, 8, 5, 1, STL_L); R_(c, 15, 12, 5, 1, STL_D); R_(c, 6, 9, 1, 3, STL_L); R_(c, 16, 9, 1, 3, STL_L);   // наплечники
    R_(c, 9, 5, 7, 4, STL_D);                                                           // горжет
    R_(c, 8, 1, 10, 8, STL); R_(c, 8, 1, 10, 1, STL_L); R_(c, 8, 1, 2, 8, STL_L); R_(c, 16, 1, 2, 8, STL_D); R_(c, 8, 8, 10, 1, STL_DD); R_(c, 11, 4, 7, 1, '#0c0806'); R_(c, 14, 4, 1, 4, '#0c0806'); R_(c, 16, 6, 1, 1, '#0c0806'); R_(c, 16, 7, 1, 1, '#0c0806'); R_(c, 10, 2, 7, 1, STL_D);
    if (!nocrest) { R_(c, 11, 0, 4, 1, col); R_(c, 12, 0, 2, 1, lit(col, 1.4)); R_(c, 10, 1, 1, 2, col); }
    R_(c, 17, 11, 3, 3, STL); R_(c, 17, 11, 3, 1, STL_L); R_(c, 19, 12, 2, 3, STL_D); R_(c, 19, 12, 2, 1, STL);   // латная перчатка
    if (!_NW) { R_(c, 21, 0, 2, 16, STL_L); R_(c, 22, 0, 1, 16, STL); R_(c, 23, 1, 1, 14, STL_D); R_(c, 19, 15, 5, 2, GLD); R_(c, 19, 15, 5, 1, '#fff0a0'); R_(c, 21, 17, 2, 5, LTH_D); R_(c, 21, 22, 2, 1, GLD_D); }
  },
};
function makeFig(t, col, cls, nw) {
  _NW = !!nw; try { return makeFig0(t, col, cls); } finally { _NW = false; }
}
function makeFig0(t, col, cls) {
  if (t === 'cmd' && cls === 'cav') return makeCav(col, true);
  if (t === 'cmd') {
    const c = mk(32, 37), x = c.getContext('2d'); x.translate(3, 8);
    R_(x, 2, 8, 6, 13, '#c02820'); R_(x, 2, 8, 6, 1, '#e8503c'); R_(x, 3, 20, 5, 2, '#8a1a14'); R_(x, 2, 8, 1, 13, '#8a1a14'); R_(x, 4, 12, 1, 8, '#8a1a14');   // алый плащ
    FIG[cls || 'light'](x, col, true);
    const top = (cls || 'light') === 'heavy' ? 1 : 0; R_(x, 9, top - 2, 8, 3, GLD); R_(x, 9, top - 2, 8, 1, '#fff0a0'); R_(x, 9, top - 3, 1, 2, GLD); R_(x, 12, top - 4, 2, 3, GLD); R_(x, 16, top - 3, 1, 2, GLD); R_(x, 12, top - 2, 2, 1, '#e03030'); R_(x, 9, top, 8, 1, GLD_D);
    const f = finishFig(c); f._feet = 8 + 26; f._k = FK; return f;
  }
  if (t === 'cav') return makeCav(col);
  if (t === 'cat' || t === 'ram') return t === 'cat' ? makeCat(col) : makeRam(col);
  const c = mk(30, 32), x = c.getContext('2d'); x.translate(3, 3); FIG[t](x, col); const f = finishFig(c); f._feet = 3 + 26; f._k = FK; return f;
}
function makeCav(col, cmd) {
  const c = mk(52, 58), x = c.getContext('2d'); x.translate(6, 17);
  const H = '#9a6a3a', HL = '#bd8a52', HD = '#6e4624', MN = '#2c1a0e';
  // хвост и задние ноги
  R_(x, 0, 12, 4, 3, MN); R_(x, 1, 14, 3, 6, MN); R_(x, 0, 18, 3, 4, '#1c1006');
  for (const lx of [5, 8]) { R_(x, lx, 21, 3, 8, HD); R_(x, lx, 28, 3, 2, '#14100c'); R_(x, lx, 25, 3, 1, lit(HD, 0.8)); }
  // туловище
  R_(x, 3, 12, 23, 11, H); R_(x, 3, 12, 23, 2, HL); R_(x, 3, 21, 23, 2, HD); R_(x, 5, 15, 3, 6, HD); R_(x, 22, 14, 3, 7, HD);
  // передние ноги
  for (const lx of [19, 22]) { R_(x, lx, 21, 3, 8, H); R_(x, lx, 28, 3, 2, '#14100c'); R_(x, lx, 25, 3, 1, HD); }
  // шея и голова (смотрит вправо-вниз)
  R_(x, 23, 6, 5, 9, H); R_(x, 26, 4, 5, 6, H); R_(x, 24, 5, 2, 9, MN); R_(x, 26, 3, 3, 1, MN); R_(x, 28, 8, 6, 4, H); R_(x, 28, 8, 6, 1, HL); R_(x, 33, 9, 2, 3, HD); R_(x, 33, 10, 2, 1, '#14100c'); R_(x, 30, 6, 2, 2, H); R_(x, 29, 4, 2, 3, HD); R_(x, 30, 8, 1, 1, '#14100c');
  R_(x, 27, 12, 4, 3, H); R_(x, 28, 11, 5, 2, HD); R_(x, 26, 6, 1, 8, '#4a2e14');   // нащёчный ремень и уздечка
  // попона команды
  R_(x, 8, 11, 14, 11, col); R_(x, 8, 11, 14, 1, lit(col, 1.4)); R_(x, 8, 21, 14, 2, lit(col, 0.65)); R_(x, 8, 11, 1, 11, lit(col, 0.7)); for (let i = 9; i < 22; i += 2) R_(x, i, 22, 1, 2, i % 4 ? GLD : lit(col, 0.5)); R_(x, 13, 14, 3, 4, GLD); R_(x, 13, 14, 3, 1, '#fff0a0');
  R_(x, 22, 8, 4, 7, lit(col, 0.9)); R_(x, 22, 8, 4, 1, lit(col, 1.3));
  // всадник
  R_(x, 10, 3, 8, 9, STL); R_(x, 10, 3, 8, 1, STL_L); R_(x, 10, 3, 2, 9, STL_D); R_(x, 13, 4, 3, 7, col); R_(x, 13, 4, 3, 1, lit(col, 1.4));
  R_(x, 10, 11, 8, 2, LTH_D); R_(x, 12, 12, 4, 7, STL_D); R_(x, 12, 17, 4, 4, '#2e2418'); R_(x, 12, 20, 6, 1, '#120c08'); R_(x, 15, 19, 2, 2, GLD_D);
  R_(x, 11, -3, 7, 7, STL); R_(x, 11, -3, 7, 1, STL_L); R_(x, 11, -3, 2, 7, STL_L); R_(x, 17, -3, 1, 7, STL_D); R_(x, 13, 0, 5, 1, '#0c0806'); R_(x, 15, 0, 1, 3, '#0c0806'); if (!cmd) { R_(x, 13, -4, 3, 1, col); R_(x, 14, -5, 1, 1, lit(col, 1.4)); }
  R_(x, 16, 5, 5, 3, STL_D); R_(x, 20, 6, 2, 3, SKN);
  if (cmd) {   // маршал: алый плащ за спиной и корона на шлеме
    R_(x, 4, 5, 6, 14, '#c02820'); R_(x, 4, 5, 6, 1, '#e8503c'); R_(x, 4, 5, 1, 14, '#8a1a14'); R_(x, 6, 9, 1, 9, '#8a1a14'); R_(x, 5, 18, 5, 1, '#8a1a14');
    R_(x, 11, -6, 7, 3, GLD); R_(x, 11, -6, 7, 1, '#fff0a0'); R_(x, 11, -7, 1, 2, GLD); R_(x, 14, -8, 2, 3, GLD); R_(x, 17, -7, 1, 2, GLD); R_(x, 14, -6, 2, 1, '#e03030'); R_(x, 11, -4, 7, 1, GLD_D);
  } else { R_(x, 5, 5, 5, 9, '#2c4a8a'); R_(x, 5, 5, 5, 1, STL_L); R_(x, 5, 13, 5, 1, STL_DD); R_(x, 7, 7, 1, 5, GLD); }   // щит за спиной
  // копьё (почти вертикально, с вымпелом)
  if (!_NW) { line2(x, 20, 9, 25, -10, '#a8743a'); line2(x, 21, 9, 26, -10, '#c9965a'); line2(x, 25, -10, 26, -13, '#cfd6e0'); line2(x, 26, -10, 27, -13, '#f4f7fb'); R_(x, 27, -9, 5, 3, col); R_(x, 27, -9, 5, 1, lit(col, 1.4)); R_(x, 30, -7, 2, 1, lit(col, 0.7)); }
  const f = finishFig(c); f._feet = 17 + 30; f._k = FK; return f;
}
function makeCat(col) {
  const c = mk(60, 44), x = c.getContext('2d'); x.translate(6, 6);
  const W1 = '#8a5a2b', W2 = '#a8743a', W3 = '#5a3a1a';
  for (const wx of [6, 28]) { x.fillStyle = '#2a1a0c'; for (let yy = 0; yy < 10; yy++) { const hw = Math.round(Math.sqrt(25 - (yy - 4.5) * (yy - 4.5))); R_(x, wx + 5 - hw, 18 + yy, hw * 2, 1, '#2a1a0c'); R_(x, wx + 5 - Math.max(0, hw - 2), 18 + yy, Math.max(0, hw - 2) * 2, 1, '#6a4a2a'); } R_(x, wx + 4, 22, 2, 2, '#2a1a0c'); R_(x, wx + 1, 22, 8, 1, '#3a2a1a'); }
  R_(x, 4, 14, 32, 5, W1); R_(x, 4, 14, 32, 1, W2); R_(x, 4, 18, 32, 1, W3); for (let i = 6; i < 36; i += 6) R_(x, i, 15, 1, 3, W3);
  R_(x, 16, 4, 3, 11, W1); R_(x, 24, 4, 3, 11, W1); R_(x, 16, 4, 1, 11, W2); R_(x, 24, 4, 1, 11, W2); R_(x, 15, 3, 13, 2, W3); R_(x, 15, 3, 13, 1, W2);   // стойки
  line2(x, 6, 13, 20, 4, W3); line2(x, 6, 12, 20, 3, W1); line2(x, 7, 12, 21, 3, W2);                             // метательный рычаг
  R_(x, 3, 10, 5, 4, W3); R_(x, 3, 10, 5, 1, W2); R_(x, 4, 8, 3, 2, '#7e838d'); R_(x, 4, 7, 3, 1, '#b8c0cc'); R_(x, 4, 8, 1, 2, '#b8c0cc');   // ковш с камнем
  R_(x, 31, 4, 1, 10, '#5a3a1a'); R_(x, 32, 4, 6, 4, col); R_(x, 32, 4, 6, 1, lit(col, 1.4)); R_(x, 32, 7, 6, 1, lit(col, 0.65));
  R_(x, 36, 12, 5, 3, '#3a3f4a'); R_(x, 36, 12, 5, 1, STL_D);
  const f = finishFig(c); f._feet = 34; f._k = FK; return f;
}
function makeRam(col) {
  const c = mk(60, 44), x = c.getContext('2d'); x.translate(6, 6);
  for (const wx of [6, 30]) { for (let yy = 0; yy < 8; yy++) { const hw = Math.round(Math.sqrt(16 - (yy - 3.5) * (yy - 3.5))); R_(x, wx + 4 - hw, 20 + yy, hw * 2, 1, '#2a1a0c'); R_(x, wx + 4 - Math.max(0, hw - 2), 20 + yy, Math.max(0, hw - 2) * 2, 1, '#6a4a2a'); } }
  R_(x, 6, 16, 3, 6, '#5a3a1a'); R_(x, 32, 16, 3, 6, '#5a3a1a');
  R_(x, 2, 6, 34, 11, col); R_(x, 2, 6, 34, 2, lit(col, 1.4)); R_(x, 2, 15, 34, 2, lit(col, 0.6)); for (let i = 5; i < 35; i += 4) R_(x, i, 8, 1, 7, lit(col, 0.72)); R_(x, 2, 6, 1, 11, lit(col, 0.7));   // крыша из шкур
  R_(x, 0, 2, 38, 4, W1_); R_(x, 0, 2, 38, 1, '#c9965a'); R_(x, 0, 5, 38, 1, '#5a3a1a');
  R_(x, 14, 12, 1, 6, '#c9b48a'); R_(x, 26, 12, 1, 6, '#c9b48a');
  R_(x, 0, 13, 40, 5, '#8a5a2b'); R_(x, 0, 13, 40, 1, '#c9965a'); R_(x, 0, 17, 40, 1, '#4a2e14');
  R_(x, 36, 11, 7, 9, '#7e838d'); R_(x, 36, 11, 7, 2, '#c4ccd8'); R_(x, 40, 13, 3, 5, '#4a4e58'); R_(x, 42, 14, 2, 3, '#2a2e36'); R_(x, 37, 14, 2, 2, '#4a4e58');
  const f = finishFig(c); f._feet = 34; f._k = FK; return f;
}
const W1_ = '#8a5a2b';
