'use strict';
/* ===== REALM: otonomi pejabat, siklus hidup, keluarga kerajaan, keamanan, dan sistem notifikasi =====
   Hanya berjalan offline (lockstep multiplayer tidak boleh diubah sepihak). Data tersimpan di S.realm (ikut save/load).
   1 tahun = 10 hari game. Semua kejadian acak memakai S.rnd() sehingga adil dan tidak sembarangan. */
const RY = DAY * 10;
const NM_P = ['Selene', 'Ivarra', 'Maelis', 'Riana', 'Lysa', 'Mirelle', 'Thessa', 'Aurelia', 'Brenna', 'Elowen', 'Fiora', 'Isolde', 'Kaelith', 'Odalys', 'Rowena', 'Yselda'];
const NM_L = ['Adrik', 'Bramwin', 'Kael', 'Torvan', 'Dareus', 'Gorran', 'Helvin', 'Sorin', 'Caedan', 'Aldric', 'Evander', 'Fenwick', 'Garrick', 'Hadrian', 'Joren', 'Leoric', 'Marek', 'Osric', 'Rurik', 'Varric'];
const FEM = new Set(NM_P);
const EXTRA_ROLES = ['Menteri Pertanian', 'Menteri Kehakiman', 'Menteri Keuangan', 'Kepala Intelijen', 'Menteri Pekerjaan Umum', 'Menteri Kesehatan', 'Menteri Pendidikan', 'Penasihat Kerajaan', 'Penasihat Raja', 'Jaksa Agung', 'Kepala Kepolisian', 'Duta Besar', 'Bendahara Kerajaan', 'Panglima Besar', 'Ketua Mahkamah Agung', 'Kepala Pengawal Kerajaan', 'Kepala Administrasi Kerajaan'];
const ROLE_DESC = { 'Penasihat Raja': 'Nasihat langsung untuk raja/ratu', 'Jaksa Agung': 'Penuntut dan penegak hukum negara', 'Kepala Kepolisian': 'Ketertiban dan keamanan kota', 'Duta Besar': 'Hubungan diplomatik dengan negara tetangga', 'Bendahara Kerajaan': 'Pengelolaan kas dan pembayaran', 'Panglima Besar': 'Komando seluruh pasukan', 'Ketua Mahkamah Agung': 'Peradilan tertinggi kerajaan', 'Kepala Pengawal Kerajaan': 'Keamanan istana dan keluarga raja', 'Kepala Administrasi Kerajaan': 'Tata usaha dan birokrasi', 'Menteri Pertanian': 'Lumbung dan pangan', 'Menteri Kehakiman': 'Hukum dan pengawasan korupsi', 'Menteri Keuangan': 'Perbendaharaan', 'Kepala Intelijen': 'Mata-mata dan keamanan negara', 'Menteri Pekerjaan Umum': 'Jalan dan bangunan', 'Menteri Kesehatan': 'Wabah dan rumah sakit', 'Menteri Pendidikan': 'Pendidikan dan akademi', 'Penasihat Kerajaan': 'Nasihat bagi penguasa' };
const TAG = { penting: '[PENTING]', peringatan: '[PERINGATAN]', rutin: '[Rutin]', info: '[Info]' };
const cl = (v, a, b) => Math.max(a, Math.min(b, v));
const pickR = (S, a) => a[Math.floor(S.rnd() * a.length)];
const capOf = (S, pid) => S.cities.find(c => c.isCap && c.owner === pid);
const dayNo = S => Math.floor(S.time / DAY) + 1;
const unitsOf = a => { try { return units(a); } catch (e) { return 4; } };

function R(S) {
  let r = S.realm;
  if (!r) r = S.realm = { extra: {}, people: {}, graves: [], log: [], seen: {}, routine: [], trips: [], assets: {}, fam: {}, sec: {}, n: 1, yr: null, next: 0, flt: 'all', rule: 'sulung' };
  if (!r.chars) r.chars = S._gov || {};
  S._gov = r.chars; return r;
}
function initCh(S, c, key, rf) {
  if (c.ck) return c; c.ck = key;
  const h = govHash(S.seed + '|rx|' + key), f = n => rf ? rf() : (Math.imul(h ^ (n * 7919), 2654435761) >>> 0) / 4294967296;
  if (c.jk === undefined) c.jk = c.t === 'Raja' ? (c.gelar === 'Ratu' ? 'P' : 'L') : (FEM.has(c.name) ? 'P' : 'L');
  const sf = c.sifat || [];
  c.amb = cl(Math.round(15 + f(1) * 55 + (sf.includes('Ambisius') ? 25 : 0) - (sf.includes('Setia') ? 15 : 0)), 0, 100);
  c.kor = cl(Math.round(10 + f(2) * 40 + (sf.includes('Serakah') ? 30 : 0) + (sf.includes('Licik') ? 15 : 0) - (sf.includes('Jujur') ? 30 : 0) - (sf.includes('Bijaksana') ? 10 : 0)), 0, 100);
  c.rel = c.rel || {}; c.log = c.log || []; c.dead = 0; c.sakit = 0; return c;
}
function newChar(S, key, o) {
  const r = R(S), jk = o.jk || (S.rnd() < 0.5 ? 'L' : 'P'), sf = [];
  while (sf.length < (o.nsifat || 2)) { const x = pickR(S, SIFAT); if (!sf.includes(x)) sf.push(x); }
  const c = { gelar: o.gelar || o.t, t: o.t, atasan: o.atasan || null, owner: o.owner, name: genName(S, jk), umur: o.umur !== undefined ? o.umur : 30 + Math.floor(S.rnd() * 20), sifat: sf, loyal: o.loyal !== undefined ? o.loyal : 40 + Math.floor(S.rnd() * 50), jk, born: S.time };
  if (o.rtg) c.rtg = o.rtg; if (o.ortu) c.ortu = o.ortu;
  (o.store === 'people' ? r.people : r.chars)[key] = c;
  return initCh(S, c, key, () => S.rnd());
}
function clog(S, c, t) { c.log.unshift('Hari ' + dayNo(S) + ': ' + t); if (c.log.length > 8) c.log.pop(); }
const cname = c => c.gelar && c.gelar !== c.t ? c.gelar + ' ' + c.name : c.name;

/* ----- notifikasi: siapa, apa, di mana, dampak; tanpa duplikat; empat tingkat ----- */
function note(S, o) {
  const r = R(S), mine = o.pid === undefined || o.pid === VP;
  const L = { t: S.time, lvl: o.lvl || 'info', type: o.type || 'pol', title: o.title, who: o.who, what: o.what, where: o.where, impact: o.impact, own: mine ? 1 : 0 };
  L.text = 'Siapa: ' + L.who + ' · Kejadian: ' + L.what + ' · Lokasi: ' + L.where + ' · Dampak: ' + L.impact;
  const k = o.key || (o.title + '|' + L.who); if (r.seen[k] !== undefined && S.time - r.seen[k] < DAY * (o.cool || 1)) return false; r.seen[k] = S.time;
  r.log.unshift(L); if (r.log.length > 90) r.log.pop();
  if (!mine) { if (!o.major) return true; L.lvl = 'info'; }
  if (L.lvl === 'rutin') { r.routine.push(L); return true; }
  addMsg(S, VP, { type: L.type, title: TAG[L.lvl] + ' ' + L.title, text: L.text });
  if (L.lvl !== 'info') S.toast.push({ title: L.lvl === 'penting' ? 'PENTING' : 'PERINGATAN', text: L.title, t: S.time });
  return true;
}
function noteRoutine(S, text) { R(S).routine.push({ t: S.time, title: 'Info', text, short: text, lvl: 'rutin', type: 'pol', own: 1 }); }
function flushRoutine(S) {
  const r = R(S); if (!r.routine.length) return;
  const ls = r.routine.splice(0).map(x => x.short || ((x.who || '') + ': ' + x.what + ' (' + x.where + ') → ' + x.impact));
  addMsg(S, VP, { type: 'pol', title: TAG.rutin + ' Laporan harian · Hari ' + dayNo(S), text: ls.slice(0, 5).join(' • ') + (ls.length > 5 ? ' • dan ' + (ls.length - 5) + ' laporan lain (lihat menu Laporan)' : '') });
}

/* ----- kompatibilitas dengan mods.js: pejabat tambahan, penyimpanan tokoh ----- */
(function () {
  const _gc = govChar; govChar = function (S, key, gelar, t, atasan, owner) { R(S); return initCh(S, _gc(S, key, gelar, t, atasan, owner), key); };
  const _go = govOf; govOf = function (S, pid) {
    const g = _go(S, pid), r = R(S);
    g.ministers = g.ministers.concat((r.extra[pid] || []).map(k => r.chars[k]).filter(c => c && !c.dead).map(c => Object.assign({ r: c.rtg || 'Pejabat kerajaan', key: 'extra' }, c)));
    return g;
  };
  const _vt = villageTax; villageTax = function (S, ct) { return villageOfficials(S, ct).some(o => o.reb) ? 0 : _vt(S, ct); };
})();

/* ----- penggantian pejabat ----- */
function cancelTrip(S, c) { const r = R(S); r.trips = r.trips.filter(t => t.ck !== c.ck); c.trip = 0; }
function replaceChar(S, old, cause) {
  const r = R(S); cancelTrip(S, old); old.dead = S.time; old.cause = cause;
  r.graves.unshift({ name: old.name, t: old.t, umur: old.umur, owner: old.owner, cause, time: S.time }); if (r.graves.length > 60) r.graves.pop();
  const n = newChar(S, old.ck, { gelar: old.gelar, t: old.t, atasan: old.atasan, owner: old.owner, rtg: old.rtg, umur: 30 + Math.floor(S.rnd() * 20), loyal: 50 + Math.floor(S.rnd() * 40) });
  if (old.izin !== undefined) n.izin = old.izin; clog(S, n, 'diangkat menggantikan ' + old.name); return n;
}
function villageOf(S, c) { const m = /^v(\d+)\|/.exec(c.ck); return m ? S.cities.find(x => x.id === +m[1]) : null; }
function whereOf(S, c) { const v = villageOf(S, c); return v ? v.name : 'Ibu kota ' + S.players[c.owner].name; }

/* ----- kematian dan suksesi ----- */
function pDeath(S, c) {
  const a = c.umur, p = S.players[c.owner]; let q = 0.003 + Math.pow(Math.max(0, a - 45), 2) * 0.00009;
  if (a < 5) q += 0.01; if (c.sakit) q += 0.03;
  if (p) { if (p.stock.food <= 0.5) q += 0.01; if (S.players.some(o => o.id !== c.owner && o.alive && atWar(S, c.owner, o.id))) q += 0.004; }
  q *= govDeathMult(S, c.owner);   // dokter menurunkan risiko kematian
  return Math.min(0.6, q);
}
function causeOf(S, c) {
  const p = S.players[c.owner];
  if (c.sakit) return 'sakit berkepanjangan'; if (c.umur >= 65) return 'usia lanjut';
  if (p && S.players.some(o => o.id !== c.owner && o.alive && atWar(S, c.owner, o.id)) && S.rnd() < 0.4) return 'korban peperangan';
  if (p && p.stock.food <= 0.5) return 'kelaparan dan wabah'; return 'kecelakaan';
}
function die(S, c, cause) {
  const r = R(S), pid = c.owner, pn = S.players[pid].name, fam = r.fam[pid];
  if (c.t === 'Raja') { succeedRuler(S, pid, cause, c); return; }
  if (c.t === 'Anak' || c.t === 'Pasangan' || c.t === 'Petugas' || c.t === 'Selir') {
    c.dead = S.time; delete r.people[c.ck]; if (fam) fam.kids = fam.kids.filter(k => k !== c.ck);
    r.graves.unshift({ name: c.name, t: c.gelar, umur: c.umur, owner: pid, cause, time: S.time });
    note(S, { pid, lvl: 'penting', type: 'life', title: 'Wafat: ' + cname(c), who: cname(c) + ' (' + c.umur + ' th), keluarga kerajaan ' + pn, what: 'meninggal karena ' + cause, where: 'Istana ' + pn, impact: c.t === 'Anak' ? 'garis suksesi berubah' : 'raja/ratu kini sendiri; dapat menikah lagi' }); return;
  }
  const where = whereOf(S, c), old = c.t, n = replaceChar(S, c, cause);
  note(S, { pid, lvl: 'penting', type: 'life', title: 'Pejabat wafat: ' + old + ' ' + c.name, who: old + ' ' + c.name + ' (' + c.umur + ' th)', what: 'meninggal karena ' + cause + '; ' + n.name + ' (' + n.umur + ' th) diangkat sebagai penggantinya', where, impact: 'tanggung jawab dan wewenang jabatan diambil alih ' + n.name });
}
function succeedRuler(S, pid, cause, old) {
  const r = R(S), fam = r.fam[pid] || (r.fam[pid] = { kids: [] }), pn = S.players[pid].name, key = pid + '|raja';
  const kids = fam.kids.map(k => r.people[k]).filter(c => c && !c.dead).sort((a, b) => b.umur - a.umur || a.born - b.born);
  const rule = pid === VP ? r.rule : 'sulung'; let heir = null, how = '';
  heir = sucPickHeir(S, pid, rule);
  cancelTrip(S, old); r.graves.unshift({ name: old.name, t: old.gelar, umur: old.umur, owner: pid, cause, time: S.time }); if (r.graves.length > 60) r.graves.pop();
  const sp = r.people[pid + '|pasangan']; if (sp) delete r.people[pid + '|pasangan'];
  if (heir) {
    delete r.people[heir.ck]; fam.kids = fam.kids.filter(k => k !== heir.ck);
    heir.ck = key; heir.t = 'Raja'; heir.gelar = heir.jk === 'P' ? 'Ratu' : 'Raja'; heir.atasan = null; heir.loyal = 70; heir.wali = heir.umur < 16; r.chars[key] = heir;
    how = 'pewaris takhta (' + (rule === 'lakilaki' ? 'putra lebih dulu' : 'anak tertua') + ')' + (heir.wali ? '; Perdana Menteri menjadi wali sampai usia 16' : '');
  } else {
    const pm = r.chars[pid + '|Perdana Menteri']; let nr;
    if (pm && !pm.dead) { nr = pm; r.chars[key] = nr; nr.ck = key; nr.t = 'Raja'; nr.gelar = nr.jk === 'P' ? 'Ratu' : 'Raja'; nr.atasan = null; newChar(S, pid + '|Perdana Menteri', { gelar: 'Perdana Menteri', t: 'Perdana Menteri', atasan: 'Raja', owner: pid }); how = 'tanpa pewaris, dewan kerajaan mengangkat Perdana Menteri'; }
    else { nr = newChar(S, key, { gelar: 'Raja', t: 'Raja', owner: pid, loyal: 70 }); how = 'tanpa pewaris, bangsawan mengangkat penguasa baru'; }
    heir = nr;
  }
  note(S, { pid, major: 1, lvl: 'penting', type: 'life', title: 'Suksesi takhta ' + pn, who: cname(old) + ' (' + old.umur + ' th) wafat; ' + cname(heir) + ' (' + heir.umur + ' th) naik takhta', what: 'wafat karena ' + cause + ', ' + how, where: 'Ibu kota ' + pn, impact: 'pemerintahan tetap berjalan; kekuasaan beralih ke ' + heir.name });
}

/* ----- pernikahan, kelahiran, perkembangan anak ----- */
function marry(S, pid) {
  const r = R(S), ru = r.chars[pid + '|raja']; if (!ru || r.people[pid + '|pasangan']) return false;
  const jk = ru.jk === 'P' ? 'L' : 'P', sp = newChar(S, pid + '|pasangan', { store: 'people', t: 'Pasangan', gelar: jk === 'P' ? 'Permaisuri' : 'Pangeran Konsort', owner: pid, jk, umur: cl(ru.umur + Math.floor(S.rnd() * 11) - 5, 18, 60), loyal: 80 });
  note(S, { pid, lvl: 'penting', type: 'life', title: 'Pernikahan kerajaan', who: cname(ru) + ' dan ' + cname(sp), what: 'menikah', where: 'Istana ' + S.players[pid].name, impact: 'peluang lahirnya pewaris takhta' });
  celebrate(S, pid, ru, sp); return true;
}
/* pesta pernikahan mewah: biaya diambil dari kas (menyisakan 50 emas untuk biaya menikah), rakyat dan raja/ratu makin senang */
function celebrate(S, pid, ru, sp) {
  const p = S.players[pid], cost = Math.max(0, Math.min((p.stock.gold || 0) - 50, 150));
  p.stock.gold = (p.stock.gold || 0) - cost;
  ru.loyal = cl((ru.loyal === undefined ? 50 : ru.loyal) + 10, 0, 100);
  for (const c of S.cities) if (c.owner === pid) c.unrest = cl((c.unrest === undefined ? 25 : c.unrest) - 15, 0, 100);
  note(S, { pid, lvl: 'penting', type: 'life', title: gxl('Lavish wedding feast', 'Pesta pernikahan mewah'), who: cname(ru) + gxl(' and ', ' dan ') + cname(sp), what: gxl('held a grand feast with dances, processions, and gifts from nobles', 'menggelar pesta megah: tarian, arak-arakan, dan hadiah dari para bangsawan'), where: gxl('Capital ', 'Ibu kota ') + p.name, impact: gxl('people rejoice, unrest falls', 'rakyat bersuka cita, kerusuhan turun') + (cost ? gxl('; feast cost ' + cost + ' gold', '; biaya pesta ' + cost + ' emas') : '') });
}
function birth(S, pid, ru, sp) {
  const r = R(S), fam = r.fam[pid], jk = S.rnd() < 0.5 ? 'L' : 'P', key = pid + '|anak|' + (r.n++);
  const k = newChar(S, key, { store: 'people', t: 'Anak', gelar: jk === 'P' ? 'Putri' : 'Pangeran', owner: pid, jk, umur: 0, loyal: 100, nsifat: 1, ortu: ru.name + ' & ' + sp.name });
  sucInit(S, k, sp && sp.t === 'Selir' ? 50 : 100); k.ibu = sp ? sp.ck : null;
  // sifat ibu (selir atau permaisuri) diwariskan ke anak dengan peluang 70%
  if (sp && sp.sifat && sp.sifat.length && S.rnd() < 0.7) k.sifat = [pickR(S, sp.sifat)];
  fam.kids.push(key);
  note(S, { pid, lvl: 'penting', type: 'life', title: 'Kelahiran ' + k.gelar + ' ' + k.name, who: cname(ru) + ' dan ' + cname(sp), what: 'dikaruniai ' + (jk === 'P' ? 'seorang putri' : 'seorang putra') + ': ' + k.name, where: 'Istana ' + S.players[pid].name, impact: 'garis suksesi bertambah (' + fam.kids.length + ' anak)' });
}
function kidGrowth(S, c) {
  if (c.t !== 'Anak') return; const tag = { 6: 'mulai belajar membaca dan berhitung', 12: 'mulai berlatih berkuda dan pedang', 16: 'dinyatakan dewasa' }[c.umur]; if (!tag) return;
  let tag2 = ''; if (c.umur === 16 && c.sifat.length < 3) { const x = pickR(S, SIFAT.filter(s => !c.sifat.includes(s))); c.sifat.push(x); tag2 = ' dan menunjukkan watak ' + x; }
  clog(S, c, tag); note(S, { pid: c.owner, lvl: 'rutin', type: 'life', title: 'Perkembangan ' + c.name, who: cname(c) + ' (' + c.umur + ' th)', what: tag + tag2, where: 'Istana ' + S.players[c.owner].name, impact: c.umur === 16 ? 'siap menjadi pewaris' : 'pendidikan kerajaan berlanjut' });
}
function royalYear(S, pid) {
  const r = R(S), ru = r.chars[pid + '|raja']; if (!ru || ru.dead) return; const fam = r.fam[pid] || (r.fam[pid] = { kids: [] }), sp = r.people[pid + '|pasangan'];
  if (!sp) { if (ru.umur >= 18 && ru.umur <= 60 && S.rnd() < 0.35) marry(S, pid); }
  else if (!sp.dead) { const fem = ru.jk === 'P' ? ru : sp; if (fem.umur <= 42 && fam.kids.length < 20 && S.rnd() < 0.6) birth(S, pid, ru, sp); }
  if (ru.jk === 'L' && ru.umur >= 18) { for (const k of Object.keys(r.people)) if (k.startsWith(pid + '|selir|')) { const s = r.people[k]; if (s && !s.dead && s.umur <= 42 && fam.kids.length < 20 && S.rnd() < 0.3) birth(S, pid, ru, s); } if (pid !== VP && ru.umur <= 55 && S.rnd() < 0.04) sucAddSelir(S, pid); }   // maks 20 anak, peluang lahir dipercepat
}
function yearStep(S) {
  const r = R(S); ensureGov(S); let aged = 0, oldest = null;
  for (const c of Object.values(r.chars).concat(Object.values(r.people))) {
    if (!c || c.dead) continue; const p = S.players[c.owner]; if (!p || !p.alive) continue;
    c.umur++; c.sakit = !c.sakit && S.rnd() < 0.04 ? 1 : 0;
    if (c.owner === VP) { aged++; if (!oldest || c.umur > oldest.umur) oldest = c; }
    if (S.rnd() < pDeath(S, c)) { die(S, c, causeOf(S, c)); continue; }
    kidGrowth(S, c);
    if (c.wali && c.umur >= 16) { c.wali = false; note(S, { pid: c.owner, lvl: 'info', type: 'pol', title: 'Masa perwalian berakhir', who: cname(c), what: 'mencapai usia 16 dan memerintah sendiri', where: 'Ibu kota', impact: 'wali menyerahkan kekuasaan penuh' }); }
  }
  for (const p of S.players) if (p.alive) royalYear(S, p.id);
  for (const c of S.cities) if (c.owner === VP) c.unrest = cl((c.unrest === undefined ? 25 : c.unrest) - 3, 0, 100);   // politik: kerusuhan kota kerajaan pemain turun 3 tiap tahun
  for (const p of S.players) if (p.alive) govTick(S, p.id);   // petugas, markas, guild (pemain dan AI)
  sucYearly(S);   // dukungan pangeran
  for (const k in r.seen) if (S.time - r.seen[k] > DAY * 3) delete r.seen[k];
  note(S, { pid: VP, lvl: 'rutin', type: 'life', key: 'tahun' + r.yr, title: 'Tahun ke-' + (r.yr + 1), who: 'Seluruh pejabat dan keluarga kerajaan', what: 'bertambah usia satu tahun (' + aged + ' tokoh)', where: 'seluruh kerajaan', impact: oldest ? 'tertua: ' + oldest.name + ' (' + oldest.umur + ' th)' : 'tidak ada' });
}

/* ----- kabinet yang berkembang, pengangkatan ----- */
function appoint(S, pid, manual) {
  const r = R(S), ex = r.extra[pid] = r.extra[pid] || [], role = EXTRA_ROLES[ex.length % EXTRA_ROLES.length], n = Math.floor(ex.length / EXTRA_ROLES.length), t = role + (n ? ' ' + (n + 1) : '');
  const key = pid + '|x|' + (r.n++), c = newChar(S, key, { gelar: t, t, atasan: 'Perdana Menteri', owner: pid, rtg: ROLE_DESC[role] }); ex.push(key);
  note(S, { pid, lvl: manual ? 'info' : 'rutin', type: 'pol', title: 'Pejabat baru: ' + t, who: c.name + ' (' + c.umur + ' th)', what: 'diangkat sebagai ' + t, where: 'Ibu kota ' + S.players[pid].name, impact: ROLE_DESC[role] + ' kini punya pejabat khusus; kabinet ' + (4 + ex.length) + ' orang' }); return c;
}
function growCabinet(S, pid, cap) {
  const r = R(S), ex = r.extra[pid] = r.extra[pid] || [], vs = S.cities.filter(c => c.owner === pid && !c.isCap).length, want = 4 + Math.floor(vs / 2) + (cap.level >= 3 ? 1 : 0);
  if (S.time - (r['g' + pid] || 0) > DAY * 2) { r['g' + pid] = S.time; appoint(S, pid, false); }
}

/* ----- keputusan mandiri pejabat ----- */
function decide(S, c, p, cap) {
  if (c.reb || c.trip || c.dead || c.t === 'Raja') return;
  const r = R(S), v = villageOf(S, c), where = whereOf(S, c), pid = p.id, jujur = c.sifat.some(x => ['Jujur', 'Setia', 'Bijaksana'].includes(x));
  const eco = c.t === 'Menteri Ekonomi' || c.t === 'Menteri Keuangan' || !!v;
  const w = { kor: c.kor >= 45 && eco ? (c.kor - 35) / 65 : 0, jur: (100 - c.kor) / 250 + (jujur ? 0.3 : 0), lok: v ? c.amb / 150 : 0, rel: 0.35, trip: 0.3, reb: (c.amb >= 65 && c.loyal <= 38) ? 0.3 + (c.sifat.includes('Ambisius') ? 0.15 : 0) : 0 };
  let tot = 0; for (const k in w) tot += w[k]; let x = S.rnd() * tot, act = 'rel'; for (const k in w) { x -= w[k]; if (x <= 0) { act = k; break; } }
  const who = c.t + ' ' + c.name;
  if (act === 'kor') {
    const amt = Math.round((3 + S.rnd() * 8) * (eco ? 1.5 : 1)); p.stock.gold = Math.max(0, (p.stock.gold || 0) - amt); c.kor = cl(c.kor + 3, 0, 100); c.loyal = cl(c.loyal - 2, 0, 100); clog(S, c, 'menggelapkan ' + amt + ' emas');
    const jaksa = (r.extra[pid] || []).some(k => r.chars[k] && /Kehakiman|Intelijen/.test(r.chars[k].t)), det = 0.22 + (jaksa ? 0.2 : 0) - (c.sifat.includes('Licik') ? 0.08 : 0);
    if (S.rnd() < det) {
      p.stock.gold += amt * 2;
      if (c.kor >= 70) { const o = c.t; replaceChar(S, c, 'dipecat karena korupsi'); note(S, { pid, lvl: 'penting', type: 'pol', title: 'Korupsi terungkap: ' + o + ' ' + c.name, who, what: 'menggelapkan kas dan dipecat', where, impact: 'denda ' + amt * 2 + ' emas masuk kas; jabatan diisi pejabat baru' }); }
      else { c.kor = cl(c.kor - 20, 0, 100); note(S, { pid, lvl: 'peringatan', type: 'pol', title: 'Dugaan korupsi: ' + c.name, who, what: 'kedapatan menggelapkan dana dan diberi peringatan keras', where, impact: 'denda ' + amt * 2 + ' emas masuk kas' }); }
    }
  } else if (act === 'jur') {
    const vs = v ? [v] : S.cities.filter(q => q.owner === pid); for (const q of vs) if (q.unrest !== undefined) q.unrest = cl(q.unrest - 4, 0, 100); p.stock.gold += 2; c.loyal = cl(c.loyal + 1, 0, 100);
    note(S, { pid, lvl: 'rutin', type: 'pol', title: 'Program kesejahteraan', who, what: 'menjalankan program untuk rakyat', where: v ? v.name : 'seluruh kerajaan', impact: 'kerusuhan turun, kas +2 emas' });
  } else if (act === 'lok' && v) {
    v.unrest = cl((v.unrest === undefined ? 25 : v.unrest) - 5, 0, 100); p.stock.gold = Math.max(0, p.stock.gold - 4);
    note(S, { pid, lvl: 'rutin', type: 'pol', title: 'Kebijakan wilayah', who, what: 'mengalihkan dana pusat untuk kepentingan wilayahnya', where: v.name, impact: 'kerusuhan di ' + v.name + ' turun, kas pusat -4 emas' });
  } else if (act === 'rel') relate(S, c, pid);
  else if (act === 'trip') { const mode = v ? pickR(S, ['ibukota', 'desa', 'dipl']) : (c.t === 'Menteri Luar Negeri' ? 'dipl' : pickR(S, ['desa', 'desa', 'dipl'])); startTrip(S, c, pid, mode); }
  else if (act === 'reb') { if (v) startRebel(S, c, v, p); else coup(S, c, p, cap); }
}
function relate(S, c, pid) {
  const r = R(S), others = Object.values(r.chars).filter(o => o.owner === pid && !o.dead && o !== c && o.t !== 'Raja'); if (!others.length) return;
  const o = pickR(S, others); let d = Math.round((S.rnd() - 0.5) * 20);
  d += c.sifat.filter(x => o.sifat.includes(x)).length * 8; if ((c.kor > 55) !== (o.kor > 55)) d -= 8; if (c.sifat.includes('Pendendam')) d -= 5; if (o.sifat.includes('Ramah') || c.sifat.includes('Ramah')) d += 6;
  const a = cl((c.rel[o.ck] || 0) + d, -100, 100); c.rel[o.ck] = a; o.rel[c.ck] = cl((o.rel[c.ck] || 0) + d, -100, 100);
  const before = (c.rel[o.ck + '_s'] || 0); const st = a >= 60 ? 1 : a <= -60 ? -1 : 0;
  if (st !== before) {
    c.rel[o.ck + '_s'] = st; o.rel[c.ck + '_s'] = st; if (!st) return;
    note(S, { pid, lvl: st > 0 ? 'rutin' : 'peringatan', type: 'pol', title: st > 0 ? 'Aliansi politik' : 'Persaingan politik', who: c.t + ' ' + c.name + ' dan ' + o.t + ' ' + o.name, what: st > 0 ? 'membentuk aliansi dan saling mendukung' : 'berseteru dan saling menjegal', where: 'Pemerintahan ' + S.players[pid].name, impact: st > 0 ? 'keduanya lebih setia pada kelompoknya' : 'risiko intrik dan kudeta meningkat' });
    c.loyal = cl(c.loyal + (st > 0 ? 3 : -4), 0, 100); o.loyal = cl(o.loyal + (st > 0 ? 3 : -4), 0, 100);
  }
}
function soldiersNear(S, pid, x, y, rad) { let n = 0; for (const a of S.armies) { if (a.owner !== pid || a.ship || a.fight) continue; if (dist(a.x, a.y, x, y) <= rad) n += unitsOf(a); } return n; }
function startRebel(S, c, v, p) {
  c.reb = S.time; c.izin = false; v.unrest = cl((v.unrest === undefined ? 25 : v.unrest) + 35, 0, 100); cancelTrip(S, c); clog(S, c, 'memberontak');
  note(S, { pid: p.id, major: 1, lvl: 'penting', type: 'pol', title: 'Pemberontakan di ' + v.name, who: c.t + ' ' + c.name, what: 'memberontak melawan pemerintah pusat', where: v.name, impact: 'pajak desa terhenti, kerusuhan naik, izin militer dicabut' });
}
function coup(S, c, p, cap) {
  const r = R(S), pid = p.id, key = pid + '|raja', ru = r.chars[key]; if (!ru || ru.dead || c.amb < 70 || c.loyal > 30) return;
  const guard = soldiersNear(S, pid, cap.x + 1, cap.y + 1, 14), ps = cl(0.25 + (c.amb - 70) / 120 + (50 - ru.loyal) / 200 - guard / 80, 0.05, 0.7), pn = p.name;
  if (S.rnd() < ps) {
    const oldKey = c.ck, oldT = c.t, oldTug = c.rtg, oldAt = c.atasan; cancelTrip(S, c); cancelTrip(S, ru);
    r.graves.unshift({ name: ru.name, t: ru.gelar, umur: ru.umur, owner: pid, cause: 'digulingkan dalam kudeta', time: S.time });
    r.chars[key] = c; c.ck = key; c.t = 'Raja'; c.gelar = c.jk === 'P' ? 'Ratu' : 'Raja'; c.atasan = null; c.loyal = 70;
    const sp = r.people[pid + '|pasangan']; if (sp) delete r.people[pid + '|pasangan']; for (const k of (r.fam[pid] || { kids: [] }).kids) delete r.people[k]; r.fam[pid] = { kids: [] };
    const n = newChar(S, oldKey, { gelar: oldT, t: oldT, atasan: oldAt, owner: pid, rtg: oldTug });
    note(S, { pid, major: 1, lvl: 'penting', type: 'pol', title: 'Kudeta di ' + pn, who: oldT + ' ' + c.name, what: 'merebut takhta dari ' + cname(ru) + '; ' + n.name + ' menjabat ' + oldT, where: 'Ibu kota ' + pn, impact: 'pergantian pemerintahan; dinasti lama jatuh' });
  } else {
    const o = c.t; replaceChar(S, c, 'dihukum karena kudeta gagal'); ru.loyal = cl(ru.loyal + 5, 0, 100);
    note(S, { pid, major: 1, lvl: 'penting', type: 'pol', title: 'Kudeta gagal di ' + pn, who: o + ' ' + c.name, what: 'mencoba merebut kekuasaan, digagalkan pengawal istana', where: 'Ibu kota ' + pn, impact: 'pelaku dihukum, jabatan diisi pejabat baru' });
  }
}
function resolveRebels(S) {
  const r = R(S);
  for (const c of Object.values(r.chars)) {
    if (!c.reb || c.dead) continue; const v = villageOf(S, c), p = S.players[c.owner]; if (!v || !p || !p.alive || v.owner !== c.owner) { c.reb = 0; continue; }
    if (S.time - c.reb < DAY * 2) continue;
    const ps = 0.3 + Math.min(0.5, soldiersNear(S, c.owner, v.x + 1, v.y + 1, 12) / 25);
    if (S.rnd() < ps) { const o = c.t; replaceChar(S, c, 'ditumpas'); v.unrest = cl((v.unrest || 25) - 20, 0, 100); note(S, { pid: c.owner, lvl: 'penting', type: 'pol', title: 'Pemberontakan dipadamkan di ' + v.name, who: o + ' ' + c.name, what: 'ditumpas, pejabat baru diangkat', where: v.name, impact: 'ketertiban pulih, pajak berjalan lagi' }); }
    else if (S.time - c.reb > DAY * 5) { c.reb = 0; c.loyal = 55; p.stock.gold = Math.max(0, p.stock.gold - 40); note(S, { pid: c.owner, lvl: 'peringatan', type: 'pol', title: 'Damai dengan ' + c.name, who: c.t + ' ' + c.name, what: 'berdamai setelah diberi konsesi', where: v.name, impact: 'kas -40 emas; pajak kembali berjalan, izin militer tetap dicabut' }); }
  }
}

/* ----- perjalanan dan penugasan ----- */
function startTrip(S, c, pid, mode) {
  const r = R(S); if (c.trip || c.dead || c.reb || c.t === 'Raja' || r.trips.length >= 16) return false;
  const cap = capOf(S, pid); if (!cap) return false; const v = villageOf(S, c), vs = S.cities.filter(x => x.owner === pid && !x.isCap && x !== v);
  let from = v || cap, to = null, kind = 'kerja', purpose = '';
  if (mode === 'desa') { if (!vs.length) return false; to = pickR(S, vs); purpose = pickR(S, ['inspeksi pajak', 'memeriksa keamanan', 'meninjau pembangunan']); }
  else if (mode === 'ibukota') { if (!v) return false; to = cap; kind = 'lapor'; purpose = pickR(S, ['melapor kepada raja', 'menghadiri sidang kabinet']); }
  else if (mode === 'dipl') {
    kind = 'dipl'; const ns = S.players.filter(q => q.id !== pid && q.alive && rel(S, pid, q.id) && rel(S, pid, q.id).st !== 'war'); if (!ns.length) return false;
    const q = pickR(S, ns); to = v ? S.cities.filter(x => x.owner === q.id).sort((a, b) => dist(a.x, a.y, from.x, from.y) - dist(b.x, b.y, from.x, from.y))[0] : capOf(S, q.id);
    purpose = pickR(S, ['negosiasi dagang', 'misi diplomatik', 'hubungan bilateral', 'perundingan perbatasan']);
  }
  if (!to || to === from || S.comp[to.y * S.W + to.x] !== S.comp[from.y * S.W + from.x]) return false;
  let path; try { path = MODS.landPath(S, from, to); } catch (e) { return false; } if (!path || path.length < 2 || path.length > 180) return false;
  r.trips.push({ ck: c.ck, pid, path, s: 0, v: 1.2 + S.rnd() * 0.4, ph: 'go', kind, purpose, from: from.id, to: to.id, toName: to.name, toPid: to.owner, stay: 0 }); c.trip = 1;
  clog(S, c, 'berangkat ke ' + to.name + ' untuk ' + purpose);
  note(S, { pid, lvl: 'rutin', type: 'pol', title: 'Penugasan ' + c.name, who: c.t + ' ' + c.name, what: 'berangkat untuk ' + purpose, where: from.name + ' → ' + to.name, impact: kind === 'dipl' ? 'hubungan dengan ' + S.players[to.owner].name + ' dapat berubah' : 'tugas dijalankan langsung di lapangan' });
  return true;
}
function arrive(S, t, c) {
  const p = S.players[t.pid], to = S.cities.find(x => x.id === t.to); if (!to || !p) return; const who = c.t + ' ' + c.name;
  if (t.kind === 'kerja') {
    to.unrest = cl((to.unrest === undefined ? 25 : to.unrest) - 4, 0, 100); let found = '';
    if (to.owner === t.pid) for (const o of villageOfficials(S, to)) if (o.kor > 60 && S.rnd() < 0.5 && !o.reb) { const ot = o.t; replaceChar(S, o, 'dipecat karena korupsi'); found = ' · ' + ot + ' ' + o.name + ' korup dan dipecat'; break; }
    note(S, { pid: t.pid, lvl: found ? 'penting' : 'rutin', type: 'pol', title: 'Kunjungan kerja di ' + to.name, who, what: t.purpose + found, where: to.name, impact: 'kerusuhan -4' + (found ? '; pejabat korup diganti' : '') });
  } else if (t.kind === 'lapor') {
    p.stock.gold += 5; c.loyal = cl(c.loyal + 2, 0, 100);
    note(S, { pid: t.pid, lvl: 'rutin', type: 'pol', title: 'Laporan pejabat daerah', who, what: t.purpose, where: 'Ibu kota ' + p.name, impact: 'pajak tersetor +5 emas, loyalitas naik' });
  } else if (t.kind === 'dipl' && t.toPid >= 0 && S.players[t.toPid]) {
    const rr = rel(S, t.pid, t.toPid); if (!rr) return; let d = 4;
    if (c.sifat.some(x => ['Ramah', 'Bijaksana', 'Jujur'].includes(x))) d = 7; else if (c.sifat.some(x => ['Pemberani', 'Pendendam'].includes(x))) d = -4; else if (c.sifat.includes('Licik')) d = S.rnd() < 0.5 ? 4 : -2;
    rr.op = cl((rr.op || 0) + d, -100, 100); const tn = S.players[t.toPid].name;
    note(S, { pid: t.toPid === VP ? VP : t.pid, major: t.toPid === VP, lvl: d < 0 ? 'peringatan' : 'rutin', type: 'pol', title: (t.pid === VP ? 'Misi diplomatik ke ' : 'Utusan ' + p.name + ' di ') + to.name, who: who + ' (' + p.name + ')', what: t.purpose + (d < 0 ? ' berakhir tegang' : ' berjalan baik'), where: to.name + ', ' + tn, impact: 'hubungan ' + p.name + ' dan ' + tn + (d < 0 ? ' memburuk ' : ' membaik +') + d });
  }
}
function tripTick(S, dt) {
  const r = R(S);
  for (const t of r.trips.slice()) {
    const c = r.chars[t.ck]; if (!c || c.dead) { r.trips.splice(r.trips.indexOf(t), 1); continue; }
    if (t.ph === 'stay') { if (S.time >= t.stay) { t.path = t.path.slice().reverse(); t.s = 0; t.ph = 'back'; } continue; }
    t.s += t.v * dt;
    if (t.s >= t.path.length - 1) {
      if (t.ph === 'go') { arrive(S, t, c); t.ph = 'stay'; t.stay = S.time + DAY * 0.4; }
      else { c.trip = 0; r.trips.splice(r.trips.indexOf(t), 1); clog(S, c, 'kembali ke pos'); }
    }
  }
}

/* ----- keamanan dan penjagaan ----- */
function ensureAssets(S, pid) {
  const r = R(S); if (r.assets[pid]) return;
  r.assets[pid] = ['Kuda Kerajaan I', 'Kuda Kerajaan II', 'Kuda Kerajaan III'].map(n => ({ kind: 'Kuda Kerajaan', name: n, st: 'aman' })).concat([{ kind: 'Kereta Kerajaan', name: 'Kereta Kerajaan', st: 'aman' }, { kind: 'Gudang Emas', name: 'Gudang Emas Istana', st: 'aman', prop: 1 }]);
}
function security(S, pid, cap, p) {
  const r = R(S); ensureAssets(S, pid); const as = r.assets[pid], pn = p.name, cx = cap.x + 1, cy = cap.y + 1;
  const horses = as.filter(a => a.kind === 'Kuda Kerajaan' && a.st === 'aman').length, need = horses * 2 + 2, guard = soldiersNear(S, pid, cx, cy, 12), cover = cl(guard / need, 0, 1);
  r.sec[pid] = { guard, need, cover };
  if (guard < need && typeof orderMove === 'function') {
    const my = S.armies.filter(a => a.owner === pid && !a.ship);
    if (my.length >= 2) {
      const main = my.slice().sort((a, b) => unitsOf(b) - unitsOf(a))[0], a = my.find(q => q !== main && q.st === 'idle' && !q.fight && !(q.path && q.path.length) && dist(q.x, q.y, cx, cy) > 12);
      if (a) { try { orderMove(S, a, Math.round(cx) + 2, Math.round(cy) + 2); a.job = 'jaga'; a.jobT = S.time; note(S, { pid, lvl: 'rutin', type: 'sec', title: 'Prajurit menjaga istana', who: 'Pasukan ' + unitsOf(a) + ' prajurit', what: 'ditugaskan patroli dan penjagaan istana', where: 'Ibu kota ' + pn, impact: 'kuda dan aset kerajaan lebih aman', cool: 2 }); } catch (e) { } }
    }
  }
  if (guard === 0 && horses > 0) note(S, { pid, lvl: 'peringatan', type: 'sec', title: 'Kuda kerajaan tanpa penjagaan', who: horses + ' kuda kerajaan', what: 'tidak dijaga prajurit satu pun', where: 'Istal ibu kota ' + pn, impact: 'rawan dicuri; tempatkan pasukan di ibu kota', cool: 3, key: 'noguard' + pid });
  else if (guard > 0) note(S, { pid, lvl: 'rutin', type: 'sec', title: 'Patroli istana', who: guard + ' prajurit', what: 'berpatroli dan menjaga istal serta gudang', where: 'Ibu kota ' + pn, impact: 'tingkat penjagaan ' + Math.round(cover * 100) + '%', cool: 3, key: 'patrol' + pid });
  const live = as.filter(a => a.st === 'aman');
  const law = typeof gxLaw === 'function' ? gxLaw(S, pid) : 0;   // penegak hukum mengurangi pencurian
  if (live.length && S.rnd() < (0.03 * (1 - cover) + 0.003) * (1 - law)) {
    const t = pickR(S, live);
    if (guard > 0 && S.rnd() < cover * 0.7 + law * 0.5) note(S, { pid, lvl: 'rutin', type: 'sec', title: 'Pencuri tertangkap', who: 'Prajurit jaga', what: 'menangkap pencuri yang mengincar ' + t.name, where: 'Ibu kota ' + pn, impact: 'tidak ada kerugian' });
    else { t.st = 'hilang'; t.since = S.time; let loss = ''; if (t.prop) { const g = 30 + Math.floor(S.rnd() * 50); p.stock.gold = Math.max(0, p.stock.gold - g); loss = '; kas -' + g + ' emas'; } note(S, { pid, lvl: 'penting', type: 'sec', title: 'Pencurian: ' + t.name, who: 'Pencuri tak dikenal', what: t.prop ? 'membobol ' + t.name : 'mencuri ' + t.name, where: 'Ibu kota ' + pn, impact: 'aset hilang, pasukan menyelidiki' + loss }); }
  }
  for (const a of as) if (a.st === 'hilang' && S.time - a.since > DAY * 2 && S.rnd() < (guard > 0 ? 0.25 : 0.08)) { a.st = 'aman'; note(S, { pid, lvl: 'rutin', type: 'sec', title: 'Aset ditemukan: ' + a.name, who: 'Prajurit penyelidik', what: a.name + ' ditemukan kembali', where: 'sekitar ' + pn, impact: 'aset kembali ke kerajaan' }); }
  for (const v of S.cities) {
    if (v.owner !== pid || v.isCap) continue; const cov = soldiersNear(S, pid, v.x + 1, v.y + 1, 9) > 0;
    if (S.rnd() < 0.012 * (cov ? 0.3 : 1)) {
      if (cov && S.rnd() < 0.6) note(S, { pid, lvl: 'rutin', type: 'sec', title: 'Perampokan digagalkan', who: 'Prajurit patroli', what: 'menggagalkan perampokan', where: v.name, impact: 'tidak ada kerugian' });
      else { const g = 5 + Math.floor(S.rnd() * 11); p.stock.gold = Math.max(0, p.stock.gold - g); v.unrest = cl((v.unrest === undefined ? 25 : v.unrest) + 6, 0, 100); note(S, { pid, lvl: 'peringatan', type: 'sec', title: 'Gangguan keamanan di ' + v.name, who: 'Kawanan perampok', what: 'merampok pedagang dan warga', where: v.name, impact: 'kas -' + g + ' emas, kerusuhan +6; kirim pasukan untuk berjaga' }); }
    }
  }
}

/* ----- kehidupan sosial dan ekonomi rakyat ----- */
function social(S, pid, p) {
  const vs = S.cities.filter(c => c.owner === pid && !c.isCap), x = S.rnd();
  if (x < 0.25 && vs.length >= 2) {
    if (popActive(S)) return;   // migrasi sungguhan sekarang dihitung Population Engine
    const a = pickR(S, vs); let b = pickR(S, vs); if (a === b) return; const n = 3 + Math.floor(S.rnd() * 12);
    a.unrest = cl((a.unrest === undefined ? 25 : a.unrest) - 1, 0, 100); b.unrest = cl((b.unrest === undefined ? 25 : b.unrest) + 1, 0, 100);
    note(S, { pid, lvl: 'rutin', type: 'pol', title: 'Perpindahan penduduk', who: n + ' keluarga', what: 'pindah mencari tanah dan pekerjaan', where: a.name + ' → ' + b.name, impact: 'penduduk ' + b.name + ' bertambah' });
  } else if (x < 0.4) {
    const g = 6 + Math.floor(S.rnd() * 12); p.stock.gold += g; const w = vs.length ? pickR(S, vs).name : 'ibu kota';
    note(S, { pid, lvl: 'rutin', type: 'econ', title: 'Pasar ramai', who: 'Para pedagang', what: 'hari pasar berlangsung ramai', where: w, impact: 'kas +' + g + ' emas' });
  }
}

/* ----- siklus harian ----- */
function ensureGov(S) { for (const p of S.players) if (p.alive) { govOf(S, p.id); for (const c of S.cities) if (c.owner === p.id && !c.isCap) villageOfficials(S, c); } }
function dayStep(S) {
  const r = R(S); ensureGov(S);
  for (const p of S.players) {
    if (!p.alive) continue; const cap = capOf(S, p.id); if (!cap) continue;
    growCabinet(S, p.id, cap); sucAuto(S, p.id);
    for (const c of Object.values(r.chars).filter(q => q.owner === p.id && !q.dead)) {
      c.loyal = cl(c.loyal + (c.kor < 40 ? 0.2 : 0) - (c.kor > 60 ? 0.2 : 0), 0, 100);
      if (S.rnd() < 0.12) decide(S, c, p, cap);
    }
    security(S, p.id, cap, p); social(S, p.id, p);
    if (!r.fam[p.id]) r.fam[p.id] = { kids: [] };
  }
  resolveRebels(S); flushRoutine(S);
}
function realmTick(S, dt) {
  const r = R(S);
  if (r.yr === null) { ensureGov(S); r.yr = Math.floor(S.time / RY); r.next = S.time + DAY; note(S, { pid: VP, lvl: 'info', type: 'pol', title: 'Dunia hidup aktif', who: 'Seluruh pejabat, prajurit, dan keluarga kerajaan', what: 'kini bertindak mandiri: bertugas, bepergian, menua, menikah, berkorupsi, bahkan memberontak', where: 'seluruh dunia', impact: 'kejadian penting dilaporkan di Kotak Masuk dan menu Politik → Laporan' }); }
  tripTick(S, dt);
  if (S.time >= r.next) { r.next = S.time + DAY; dayStep(S); }
  const y = Math.floor(S.time / RY); while (r.yr < y) { r.yr++; yearStep(S); }
}
(function () { const _t = tick; tick = function (S, dt) { try { if (MODS.live() && S === UI.S) realmTick(S, dt); } catch (e) { console.error(e); } return _t(S, dt); }; })();

/* ----- gambar: pejabat yang sedang bepergian dan prajurit patroli ----- */
(function () {
  const _d = MODS.draw;
  MODS.draw = function (c, S, vx0, vx1, vy0, vy1) {
    _d.call(MODS, c, S, vx0, vx1, vy0, vy1);
    try {
      if (!S || S !== UI.S || MODS.online() || !S.realm) return; const r = S.realm, inV = (x, y) => x >= vx0 - 2 && x <= vx1 + 2 && y >= vy0 - 2 && y <= vy1 + 2;
      for (const t of r.trips) {
        const ch = r.chars[t.ck]; if (!ch || !S.players[t.pid]) continue; let cx, cy;
        if (t.ph === 'stay') { const e = t.path[t.path.length - 1]; cx = e[0] + 0.5; cy = e[1] + 0.5; }
        else { const k = Math.min(t.path.length - 1, Math.floor(t.s)), f = t.s - Math.floor(t.s), a = t.path[k], b = t.path[Math.min(t.path.length - 1, k + 1)]; cx = a[0] + (b[0] - a[0]) * f + 0.5; cy = a[1] + (b[1] - a[1]) * f + 0.5; }
        if (inV(cx, cy)) drawPerson(c, cx * TS, cy * TS, S.players[t.pid].col, ch.name, false);
      }
      for (const p of S.players) {
        const sc = r.sec && r.sec[p.id], cap = capOf(S, p.id); if (!p.alive || !sc || !cap || !sc.guard || !inV(cap.x, cap.y)) continue;
        const n = Math.min(4, Math.ceil(sc.guard / 8));
        for (let i = 0; i < n; i++) { const a = S.time * 0.15 + i * 6.283 / n; drawPerson(c, (cap.x + 1 + Math.cos(a) * 3.5) * TS, (cap.y + 1 + Math.sin(a) * 3) * TS, p.col, 'Penjaga', false); }
      }
    } catch (e) { }
  };
})();

/* ----- tampilan: Pejabat, Profil, Keluarga, Keamanan, Laporan ----- */
function statusOf(S, c) {
  const r = R(S), t = r.trips.find(q => q.ck === c.ck);
  if (c.reb) return 'MEMBERONTAK'; if (t) return t.ph === 'stay' ? 'di ' + t.toName + ' (' + t.purpose + ')' : t.ph === 'back' ? 'kembali dari ' + t.toName : 'menuju ' + t.toName + ' (' + t.purpose + ')';
  return 'bertugas di ' + whereOf(S, c);
}
function offRow(S, c, me, ind) {
  const k = c.ck; return `<div class="row" style="margin-left:${ind}px">↳ <b>${c.t}</b>: ${c.name}${c.jk === 'P' ? ' (P)' : ''}, ${c.umur} th · loyal ${Math.round(c.loyal)}${c.sakit ? ' · sakit' : ''} ${btn('profil:' + k, 'Profil')}<br><i class="dim">${statusOf(S, c)}</i></div>`;
}
govHTML = function (S) {
  const r = R(S), rows = S.players.filter(p => p.alive).map(p => {
    const me = p.id === VP, g = govOf(S, p.id), rl = r.chars[p.id + '|raja'], desa = S.cities.filter(c => c.owner === p.id && !c.isCap);
    let h = `<div class="it"><div class="g">${sw(p.col)} ${p.name}${me ? ' <span class="gd">(kamu)</span>' : ''}</div></div>`;
    h += `<div class="row" style="margin-left:6px"><b>${cname(rl)}</b>, ${rl.umur} th · Sifat: ${rl.sifat.join(', ')}${rl.wali ? ' · di bawah perwalian' : ''} ${btn('profil:' + rl.ck, 'Profil')}<br><i class="dim">Memimpin kerajaan; keputusan strategis dan izin militer di tangan pemerintah pusat</i></div>`;
    h += g.ministers.map(m => offRow(S, r.chars[m.ck] || m, me, 14)).join('');
    h += `<div class="row" style="margin-left:14px"><i class="dim">Kabinet ibu kota: ${g.ministers.length} pejabat (tanpa batas, bertambah sesuai kebutuhan) · pemukiman lain: ${desa.length}, masing-masing 2 pejabat</i></div>`;
    if (me) h += desa.map(c => { const [w, gu] = villageOfficials(S, c); return `<div class="row" style="margin-left:22px"><b>${c.name}</b> (lv ${c.level}) · pajak ${villageTax(S, c)}/hari · izin militer ${w.izin && gu.izin ? 'ya' : 'sebagian/tidak'}</div>` + offRow(S, w, me, 30) + offRow(S, gu, me, 30); }).join('');
    return h + '<div style="height:8px"></div>';
  }).join('');
  const ex = (r.extra[VP] || []).length;
  return `<div class="gl">Pejabat</div><div class="dim">Hierarki: Raja → Perdana Menteri → menteri. Pejabat bertindak mandiri (bepergian, berpolitik, bisa korup atau memberontak) tetapi tetap di bawah penguasa.</div><div class="btns">${btn('angkat', 'Angkat pejabat (40 emas)')}</div><div class="dim" style="font-size:11px">Pejabat tambahan: ${ex}. Nama pejabat tampil di peta, termasuk yang sedang dalam perjalanan.</div>${rows}`;
};
function ruleName(S) { return R(S).rule === 'lakilaki' ? 'putra lebih dulu, lalu anak tertua' : 'anak tertua (putra atau putri)'; }
function heirOf(S, pid) {
  const r = R(S), fam = r.fam[pid]; if (!fam) return null; const ks = fam.kids.map(k => r.people[k]).filter(c => c && !c.dead).sort((a, b) => b.umur - a.umur || a.born - b.born);
  return (pid === VP && r.rule === 'lakilaki' ? ks.find(k => k.jk === 'L') : null) || ks[0] || null;
}
function royalHTML(S) {
  const r = R(S), ru = r.chars[VP + '|raja'], sp = r.people[VP + '|pasangan'], fam = r.fam[VP] || { kids: [] }, heir = heirOf(S, VP);
  const kids = fam.kids.map(k => r.people[k]).filter(Boolean).sort((a, b) => b.umur - a.umur);
  let h = `<div class="gl">Keluarga Kerajaan ${S.players[VP].name}</div><div class="row"><b>${cname(ru)}</b>, ${ru.umur} th ${btn('profil:' + ru.ck, 'Profil')}</div>`;
  h += sp ? `<div class="row">Pasangan: <b>${cname(sp)}</b>, ${sp.umur} th ${btn('profil:' + sp.ck, 'Profil')}</div>` : `<div class="row dim">Belum menikah ${ru.umur >= 18 ? btn('menikah', 'Menikah (50 emas)') : ''}</div>`;
  h += `<div class="row">Anak (${kids.length}):</div>` + (kids.length ? kids.map(k => `<div class="row" style="margin-left:14px">${k === heir ? '👑 ' : ''}${k.gelar} <b>${k.name}</b>, ${k.umur} th · ${k.ortu || ''} ${btn('profil:' + k.ck, 'Profil')}</div>`).join('') : '<div class="row dim" style="margin-left:14px">belum ada</div>');
  h += `<div class="row">Pewaris: <b>${heir ? heir.gelar + ' ' + heir.name : 'belum ada (Perdana Menteri akan diangkat)'}</b></div><div class="row">Aturan pewarisan: ${ruleName(S)} ${btn('aturan', 'Ubah aturan')}</div>`;
  const gr = r.graves.filter(g => g.owner === VP).slice(0, 5); if (gr.length) h += '<div class="gl" style="margin-top:6px">Wafat</div>' + gr.map(g => `<div class="row dim">${g.t} ${g.name}, ${g.umur} th · ${g.cause} · Hari ${Math.floor(g.time / DAY) + 1}</div>`).join('');
  return h;
}
function secHTML(S) {
  const r = R(S); ensureAssets(S, VP); const as = r.assets[VP], sc = r.sec[VP] || { guard: 0, need: 0, cover: 0 };
  let h = `<div class="gl">Keamanan Kerajaan</div><div class="row">Penjaga ibu kota: <b>${sc.guard}</b> prajurit (butuh ${sc.need}) · penjagaan <b>${Math.round(sc.cover * 100)}%</b></div><div class="dim">Kuda dan aset kerajaan wajib dijaga prajurit. Prajurit cadangan otomatis dikirim berjaga dan berpatroli.</div>`;
  h += as.map(a => `<div class="row">${a.st === 'aman' ? '✔' : '✖'} <b>${a.name}</b> · ${a.st === 'aman' ? 'aman' : '<span class="bad">hilang, sedang dicari</span>'}</div>`).join('');
  const vs = S.cities.filter(c => c.owner === VP && !c.isCap); if (vs.length) h += '<div class="gl" style="margin-top:6px">Pemukiman</div>' + vs.map(v => `<div class="row">${v.name}: ${soldiersNear(S, VP, v.x + 1, v.y + 1, 9) ? '<span class="gd">dijaga</span>' : '<span class="bad">tanpa penjagaan</span>'}</div>`).join('');
  const ev = r.log.filter(l => l.type === 'sec' && l.own).slice(0, 6); h += '<div class="gl" style="margin-top:6px">Kejadian terbaru</div>' + (ev.length ? ev.map(l => `<div class="row dim">Hari ${Math.floor(l.t / DAY) + 1}: ${l.title}</div>`).join('') : '<div class="row dim">belum ada</div>');
  return h;
}
function laporHTML(S) {
  const r = R(S), f = r.flt, cls = { penting: 'bad', peringatan: 'gl', rutin: 'dim', info: '' };
  const fb = [['all', 'Semua'], ['penting', 'Penting'], ['peringatan', 'Peringatan'], ['rutin', 'Rutin']].map(x => btn('lf:' + x[0], x[1], f === x[0] ? 'on' : '')).join('');
  const ls = r.log.filter(l => f === 'all' || l.lvl === f).slice(0, 30);
  return `<div class="gl">Laporan Peristiwa</div><div class="btns">${fb}</div>` + (ls.length ? ls.map(l => `<div class="row ${cls[l.lvl] || ''}"><b>${TAG[l.lvl]} ${l.title}</b> <span class="dim">Hari ${Math.floor(l.t / DAY) + 1}${l.own ? '' : ' · kerajaan lain'}</span><br><i class="dim">${l.text}</i></div>`).join('') : '<div class="dim">Belum ada peristiwa.</div>');
}
function profilHTML(S, c) {
  const r = R(S), me = c.owner === VP, p = S.players[c.owner], f = k => (r.chars[k] || r.people[k]);
  const rels = Object.keys(c.rel).filter(k => !k.endsWith('_s')); const al = rels.filter(k => c.rel[k] >= 40 && f(k) && !f(k).dead).map(k => f(k).name), ri = rels.filter(k => c.rel[k] <= -40 && f(k) && !f(k).dead).map(k => f(k).name);
  const efek = (SIFAT_EFEK[c.t] || {}), rows = [
    ['Jabatan', cname(c)], ['Kerajaan', p.name], ['Usia / jenis', c.umur + ' th · ' + (c.jk === 'P' ? 'perempuan' : 'laki-laki') + (c.sakit ? ' · sedang sakit' : '')],
    ['Sifat', c.sifat.map(x => x + ' (' + SIFAT_KET[x] + (efek[x] ? '; ' + efek[x] : '') + ')').join(', ')], ['Loyalitas', Math.round(c.loyal) + '/100'], ['Integritas', (100 - c.kor) + '/100' + (c.kor >= 60 ? ' (rawan korupsi)' : c.kor <= 30 ? ' (jujur)' : '')], ['Ambisi', c.amb + '/100' + (c.amb >= 65 && c.loyal <= 38 ? ' (berbahaya)' : '')],
    ['Status', statusOf(S, c)], ['Atasan', c.atasan || (c.t === 'Raja' ? 'tertinggi' : '-')], ['Sekutu', al.join(', ') || '-'], ['Rival', ri.join(', ') || '-']];
  if (c.ortu) rows.push(['Orang tua', c.ortu]); if (c.izin !== undefined) rows.push(['Izin militer', (c.izin ? 'ada' : 'dicabut') + ' (hak pemerintah pusat)']);
  let b = rows.map(x => `<div class="row"><b>${x[0]}:</b> ${x[1]}</div>`).join('') + '<div class="gl" style="margin-top:6px">Riwayat</div>' + (c.log.length ? c.log.map(l => `<div class="row dim">${l}</div>`).join('') : '<div class="row dim">belum ada</div>');
  if (me && c.t !== 'Raja' && c.t !== 'Anak' && c.t !== 'Pasangan') {
    b += '<div class="btns" style="margin-top:6px">' + btn('tugas:' + c.ck + '~desa', 'Kirim ke desa') + btn('tugas:' + c.ck + '~ibukota', 'Panggil ke ibu kota') + btn('tugas:' + c.ck + '~dipl', 'Misi diplomatik') + (c.izin !== undefined ? btn('izin:' + c.ck, c.izin ? 'Cabut izin militer' : 'Beri izin militer') : '') + btn('pecat:' + c.ck, 'Pecat') + '</div>';
  }
  return b;
}
const _lh = listHtml;
listHtml = function (sh) {
  const S = UI.S; if (sh.what === 'royal') return { title: 'Keluarga', body: royalHTML(S) }; if (sh.what === 'sec') return { title: 'Keamanan', body: secHTML(S) }; if (sh.what === 'lapor') return { title: 'Laporan', body: laporHTML(S) };
  return _lh(sh);
};
Object.assign(ACT, {
  royal() { openList('royal'); }, sec() { openList('sec'); }, lapor() { openList('lapor'); }, lf(f) { R(UI.S).flt = f; },
  profil(k) { const S = UI.S, r = R(S), c = r.chars[k] || r.people[k]; if (!c) return say('Tokoh tidak ditemukan', false); showModal(cname(c), profilHTML(S, c)); },
  angkat() { const S = UI.S, p = S.players[VP]; if ((p.stock.gold || 0) < 40) return say('Emas tidak cukup (40)', false); p.stock.gold -= 40; appoint(S, VP, true); say('Pejabat baru diangkat', true); },
  menikah() { const S = UI.S, p = S.players[VP]; if ((p.stock.gold || 0) < 50) return say('Emas tidak cukup (50)', false); if (marry(S, VP)) p.stock.gold -= 50; },
  aturan() { const r = R(UI.S); r.rule = r.rule === 'lakilaki' ? 'sulung' : 'lakilaki'; say('Aturan pewarisan: ' + ruleName(UI.S), true); },
  pecat(k) {
    const S = UI.S, r = R(S), c = r.chars[k]; if (!c || c.owner !== VP || c.t === 'Raja') return; const n = c.t, ex = r.extra[VP] || [];
    if (ex.includes(k)) { cancelTrip(S, c); c.dead = S.time; delete r.chars[k]; r.extra[VP] = ex.filter(x => x !== k); } else replaceChar(S, c, 'dipecat oleh ' + (S.players[VP].name));
    note(S, { pid: VP, lvl: 'info', type: 'pol', title: 'Pejabat dipecat: ' + n, who: n + ' ' + c.name, what: 'dipecat oleh penguasa', where: whereOf(S, c), impact: ex.includes(k) ? 'jabatan dihapus' : 'pejabat baru diangkat' }); ACT.closemodal();
  },
  tugas(a) { const [k, m] = a.split('~'), S = UI.S, c = R(S).chars[k]; if (!c || c.owner !== VP) return; ACT.closemodal(); if (!startTrip(S, c, VP, m)) say('Tidak ada tujuan yang bisa dicapai lewat darat', false); },
  izin(k) { const S = UI.S, c = R(S).chars[k]; if (!c || c.owner !== VP || c.izin === undefined) return; c.izin = !c.izin; clog(S, c, c.izin ? 'diberi izin militer oleh pusat' : 'izin militer dicabut oleh pusat'); ACT.profil(k); }
});
