/* ----- suksesi: pangeran dengan pendukung, selir, dan perebutan takhta ----- */
const SUC_SELIR_MAX = 20;
function sucInit(S, c, legit) { c.legit = legit; if (c.dukung === undefined) c.dukung = 20 + Math.floor(S.rnd() * 40); if (c.asing === undefined) c.asing = 0; return c; }
// kekuatan klaim: pendukung + legitimasi + umur (dan bonus bila aturan mengutamakan putra)
function sucPower(c, rule) { return (c.dukung || 0) + (c.legit === undefined ? 100 : c.legit) * 0.4 + Math.min(10, Math.max(0, c.umur - 16)) + (rule === 'lakilaki' && c.jk === 'L' ? 15 : 0); }
// memilih pewaris. Jika dua pangeran kuat selisihnya kecil, terjadi perebutan takhta
function sucPickHeir(S, pid, rule) {
  const r = R(S), fam = r.fam[pid] || { kids: [] };
  const kids = fam.kids.map(k => r.people[k]).filter(c => c && !c.dead);
  const adult = kids.filter(c => c.umur >= 16 && !c.asing);
  if (!adult.length) return kids.sort((a, b) => b.umur - a.umur)[0] || null;
  const scored = adult.map(c => ({ c, p: sucPower(c, rule) })).sort((a, b) => b.p - a.p);
  const top = scored[0], rivals = scored.slice(1).filter(s => top.p - s.p < 20);
  if (!rivals.length) return top.c;
  const contenders = [top, ...rivals], total = contenders.reduce((s, x) => s + x.p, 0);
  let roll = S.rnd() * total, win = contenders[contenders.length - 1];
  for (const x of contenders) { if (roll < x.p) { win = x; break; } roll -= x.p; }
  for (const x of contenders) if (x !== win) { if (S.rnd() < 0.5) x.c.asing = 1; else die(S, x.c, 'tewas dalam perebutan takhta'); }
  const P = S.players[pid]; P.stock.gold = Math.max(0, (P.stock.gold || 0) - 80);
  for (const c of S.cities) if (c.owner === pid) c.unrest = cl((c.unrest === undefined ? 25 : c.unrest) + 15, 0, 100);
  note(S, { pid, major: 1, lvl: 'penting', type: 'pol', title: gxl('Civil war over the throne', 'Perang saudara perebutan takhta'), who: contenders.map(x => cname(x.c)).join(', '), what: gxl(cname(win.c) + ' seized the throne', cname(win.c) + ' merebut takhta'), where: gxl('Capital ', 'Ibu kota ') + P.name, impact: gxl('kas -80 emas, kerusuhan naik; losers are exiled or killed', 'kas -80 emas, kerusuhan naik; yang kalah diasingkan atau tewas') });
  return win.c;
}
// dukungan bergeser tiap tahun: legitimasi tinggi dan pangeran dewasa lebih didukung
function sucYearly(S) {
  const r = R(S);
  for (const p of S.players) {
    const fam = r.fam[p.id]; if (!p.alive || !fam) continue;
    for (const k of fam.kids) {
      const c = r.people[k]; if (!c || c.dead) continue; sucInit(S, c, 100);
      const gov = typeof govOf === 'function' ? govOf(S, p.id) : null, mins = gov && gov.ministers ? gov.ministers : [];
      const avgLoyal = mins.length ? mins.reduce((s, m) => s + (m.loyal || 50), 0) / mins.length : 50;   // menteri yang setia mendukung pangeran
      const target = 30 + (c.legit - 50) * 0.3 + (c.umur >= 16 ? 10 : 0) + (avgLoyal - 50) * 0.1 + (gxOf(S, p.id).guild.sekte * 2) - (c.asing ? 25 : 0);
      c.dukung = cl(c.dukung + (target - c.dukung) * 0.15, 0, 100);
      // pangeran yang diasingkan dengan pendukung kuat bisa kembali
      if (c.asing && c.dukung > 70 && S.rnd() < 0.05) { c.asing = 0; for (const q of S.cities) if (q.owner === p.id) q.unrest = cl((q.unrest === undefined ? 25 : q.unrest) + 10, 0, 100); if (p.id === VP) note(S, { pid: p.id, lvl: 'penting', type: 'pol', title: gxl('Exiled prince returns: ', 'Pangeran pengasingan kembali: ') + cname(c), who: cname(c), what: gxl('returned with strong supporters', 'kembali dengan pendukung kuat'), where: gxl('Capital ', 'Ibu kota ') + p.name, impact: gxl('unrest +10; rival claim renewed', 'kerusuhan +10; klaim takhta kembali memanas') }); }
    }
  }
}
// selir: hanya untuk raja laki-laki; anak dari selir berstatus legitimasi 50
function sucAddSelir(S, pid) {
  const r = R(S), P = S.players[pid];
  const n = Object.keys(r.people).filter(k => k.startsWith(pid + '|selir|')).length;
  if (n >= SUC_SELIR_MAX) return gxl('Concubine limit reached (3).', 'Batas selir tercapai (3).');
  if ((P.stock.gold || 0) < 60) return gxl('Not enough gold (60)', 'Emas tidak cukup (60)');
  P.stock.gold -= 60;
  const key = pid + '|selir|' + (r.n++);
  newChar(S, key, { store: 'people', t: 'Selir', gelar: gxl('Concubine', 'Selir'), owner: pid, jk: 'P', umur: 18 + Math.floor(S.rnd() * 17), loyal: 60, nsifat: 1 });
  // keseimbangan: separuh selir bersifat baik, separuh bersifat jahat
  const sels = Object.keys(r.people).filter(k => k.indexOf(pid + '|selir|') === 0).map(k => r.people[k]).filter(x => x && !x.dead && x !== r.people[key]);
  const good = sels.filter(x => x.sifat.some(s => SELIR_GOOD.includes(s))).length, evil = sels.length - good;
  r.people[key].sifat = [pickR(S, good <= evil ? SELIR_GOOD : SELIR_EVIL)];
  if (pid === VP) note(S, { pid, lvl: 'penting', type: 'life', title: gxl('New concubine', 'Selir baru'), who: P.name, what: gxl('took a concubine', 'mengambil selir'), where: gxl('Palace ', 'Istana ') + P.name, impact: gxl('her children have lower legitimacy (50)', 'anaknya berstatus legitimasi 50') });
  return null;
}
// tampilan pemain: pangeran, selir (dengan jumlah anak), dan daftar anak
function succView(S) {
  const r = R(S), pid = VP, fam = r.fam[pid] || { kids: [] };
  const alive = c => c && !c.dead;
  const kids = fam.kids.map(k => r.people[k]).filter(alive);
  const selirs = Object.keys(r.people).filter(k => k.indexOf(pid + '|selir|') === 0).map(k => r.people[k]).filter(alive);
  const rowsOf = list => list.map(c => {
    sucInit(S, c, 100);
    const mom = c.ibu && r.people[c.ibu] ? cname(r.people[c.ibu]) : (c.ibu ? gxl('queen', 'permaisuri') : '-');
    return `<div class="it"><div class="g"><b>${cname(c)}</b> · ${c.umur} ${gxl('yrs', 'th')} · ${gxl('legitimacy', 'legitimasi')} ${c.legit}${c.asing ? ' · ' + gxl('exiled', 'diasingkan') : ''}<div class="dim">${gxl('Mother', 'Ibu')}: ${mom} · ${gxl('Supporters', 'Pendukung')}: ${Math.round(c.dukung)}%</div></div>${c.asing ? '' : btn('suk:bantu:' + c.ck, gxl('Support (50)', 'Bantu (50)'))}${btn('suk:asing:' + c.ck, c.asing ? gxl('Recall', 'Pulangkan') : gxl('Exile', 'Asingkan'))}</div>`;
  }).join('');
  const princes = kids.filter(c => c.ibu !== undefined && !(c.ibu && r.people[c.ibu] && r.people[c.ibu].t === 'Selir'));
  const selirHtml = selirs.map(s => {
    const mine = kids.filter(c => c.ibu === s.ck);
    const childLines = mine.length
      ? mine.map(c => `<div class="it"><div class="g">${cname(c)} · ${c.umur} ${gxl('yrs', 'th')}</div>${btn('profil:' + c.ck, gxl('Profile', 'Profil'))}</div>`).join('')
      : `<div class="dim">${gxl('No children yet.', 'Belum punya anak.')}</div>`;
    return `<div class="it"><div class="g"><b>${cname(s)}</b> · ${s.umur} ${gxl('yrs', 'th')} · ${gxl('children', 'anak')}: ${mine.length}<div class="dim">${gxl('Her children have legitimacy 50.', 'Anaknya berlegitimasi 50.')}</div></div>${btn('profil:' + s.ck, gxl('Profile', 'Profil'))}</div>${childLines}`;
  }).join('');
  return { title: gxl('Succession', 'Suksesi takhta'), html:
    '<div class="dim">' + gxl('The heir is chosen by supporters and legitimacy. Close rivals may start a civil war.', 'Pewaris dipilih dari dukungan dan legitimasi. Pesaing yang kuat bisa memicu perang saudara.') + '</div>' +
    '<div class="gl" style="margin-top:6px">' + gxl('Princes and princesses', 'Pangeran dan putri') + ' (' + kids.length + ')</div><div class="list">' + (rowsOf(kids) || '<div class="dim">' + gxl('No children yet.', 'Belum punya anak.') + '</div>') + '</div>' +
    '<div class="gl" style="margin-top:6px">' + gxl('Concubines', 'Selir') + ' (' + selirs.length + '/' + SUC_SELIR_MAX + ')</div><div class="list">' + (selirHtml || '<div class="dim">' + gxl('No concubines yet.', 'Belum ada selir.') + '</div>') + '</div>' +
    '<div class="btns">' + btn('suk:selir:0', gxl('Take concubine (60)', 'Ambil selir (60)')) + '</div>' };
}

// gambar sosok di peta: petugas di dekat markasnya, keluarga kerajaan (permaisuri, anak, selir) di sekitar istana
function gxDrawFigures(c, S, vx0, vx1, vy0, vy1) {
  if (!S || S !== UI.S || typeof drawPerson !== 'function') return;
  const r = R(S), inV = (x, y) => x >= vx0 - 2 && x <= vx1 + 2 && y >= vy0 - 2 && y <= vy1 + 2;
  for (const p of S.players) {
    if (!p.alive) continue;
    for (const [id, type] of [['dokter', 'hospital'], ['damkar', 'firehouse']]) {
      const keys = gxStaffKeys(S, p.id, id), blds = S.buildings.filter(b => b.owner === p.id && b.type === type && !(b.cons > 0));
      if (!blds.length) continue;
      keys.forEach((k, i) => {
        const m = r.people[k], b = blds[i % blds.length]; if (!m) return;
        const x = b.x + 0.5 + Math.cos(i * 2.1) * 1.6, y = b.y + 1.6 + Math.sin(i * 2.1) * 0.6;
        if (inV(x, y)) drawPerson(c, x * TS, y * TS, p.col, cname(m), false);
      });
    }
    const ct = S.cities.find(q => q.isCap && q.owner === p.id); if (!ct) continue;
    const members = [], sp = r.people[p.id + '|pasangan']; if (sp && !sp.dead) members.push(sp);
    for (const k of ((r.fam[p.id] && r.fam[p.id].kids) || [])) { const x = r.people[k]; if (x && !x.dead) members.push(x); }
    for (const k of Object.keys(r.people)) if (k.indexOf(p.id + '|selir|') === 0) { const x = r.people[k]; if (x && !x.dead) members.push(x); }
    members.forEach((m, i) => {
      const ang = i * 2.399, rad = 2.5 + (i % 3) * 0.9, x = ct.x + 1 + Math.cos(ang) * rad, y = ct.y + 2.5 + Math.sin(ang) * rad * 0.6;
      if (inV(x, y)) drawPerson(c, x * TS, y * TS, p.col, cname(m), false);
    });
  }
}

// sifat selir: baik dan jahat (dipakai untuk menjaga keseimbangan 50:50)
const SELIR_GOOD = ['Jujur', 'Setia', 'Bijaksana', 'Ramah', 'Pragmatis'];
const SELIR_EVIL = ['Licik', 'Serakah', 'Ambisius', 'Pendendam', 'Pemalas'];
// AI mengambil selir sendiri: tiap 3 hari game, bila raja laki-laki dewasa dan kas cukup (kas cadangan 150)
// pemain ikut hanya jika AI ambil alih menyala
function sucAuto(S, pid) {
  if (pid === VP && !(typeof MODS !== 'undefined' && MODS.cfg && MODS.cfg.auto)) return;
  const r = R(S), ru = r.chars[pid + '|raja'];
  if (!ru || ru.dead || ru.jk !== 'L' || ru.umur < 18) return;
  if (S.time - (r['sa' + pid] || 0) < DAY * 3) return;
  r['sa' + pid] = S.time;
  if ((S.players[pid].stock.gold || 0) < 150) return;
  sucAddSelir(S, pid);
}
