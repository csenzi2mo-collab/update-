'use strict';
/* ===== Команды игроков (общий слой для одиночной и сетевой игры) =====
   execCmd выполняется ОДИНАКОВО на всех устройствах (lockstep), поэтому здесь только детерминированный код:
   никакого UI, времени, Math.random. Возвращает { msg, ok } для показа игроку-автору команды. */
function execCmd(S, pid, c) {
  const P = S.players[pid]; if (!P || !c || typeof c.k !== 'string') return null;
  const R = (msg, ok) => ({ msg: msg || null, ok: !!ok, k: c.k });
  const E = e => e ? R(e, false) : null;           // тихий успех, ошибка — тостом
  const num = v => (typeof v === 'number' && isFinite(v)) ? v : null;
  const id = num(c.id);
  const bld = () => { const b = S.buildings.find(q => q.id === id); return b && b.owner === pid ? b : null; };
  const army = () => { const a = S.armies.find(q => q.id === id); return a && a.owner === pid && !a.ship ? a : null; };
  const ship = () => { const s = S.ships.find(q => q.id === id); return s && s.owner === pid ? s : null; };
  const target = () => { const t = num(c.to); return t !== null && t >= 0 && t < S.players.length && t !== pid && S.players[t].alive ? t : null; };
  const NOPE = { b: 'Здание не найдено', a: 'Армия не найдена', s: 'Корабль не найден' };
  switch (c.k) {
    case 'build': {
      if (!Array.isArray(c.tiles) || !c.tiles.length || c.tiles.length > 200) return null;
      if (c.type !== 'village' && !BD[c.type]) return null;
      const tiles = c.tiles.map(t => ({ x: num(t[0]), y: num(t[1]) })); if (tiles.some(t => t.x === null || t.y === null)) return null;
      let built = 0, fail = '', todo = tiles.slice();
      for (let pass = 0; pass < tiles.length && todo.length; pass++) { let pr = false; for (const t of todo.slice()) { const e = doBuild(S, pid, c.type, t.x | 0, t.y | 0); if (!e) { built++; pr = true; todo.splice(todo.indexOf(t), 1); } else fail = e; } if (!pr) break; }
      if (built) { calcRates(S); calcScore(S); }
      return built ? R(built > 1 ? 'Начато строительство: ' + built + ' кл.' : 'Начато строительство', true) : R(fail || 'Нельзя построить', false);
    }
    case 'upgrade': { const ct = S.cities[id]; if (!ct || ct.owner !== pid) return R('Это не ваш город', false); const e = upgradeCity(S, ct); return R(e || (ct.level === 0 ? 'Деревня выросла' : ct.level === 1 ? 'Деревня стала городом' : 'Город улучшен'), !e); }
    case 'recipe': { const b = bld(); if (!b || typeof c.r !== 'string') return null; b.recipe = c.r; b.busy = false; return null; }
    case 'cmdr': { const b = bld(); if (!b || typeof c.t !== 'string') return null; return E(enqueueCmd(S, b, c.t)); }
    case 'train': { const b = bld(); if (!b || !SQ[c.t]) return null; return E(enqueue(S, b, c.t)); }
    case 'ship': { const b = bld(); if (!b || (c.t !== 'war' && c.t !== 'trade')) return null; const e = buildShip(S, b, c.t); return R(e || 'Судно построено', !e); }
    case 'demolish': { const b = bld(); if (!b) return null; demolish(S, b); return null; }
    case 'ungar': { const b = bld(); if (!b) return null; ungarrison(S, b); return R('Отряд покинул башню', true); }
    case 'merge': { const a = army(); if (!a) return R(NOPE.a, false); const n = mergeNear(S, a); return R(n ? 'Отряды объединены' : 'Рядом нет своих армий (нужно подойти ближе)', !!n); }
    case 'split': { const a = army(); if (!a) return R(NOPE.a, false); const n = splitArmy(S, a); return R(n ? 'Армия разделена' : 'В армии один отряд', !!n); }
    case 'stop': { const a = army(); if (!a) return null; stopArmy(a); return null; }
    case 'retreat': { const a = army(); if (!a) return null; const e = retreat(S, a); return R(e || 'Армия отступает', !e); }
    case 'move': { const a = army(), x = num(c.x), y = num(c.y); if (!a || x === null || y === null) return null; return E(orderMove(S, a, x, y)); }
    case 'sail': { const s = ship(), x = num(c.x), y = num(c.y); if (!s || s.kind !== 'war' || x === null || y === null) return null; return E(orderShip(S, s, x, y)); }
    case 'stopship': { const s = ship(); if (s) s.path = []; return null; }
    case 'unload': { const s = ship(); if (!s) return R(NOPE.s, false); const e = unloadShip(S, s, num(c.army)); return R(e || 'Войска высажены', !e); }
    case 'board': { const a = army(); if (!a) return R(NOPE.a, false); const sid = num(c.ship), sh = sid !== null ? S.ships.find(q => q.id === sid && q.owner === pid) : pickShip(S, a); if (!sh) return R('Нет своего военного корабля со свободным местом', false); const e = orderBoard(S, a, sh); return R(e || (a.ship ? 'Войска на борту' : 'Армия идёт к кораблю'), !e); }
    case 'claim': { const t = target(); if (t === null) return null; const e = startClaim(S, pid, t); return R(e || 'Претензия предъявлена: 3 дня', !e); }
    case 'war': { const t = target(); if (t === null) return null; const e = declareWar(S, pid, t); return R(e || 'Война объявлена', !e); }
    case 'breakally': { const t = target(); if (t === null) return null; breakAlly(S, pid, t); return null; }
    case 'offer': { const t = target(); if (t === null || !['trade', 'truce', 'ult', 'ally', 'pass'].includes(c.kind)) return null; const e = offer(S, pid, t, c.kind); return R(e || 'Предложение отправлено', !e); }
    case 'canceltrade': { const t = target(); if (t === null) return null; cancelTrade(S, pid, t); return null; }
    case 'answer': { if (id === null) return null; answerMsg(S, id, !!c.y, pid); return null; }
    case '_back': { P.human = true; for (const q of S.players) if (q.human) info(S, q.id, 'Игрок вернулся', P.name + ' снова в игре.', 'info'); return null; }
    case '_left': { P.human = false; for (const q of S.players) if (q.human) info(S, q.id, 'Игрок вышел', P.name + ' покинул игру. Его королевством управляет советник.', 'info'); return null; }
  }
  return null;
}
/* Один ход сети: сперва команды в порядке прихода, затем ровно один шаг симуляции. */
function applyTurn(S, t, onRes) {
  for (const q of t.cmds) { let r = null; try { r = execCmd(S, q.p, q.c); } catch (e) { r = null; } if (r && onRes && q.p === VP) onRes(r); }
  tick(S, 0.25);
}
/* Контрольная сумма состояния — поиск рассинхрона между устройствами */
function stateHash(S) {
  let h = 2166136261 >>> 0; const mix = v => { h = Math.imul(h ^ (v | 0), 16777619) >>> 0; };
  mix(Math.round(S.time * 100)); mix(S.nid); mix(S.armies.length); mix(S.buildings.length);
  for (const p of S.players) { mix(p.stock.gold); mix(p.stock.wood); mix(p.stock.food); mix(p.stock.iron); mix(p.alive ? 1 : 0); }
  for (const a of S.armies) { mix(a.id); mix(Math.round(a.x * 100)); mix(Math.round(a.y * 100)); mix(a.maxU); }
  for (const sh of S.ships) { mix(sh.id); mix(Math.round(sh.x * 100)); mix(Math.round(sh.y * 100)); mix(Array.isArray(sh.cargo) ? sh.cargo.length : 0); }
  for (const b of S.buildings) { mix(b.id); mix(b.owner); mix(Math.round((b.cons || 0) * 10)); }
  for (const c of S.cities) { mix(c.owner); mix(c.level); mix(Math.round(c.radius * 10)); }
  for (let i = 0; i < S.tc.length; i += 7) mix(S.tc[i]);
  return h;
}
